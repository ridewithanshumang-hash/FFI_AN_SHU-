# FFI_ANSHU - Stage 1 prototype

## Setup
1. Unity Hub: create a new project (Unity 6 or 2022.3 LTS, "3D (URP)" or "3D" template).
2. Copy the `Assets/FFI_ANSHU` folder from here into that project's `Assets`.
3. Open any scene and press Play. `GameBootstrap` auto-starts and builds everything in code.
4. Menu `FFI_ANSHU > Configure for Android`, then File > Build Settings > Android > Build.
5. If the sky is missing in a build: Project Settings > Graphics > Always Included Shaders > add `Skybox/Procedural`.

## Controls
- Phone: left thumb = floating joystick, right side drag = camera, JUMP / CROUCH / SPRINT buttons, SENS +/-.
- Editor: WASD, Space, C, Shift, hold right mouse to look.

## Done in Stage 1
Player (procedural character, 4 original skins), third-person camera with collision, mobile controls,
800x800m Jaisalmer-style map (dunes, edge mountains, canyon + bridge, fort, bazaar town, 3 villages, roads,
market, trees, rocks), enterable houses with doors/windows/stairs, day/night cycle, fog, FPS counter.

## Done in Stage 2 (combat)
4 original weapons (Loha Pistol, Thar SMG, Marusthal AR, Sher Shotgun), FIRE (2 buttons) / AIM (zoom, tighter spread) /
RELOAD / SWAP buttons, recoil, tracers, muzzle flash, headshots (x2), health + damage, hit marker, damage flash,
12 enemy bots (wander, spot, chase, strafe, shoot), kill counter, alive counter, death screen + respawn, VICTORY when all bots die.
Editor keys: F fire, E aim, R reload, Q swap.

## Done in Stage 3 (match flow)
- Loot: weapons, ammo packs, medkits and armor plates spawn in houses (fort has better loot) and open ground; walk over to pick up.
  You now start with only the Loha Pistol (36 reserve ammo). Reload uses reserve ammo.
- Inventory: BAG button (top right) lists the 4 weapons with ammo, tap a row to equip; HEAL (+50 hp) and ARMOR (+50 armor, absorbs 60% of damage) buttons.
- Safe zone: blue pillar ring, 5 shrinking phases with growing damage, status text, bots run back into the zone.
- Parachute: match starts on a plane (tap JUMP to drop), free-fall, tap JUMP again (or auto at 90 m) to open the parachute, steer with the joystick.
- Not parachuting yet: the bots (they start on the ground).

## Done in Stage 4
- 3D lobby (sandstone courtyard, lanterns, your character on a podium) with menus: CHARACTER (4 outfits), MAP (Jaisalmer; 2nd map shown as locked),
  INVENTORY & PROFILE (stats, owned weapons, last 5 matches = leaderboard), SETTINGS (graphics Low/Med/High, FPS 30/60, music, sounds, sensitivity, match size 20/35/50),
  PLAY -> matchmaking screen (offline: filled with bots) -> match.
- Result screen at the end (place, kills, time) with PLAY AGAIN / LOBBY; stats saved on the device.
- Vehicles: 10 jeeps around roads. Walk close, press DRIVE. Joystick = throttle/steer, JUMP = handbrake, EXIT to get out. Run over bots for damage.
- Sound: all synthesized in code (guns, steps, pickups, engine, wind) + an original raga-style music loop. No audio files used.
- Minimap (roads, villages, canyon, you, zone ring, next-zone ring) + white next-zone pillars in the world.
- Far bots (170 m+) are hidden to keep 50-player matches playable on mid-range phones.

## Important notes
- Save your scene (Ctrl+S) before pressing Play, or LOBBY / PLAY AGAIN cannot reload it.
- Shadow quality in Settings works with the Built-in pipeline ("3D" template). With URP the shadow settings come from the URP asset.

## Done in Stage 5
- Coins + outfit shop: 8 original outfits (first one free). Earn coins every match (kills, placement, win bonus); you start with 500. Lobby > CHARACTER > BUY / EQUIP.
- Bots now start in the plane and parachute down at random times.
- Sandstorm weather: thick tan fog, louder wind, bots see less far. Random timing (shown at top as SANDSTORM).
- EMOTE button (dance) next to HEAL / ARMOR.

## NOT done yet
Real online multiplayer (matches are offline vs bots), real rigged / animated 3D character models and textures,
a second map (Thar Dunes is shown as locked), squads / friends.

## Cloud APK build (no Unity install needed)
1. Create a GitHub repo and push this whole folder (the one containing Assets, Packages, ProjectSettings, .github).
2. Actions > "Unity activation file (run once)" > Run. Download the `.alf` artifact.
3. Go to https://license.unity3d.com/manual, upload the `.alf`, choose Unity Personal, download the `.ulf`.
4. Repo Settings > Secrets and variables > Actions, add: UNITY_LICENSE (full text of the .ulf), UNITY_EMAIL, UNITY_PASSWORD.
5. Actions > "Build FFI_ANSHU APK" > Run workflow. When green, download artifact `FFI_ANSHU-apk` (a zip containing FFI_ANSHU.apk).
Unity's licensing flow changes over time; if step 2-4 differ, follow https://game.ci/docs/github/activation
In the Unity Editor you can also use menu FFI_ANSHU > Build APK.

## Phone-only build (no computer)
1. On github.com (browser, "desktop site") create a repo. Upload `FFI_ANSHU_ALL_IN_ONE.zip` as a single file (Add file > Upload files).
2. Add file > Create new file, name it `.github/workflows/build-from-zip.yml`, paste extra/build-from-zip.yml; same for unity-activation.yml.
3. Do the Unity license steps above (activation file + secrets), then Actions > "Build APK from zip" > Run workflow.

## Stage 6
- RiggedCharacter.cs: real skinned mesh (17-bone skeleton, smooth joint-blended weights) used by player, bots and lobby. Generated in code, NOT an artist-made model.
- Second map KALAHARI (red desert, 6 tent camps with fires/watchtowers, 5 adobe lodges, giant dinosaur fossil at the centre, red mesas, acacia/baobab trees). Pick it in Lobby > MAP.
- Not compiled/run in the sandbox: please send any Unity compile errors.

## Stage 7
- Diamonds wallet (Wallet.cs), TOP UP panel (TEST MODE, free, no real payment), REDEEM and REFERRAL codes (referral ANSHUU = 10000 diamonds once), daily free SPIN WHEEL (extra spin 50 diamonds), 6 premium skins (rare/epic/legendary) bought with diamonds or won on the wheel.
- Everything is stored on-device and codes live in the app (no server): not abuse-proof. Real payments need Google Play Billing + a backend.
- Not compiled/run in the sandbox.
