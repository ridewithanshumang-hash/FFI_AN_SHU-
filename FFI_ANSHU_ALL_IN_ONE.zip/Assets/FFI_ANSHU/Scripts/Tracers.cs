using UnityEngine;

public class TracerDriver : MonoBehaviour
{
    public System.Action tick;
    void Update() { if (tick != null) tick(); }
}

/// <summary>Tiny pooled bullet-trail effect shared by the player and bots.</summary>
public static class Tracers
{
    const int N = 24;
    static Transform[] pool;
    static float[] endTime;
    static int idx;

    static void Init()
    {
        var root = new GameObject("Tracers");
        var mat = MapKit.Mat(new Color(1f, 0.9f, 0.5f), 0f);
        pool = new Transform[N];
        endTime = new float[N];
        for (int i = 0; i < N; i++)
        {
            var g = MapKit.Prim(PrimitiveType.Cube, root.transform, Vector3.zero, Vector3.one, mat, false);
            g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            g.SetActive(false);
            pool[i] = g.transform;
        }
        root.AddComponent<TracerDriver>().tick = Tick;
    }

    static void Tick()
    {
        for (int i = 0; i < N; i++)
            if (pool[i].gameObject.activeSelf && Time.time > endTime[i]) pool[i].gameObject.SetActive(false);
    }

    public static void Spawn(Vector3 a, Vector3 b)
    {
        if (pool == null || pool[0] == null) Init();
        Vector3 d = b - a;
        float len = d.magnitude;
        if (len < 0.1f) return;
        var t = pool[idx];
        endTime[idx] = Time.time + 0.06f;
        idx = (idx + 1) % N;
        t.position = a + d * 0.5f;
        t.rotation = Quaternion.LookRotation(d);
        t.localScale = new Vector3(0.035f, 0.035f, len);
        t.gameObject.SetActive(true);
    }
}
