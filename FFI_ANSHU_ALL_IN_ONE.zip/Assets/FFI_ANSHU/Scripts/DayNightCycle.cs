using UnityEngine;

/// <summary>Procedural sun/moon, sky, fog and ambient light with a day/night cycle.</summary>
public class DayNightCycle : MonoBehaviour
{
    public float dayLengthSeconds = 600f;
    [Range(0, 1)] public float timeOfDay = 0.36f;   // 0.25 sunrise, 0.5 noon, 0.75 sunset

    Light sun, moon;
    Material skyMat;
    Camera cam;

    static float Smooth(float a, float b, float x)
    {
        float t = Mathf.Clamp01((x - a) / (b - a));
        return t * t * (3 - 2 * t);
    }

    public static DayNightCycle Create(Camera cam)
    {
        foreach (var l in FindObjectsByType<Light>(FindObjectsSortMode.None))
            if (l.type == LightType.Directional) Destroy(l.gameObject);

        var go = new GameObject("DayNight");
        var d = go.AddComponent<DayNightCycle>();
        d.cam = cam;

        var sg = new GameObject("Sun");
        sg.transform.SetParent(go.transform);
        d.sun = sg.AddComponent<Light>();
        d.sun.type = LightType.Directional;
        d.sun.shadows = LightShadows.Soft;
        d.sun.shadowStrength = 0.85f;

        var mg = new GameObject("Moon");
        mg.transform.SetParent(go.transform);
        d.moon = mg.AddComponent<Light>();
        d.moon.type = LightType.Directional;
        d.moon.color = new Color(0.45f, 0.55f, 0.9f);
        d.moon.shadows = LightShadows.None;

        var sh = Shader.Find("Skybox/Procedural");
        if (sh != null)
        {
            d.skyMat = new Material(sh);
            RenderSettings.skybox = d.skyMat;
        }
        RenderSettings.sun = d.sun;
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogDensity = 0.0011f;
        d.Apply();
        return d;
    }

    void Update()
    {
        timeOfDay = (timeOfDay + Time.deltaTime / dayLengthSeconds) % 1f;
        Apply();
    }

    void Apply()
    {
        float angle = (timeOfDay - 0.25f) * 360f;
        float elev = Mathf.Sin((timeOfDay - 0.25f) * Mathf.PI * 2f);
        float day = Smooth(-0.08f, 0.22f, elev);

        sun.transform.rotation = Quaternion.Euler(angle, 150f, 0f);
        sun.intensity = Mathf.Lerp(0f, 1.3f, day);
        sun.color = Color.Lerp(new Color(1f, 0.5f, 0.25f), new Color(1f, 0.95f, 0.84f), Mathf.Clamp01(elev * 2.5f));
        sun.enabled = day > 0.01f;

        moon.transform.rotation = Quaternion.Euler(angle + 180f, 150f, 0f);
        moon.intensity = 0.35f * (1f - day);

        Color ambDay = new Color(0.62f, 0.58f, 0.52f);
        Color ambNight = new Color(0.04f, 0.05f, 0.10f);
        RenderSettings.ambientLight = Color.Lerp(ambNight, ambDay, day);

        Color fogDay = new Color(0.88f, 0.78f, 0.62f);
        Color fogNight = new Color(0.03f, 0.04f, 0.08f);
        Color fog = Color.Lerp(fogNight, fogDay, day);
        RenderSettings.fogColor = fog;

        if (skyMat != null)
        {
            skyMat.SetFloat("_Exposure", Mathf.Lerp(0.25f, 1.3f, day));
            skyMat.SetFloat("_AtmosphereThickness", 1.1f);
        }
        else
        {
            if (cam == null) cam = Camera.main;
            if (cam != null)
            {
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = Color.Lerp(new Color(0.02f, 0.03f, 0.08f), new Color(0.45f, 0.7f, 0.95f), day);
            }
        }
    }
}
