using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem.UI;
#endif

/// <summary>Small helpers for building menu UI from code.</summary>
public static class UiKit
{
    static Font font;
    public static Font Font
    {
        get
        {
            if (font == null) font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            return font;
        }
    }

    static void EnsureEventSystem()
    {
        if (UnityEngine.Object.FindFirstObjectByType<EventSystem>() != null) return;
        var es = new GameObject("EventSystem");
        es.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        var m = es.AddComponent<InputSystemUIInputModule>();
        m.AssignDefaultActions();
#else
        es.AddComponent<StandaloneInputModule>();
#endif
    }

    public static Canvas NewCanvas(string name)
    {
        EnsureEventSystem();
        var g = new GameObject(name);
        var cv = g.AddComponent<Canvas>();
        cv.renderMode = RenderMode.ScreenSpaceOverlay;
        var sc = g.AddComponent<CanvasScaler>();
        sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        sc.referenceResolution = new Vector2(1920, 1080);
        sc.matchWidthOrHeight = 0.5f;
        g.AddComponent<GraphicRaycaster>();
        return cv;
    }

    public static RectTransform Rect(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = go.GetComponent<RectTransform>();
        rt.SetParent(parent, false);
        return rt;
    }

    public static Image Box(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color c, bool raycast)
    {
        var rt = Rect(name, parent);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        var img = rt.gameObject.AddComponent<Image>();
        img.color = c;
        img.raycastTarget = raycast;
        return img;
    }

    public static Text Label(Transform parent, string s, int size, TextAnchor a)
    {
        var rt = Rect("Text", parent);
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        var t = rt.gameObject.AddComponent<Text>();
        t.font = Font; t.text = s; t.fontSize = size; t.alignment = a;
        t.color = Color.white; t.raycastTarget = false;
        return t;
    }

    public static Text LabelAt(Transform parent, string s, int size, TextAnchor a, Vector2 anchor, Vector2 pos, Vector2 sz)
    {
        var rt = Rect("Label", parent);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = sz;
        var t = rt.gameObject.AddComponent<Text>();
        t.font = Font; t.text = s; t.fontSize = size; t.alignment = a;
        t.color = Color.white; t.raycastTarget = false;
        return t;
    }

    public static Image Btn(Transform parent, string text, int fs, Vector2 anchor, Vector2 pos, Vector2 size, Color c, Action onClick)
    {
        var img = Box(text + "Btn", parent, anchor, pos, size, c, true);
        Label(img.transform, text, fs, TextAnchor.MiddleCenter);
        var tb = img.gameObject.AddComponent<TapButton>();
        tb.onDown = onClick;
        return img;
    }
}
