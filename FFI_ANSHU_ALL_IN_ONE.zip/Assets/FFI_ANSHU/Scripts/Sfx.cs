using UnityEngine;

/// <summary>All sound is synthesized at startup (no audio files): guns, steps, pickups, engine, wind and an original raga-style music loop.</summary>
public static class Sfx
{
    const int SR = 22050;
    public static AudioClip Step, Reload, Pickup, Hurt, EngineLoop;
    public static float SfxVolume = 0.8f;

    static AudioClip[] shots;
    static AudioClip wind, music;
    static AudioSource[] pool;
    static AudioSource musicSrc, windSrc;
    static GameObject root;
    static int pi;
    static bool generated;

    public static AudioClip Shot(int i) { return shots != null ? shots[Mathf.Clamp(i, 0, shots.Length - 1)] : null; }

    public static void Init()
    {
        if (!generated) { Generate(); generated = true; }
        if (root != null) return;
        root = new GameObject("Sfx");
        pool = new AudioSource[14];
        for (int i = 0; i < pool.Length; i++)
        {
            var g = new GameObject("S" + i);
            g.transform.SetParent(root.transform, false);
            var s = g.AddComponent<AudioSource>();
            s.playOnAwake = false;
            s.minDistance = 4f; s.maxDistance = 160f;
            s.rolloffMode = AudioRolloffMode.Linear;
            pool[i] = s;
        }
        musicSrc = MakeLoop("Music", music);
        windSrc = MakeLoop("Wind", wind);
        ApplyVolumes();
    }

    static AudioSource MakeLoop(string name, AudioClip c)
    {
        var g = new GameObject(name);
        g.transform.SetParent(root.transform, false);
        var s = g.AddComponent<AudioSource>();
        s.clip = c; s.loop = true; s.spatialBlend = 0f;
        s.Play();
        return s;
    }

    public static void ApplyVolumes()
    {
        SfxVolume = GameSettings.SfxVol;
        if (musicSrc != null) musicSrc.volume = GameSettings.MusicVol * 0.6f;
        if (windSrc != null) windSrc.volume = GameSettings.SfxVol * 0.2f;
    }

    public static void SetWindBoost(float k)
    {
        if (windSrc != null) windSrc.volume = GameSettings.SfxVol * (0.2f + 0.5f * k);
    }

    public static void Play(AudioClip c, Vector3 pos, float vol)
    {
        if (root == null || c == null) return;
        var s = pool[pi]; pi = (pi + 1) % pool.Length;
        s.transform.position = pos;
        s.spatialBlend = 1f;
        s.volume = vol * SfxVolume;
        s.pitch = Random.Range(0.95f, 1.05f);
        s.clip = c;
        s.Play();
    }

    public static void Play2D(AudioClip c, float vol)
    {
        if (root == null || c == null) return;
        var s = pool[pi]; pi = (pi + 1) % pool.Length;
        s.spatialBlend = 0f;
        s.volume = vol * SfxVolume;
        s.pitch = 1f;
        s.clip = c;
        s.Play();
    }

    // ---------------- synthesis ----------------
    static AudioClip Make(string name, float[] d)
    {
        var c = AudioClip.Create(name, d.Length, 1, SR, false);
        c.SetData(d, 0);
        return c;
    }

    static AudioClip Burst(string name, float dur, float lp, float thumpHz, float thump, float decay)
    {
        int n = (int)(SR * dur);
        var d = new float[n];
        float l = 0f;
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / SR;
            float env = Mathf.Exp(-t * decay);
            l += ((Random.value * 2f - 1f) - l) * lp;
            d[i] = Mathf.Clamp((l * 0.9f + Mathf.Sin(6.2832f * thumpHz * t) * thump) * env, -1f, 1f);
        }
        return Make(name, d);
    }

    static void Generate()
    {
        shots = new[]
        {
            Burst("pistol",  0.25f, 0.50f, 120f, 0.50f, 18f),
            Burst("smg",     0.18f, 0.60f, 150f, 0.35f, 28f),
            Burst("ar",      0.22f, 0.35f,  90f, 0.60f, 20f),
            Burst("shotgun", 0.50f, 0.20f,  60f, 0.90f,  9f),
        };
        Step = Burst("step", 0.12f, 0.12f, 70f, 0.6f, 35f);
        Hurt = Burst("hurt", 0.25f, 0.20f, 110f, 0.8f, 12f);

        int n = (int)(SR * 0.5f);
        var d = new float[n];
        float l = 0f;
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / SR;
            float e = Mathf.Exp(-t * 110f) + (t > 0.28f ? Mathf.Exp(-(t - 0.28f) * 110f) : 0f);
            l += ((Random.value * 2f - 1f) - l) * 0.7f;
            d[i] = l * e * 0.6f;
        }
        Reload = Make("reload", d);

        n = (int)(SR * 0.18f);
        d = new float[n];
        float ph = 0f;
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / SR;
            ph += 6.2832f * (600f + 600f * (t / 0.18f)) / SR;
            d[i] = Mathf.Sin(ph) * Mathf.Exp(-t * 10f) * 0.5f;
        }
        Pickup = Make("pickup", d);

        n = SR;   // 1 s loop, integer cycles
        d = new float[n];
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / SR;
            d[i] = (Mathf.Sin(6.2832f * 55f * t) * 0.5f + Mathf.Sin(6.2832f * 110f * t) * 0.3f + Mathf.Sin(6.2832f * 165f * t) * 0.2f) * 0.5f
                   + (Random.value * 2f - 1f) * 0.03f;
        }
        EngineLoop = Make("engine", d);

        n = SR * 4;
        d = new float[n];
        l = 0f;
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / SR;
            l += ((Random.value * 2f - 1f) - l) * 0.02f;
            d[i] = Mathf.Clamp(l * (0.6f + 0.4f * Mathf.Sin(6.2832f * t / 4f)) * 6f, -1f, 1f);
        }
        wind = Make("wind", d);

        music = MakeMusic();
    }

    static void Pluck(float[] d, int start, float freq, float len, float amp)
    {
        int m = (int)(len * SR);
        float w = 6.2832f * freq;
        for (int j = 0; j < m && start + j < d.Length; j++)
        {
            float t = (float)j / SR;
            float env = (1f - Mathf.Exp(-t * 400f)) * Mathf.Exp(-t * 3.5f);
            float s = Mathf.Sin(w * t) * 0.6f + Mathf.Sin(2f * w * t) * 0.3f + Mathf.Sin(3f * w * t) * 0.15f;
            d[start + j] += s * env * amp;
        }
    }

    static AudioClip MakeMusic()
    {
        // 96 bpm, 32 beats (20 s) loop, Bhairav-style scale (komal Re / komal Dha) over a tanpura-like drone
        float beat = 60f / 96f;
        int beats = 32;
        int n = (int)(SR * beat * beats);
        var d = new float[n];
        float sa = 293.66f;
        float[] ratio = { 1f, 16f / 15f, 5f / 4f, 4f / 3f, 3f / 2f, 8f / 5f, 15f / 8f, 2f };
        int[] mel = { 0, 2, 3, 4, 3, 2, 1, 0, 2, 3, 4, 5, 4, 3, 2, -1, 4, 5, 6, 7, 6, 5, 4, 3, 2, 3, 2, 1, 0, -1, -1, -1 };
        for (int b = 0; b < beats; b++)
        {
            int start = (int)(b * beat * SR);
            if (mel[b] >= 0) Pluck(d, start, sa * ratio[mel[b]], 0.9f, 0.35f);
            int km = (int)(0.15f * SR);
            for (int j = 0; j < km && start + j < n; j++)
            {
                float t = (float)j / SR;
                d[start + j] += Mathf.Sin(6.2832f * 65f * t) * Mathf.Exp(-t * 18f) * 0.25f;
            }
            int hs = start + (int)(beat * 0.5f * SR);
            int hm = (int)(0.05f * SR);
            for (int j = 0; j < hm && hs + j < n; j++)
                d[hs + j] += (Random.value * 2f - 1f) * Mathf.Exp(-((float)j / SR) * 220f) * 0.06f;
        }
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / SR;
            d[i] += (Mathf.Sin(6.2832f * 146.85f * t) * 0.06f + Mathf.Sin(6.2832f * 220.25f * t) * 0.045f);
        }
        float peak = 0.001f;
        for (int i = 0; i < n; i++) peak = Mathf.Max(peak, Mathf.Abs(d[i]));
        float g = 0.7f / peak;
        for (int i = 0; i < n; i++) d[i] *= g;
        return Make("music", d);
    }
}
