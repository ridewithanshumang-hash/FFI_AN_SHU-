using UnityEngine;

public class ThirdPersonCamera : MonoBehaviour
{
    public Transform target;
    public float Yaw;
    public float Pitch = 15f;
    public float distance = 4.3f;
    public float pivotHeight = 1.55f;
    public Vector3 shoulder = new Vector3(0.55f, 0.25f, 0f);
    public float minPitch = -30f, maxPitch = 70f;

    public float aimDistance = 2.6f;
    float curD;

    void Start() { Yaw = 0f; curD = distance; }

    public void AddRecoil(float kick) { Pitch -= kick; Yaw += Random.Range(-kick, kick) * 0.35f; }

    void LateUpdate()
    {
        if (target == null) return;

        Vector2 look = MobileInput.ConsumeLook();
        float scale = 0.12f * MobileInput.Sensitivity * (1920f / Mathf.Max(Screen.width, Screen.height));
        if (MobileInput.Aiming) scale *= 0.6f;
        Yaw += look.x * scale;
        Pitch -= look.y * scale;
#if ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetMouseButton(1))
        {
            Yaw += Input.GetAxis("Mouse X") * 3f * MobileInput.Sensitivity;
            Pitch -= Input.GetAxis("Mouse Y") * 3f * MobileInput.Sensitivity;
        }
#endif
        Pitch = Mathf.Clamp(Pitch, minPitch, maxPitch);

        var pc = target.GetComponent<PlayerController>();
        float ph = pivotHeight - (pc != null && pc.IsCrouching ? 0.4f : 0f);
        Vector3 pivot = target.position + Vector3.up * ph;
        Quaternion rot = Quaternion.Euler(Pitch, Yaw, 0);

        curD = Mathf.Lerp(curD, MobileInput.Aiming ? aimDistance : distance, 10f * Time.deltaTime);
        var camComp = GetComponent<Camera>();
        if (camComp != null) camComp.fieldOfView = Mathf.Lerp(camComp.fieldOfView, MobileInput.Aiming ? 48f : 62f, 10f * Time.deltaTime);
        Vector3 dir = rot * new Vector3(shoulder.x, shoulder.y, -curD);
        float len = dir.magnitude;
        dir /= len;
        float d = len;
        RaycastHit hit;
        if (Physics.SphereCast(pivot, 0.22f, dir, out hit, len, ~(1 << 2), QueryTriggerInteraction.Ignore))
            d = Mathf.Max(0.6f, hit.distance - 0.05f);

        transform.position = pivot + dir * d;
        transform.rotation = rot;
    }
}
