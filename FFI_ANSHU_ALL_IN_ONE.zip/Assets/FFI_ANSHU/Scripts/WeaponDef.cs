using UnityEngine;

public class WeaponDef
{
    public string name;
    public float damage, interval, reload, spread, range, recoil;
    public int mag, pellets = 1;
    public Color color;
    public Vector3 size;   // x = width, y = height, z = length of the placeholder gun model
}

/// <summary>Original weapon set (names and stats are our own).</summary>
public static class Weapons
{
    static Color C(int r, int g, int b) { return new Color(r / 255f, g / 255f, b / 255f); }

    public static readonly WeaponDef[] All =
    {
        new WeaponDef{ name="LOHA PISTOL",   damage=22f, interval=0.28f, reload=1.2f, spread=1.2f, range=80f,  recoil=1.2f, mag=12, pellets=1, color=C(60,60,66),   size=new Vector3(0.07f,0.11f,0.30f) },
        new WeaponDef{ name="THAR SMG",      damage=12f, interval=0.075f,reload=1.6f, spread=2.6f, range=60f,  recoil=0.5f, mag=30, pellets=1, color=C(50,70,90),   size=new Vector3(0.08f,0.12f,0.45f) },
        new WeaponDef{ name="MARUSTHAL AR",  damage=20f, interval=0.11f, reload=2.0f, spread=1.6f, range=120f, recoil=0.9f, mag=30, pellets=1, color=C(110,80,40),  size=new Vector3(0.08f,0.13f,0.75f) },
        new WeaponDef{ name="SHER SHOTGUN",  damage=11f, interval=0.85f, reload=2.2f, spread=5.0f, range=30f,  recoil=4.0f, mag=6,  pellets=8, color=C(120,40,30),  size=new Vector3(0.09f,0.12f,0.70f) },
    };
}
