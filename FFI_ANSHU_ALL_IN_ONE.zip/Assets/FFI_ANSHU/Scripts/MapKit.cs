using UnityEngine;

/// <summary>Primitive/material helpers and the wall-with-openings builder used for all architecture.</summary>
public static class MapKit
{
    static Shader _shader;

    public static Color C(int r, int g, int b) { return new Color(r / 255f, g / 255f, b / 255f); }

    public static Material Mat(Color c, float smooth = 0.05f)
    {
        if (_shader == null)
        {
            // Borrow the active render pipeline's default lit shader (works in Built-in and URP).
            var p = GameObject.CreatePrimitive(PrimitiveType.Cube);
            _shader = p.GetComponent<Renderer>().sharedMaterial.shader;
            Object.Destroy(p);
        }
        var m = new Material(_shader);
        m.color = c;
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
        return m;
    }

    public static GameObject Prim(PrimitiveType t, Transform parent, Vector3 localPos, Vector3 scale, Material mat, bool collider = true)
    {
        var g = GameObject.CreatePrimitive(t);
        g.transform.SetParent(parent, false);
        g.transform.localPosition = localPos;
        g.transform.localScale = scale;
        g.GetComponent<Renderer>().sharedMaterial = mat;
        if (!collider) Object.Destroy(g.GetComponent<Collider>());
        return g;
    }

    public static GameObject Box(Transform parent, Vector3 localPos, Vector3 size, Material mat)
    {
        return Prim(PrimitiveType.Cube, parent, localPos, size, mat);
    }

    // ---- Walls with door / window openings ----
    public struct Op
    {
        public float c, w, sill, top;
        public Op(float center, float width, float sillHeight, float topHeight)
        { c = center; w = width; sill = sillHeight; top = topHeight; }
    }

    /// <param name="mid">Bottom-centre of the wall in parent space.</param>
    public static void Wall(Transform p, Vector3 mid, bool alongX, float L, float H, float T, Material m, params Op[] ops)
    {
        System.Array.Sort(ops, (a, b) => a.c.CompareTo(b.c));
        float cur = -L * 0.5f;
        foreach (var o in ops)
        {
            float l = o.c - o.w * 0.5f, r = o.c + o.w * 0.5f;
            Piece(p, mid, alongX, cur, l, 0, H, T, m);
            if (o.sill > 0.01f) Piece(p, mid, alongX, l, r, 0, o.sill, T, m);
            if (o.top < H - 0.01f) Piece(p, mid, alongX, l, r, o.top, H, T, m);
            cur = r;
        }
        Piece(p, mid, alongX, cur, L * 0.5f, 0, H, T, m);
    }

    static void Piece(Transform p, Vector3 mid, bool alongX, float u0, float u1, float y0, float y1, float T, Material m)
    {
        if (u1 - u0 < 0.01f || y1 - y0 < 0.01f) return;
        float u = (u0 + u1) * 0.5f, y = (y0 + y1) * 0.5f;
        Vector3 pos = mid + (alongX ? new Vector3(u, y, 0) : new Vector3(0, y, u));
        Vector3 size = alongX ? new Vector3(u1 - u0, y1 - y0, T) : new Vector3(T, y1 - y0, u1 - u0);
        Box(p, pos, size, m);
    }
}
