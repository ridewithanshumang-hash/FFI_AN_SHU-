using UnityEngine;

public struct CharacterSkin
{
    public string name;
    public Color skin, shirt, pants, turban, sash;
    public int price;      // coins; 0 = free (unless diamonds > 0)
    public int diamonds;   // > 0: premium skin bought with diamonds
    public int rarity;     // 0 common, 1 rare, 2 epic, 3 legendary
}

/// <summary>Original outfits. Bought with coins earned in matches (lobby > CHARACTER).</summary>
public static class CharacterSkins
{
    static Color C(int r, int g, int b) { return new Color(r / 255f, g / 255f, b / 255f); }

    public static readonly CharacterSkin[] All =
    {
        new CharacterSkin{ name="Desert Nomad",    skin=C(176,120,84),  shirt=C(236,226,200), pants=C(120,90,60),  turban=C(214,60,40),  sash=C(250,190,40), price=0 },
        new CharacterSkin{ name="Fort Guard",      skin=C(150,98,68),   shirt=C(40,90,110),   pants=C(40,40,46),   turban=C(240,170,30), sash=C(180,30,30),  price=300 },
        new CharacterSkin{ name="Night Raider",    skin=C(190,140,100), shirt=C(35,35,45),    pants=C(25,25,30),   turban=C(20,20,24),   sash=C(110,40,160), price=500 },
        new CharacterSkin{ name="Royal Rani",      skin=C(200,150,110), shirt=C(160,30,90),   pants=C(230,190,60), turban=C(250,215,120),sash=C(30,130,120), price=450 },
        new CharacterSkin{ name="Jaipur Prince",   skin=C(200,150,110), shirt=C(236,120,160), pants=C(250,240,220),turban=C(230,60,110), sash=C(250,200,60), price=600 },
        new CharacterSkin{ name="Camel Rider",     skin=C(170,115,80),  shirt=C(80,120,70),   pants=C(110,90,55),  turban=C(240,220,170),sash=C(150,90,40),  price=700 },
        new CharacterSkin{ name="Desert Ghost",    skin=C(185,130,95),  shirt=C(215,215,210), pants=C(140,140,140),turban=C(240,240,240),sash=C(90,90,100),  price=900 },
        new CharacterSkin{ name="Golden Maharaja", skin=C(195,140,100), shirt=C(240,200,70),  pants=C(130,25,40),  turban=C(250,215,90), sash=C(20,100,160), price=1500 },
        // premium skins: diamonds, or won on the spin wheel
        new CharacterSkin{ name="Dune Phantom",     skin=C(180,125,90), shirt=C(60,70,110),  pants=C(30,35,60),    turban=C(120,160,255), sash=C(80,200,255),  diamonds=800,  rarity=1 },
        new CharacterSkin{ name="Fossil Hunter",    skin=C(172,118,82), shirt=C(120,100,70), pants=C(70,60,45),    turban=C(235,225,200), sash=C(200,160,90),  diamonds=1000, rarity=1 },
        new CharacterSkin{ name="Sandstorm Queen",  skin=C(200,150,110),shirt=C(120,40,160), pants=C(60,20,90),    turban=C(255,120,220), sash=C(255,215,80),  diamonds=1500, rarity=2 },
        new CharacterSkin{ name="Mirage Assassin",  skin=C(185,130,95), shirt=C(15,15,20),   pants=C(15,15,20),    turban=C(180,0,40),    sash=C(255,40,70),   diamonds=1800, rarity=2 },
        new CharacterSkin{ name="Kalahari Warlord", skin=C(150,95,65),  shirt=C(150,40,20),  pants=C(70,20,10),    turban=C(255,160,40),  sash=C(255,230,100), diamonds=2000, rarity=2 },
        new CharacterSkin{ name="Thar Emperor",     skin=C(205,150,105),shirt=C(255,200,40), pants=C(250,250,250), turban=C(255,230,120), sash=C(0,200,255),   diamonds=4000, rarity=3 },
    };

    public static readonly string[] RarityNames = { "COMMON", "RARE", "EPIC", "LEGENDARY" };
    public static Color RarityColor(int r)
    {
        switch (r)
        {
            case 1: return new Color(0.35f, 0.65f, 1f);
            case 2: return new Color(0.78f, 0.45f, 1f);
            case 3: return new Color(1f, 0.82f, 0.2f);
            default: return Color.white;
        }
    }

    public static int IndexOf(string name)
    {
        for (int i = 0; i < All.Length; i++) if (All[i].name == name) return i;
        return -1;
    }

    public static CharacterSkin Get(int i) { return All[Mathf.Clamp(i, 0, All.Length - 1)]; }

    public static bool Owned(int i)
    {
        i = Mathf.Clamp(i, 0, All.Length - 1);
        return (All[i].price == 0 && All[i].diamonds == 0) || PlayerPrefs.GetInt("own" + i, 0) == 1;
    }

    public static void Unlock(int i) { PlayerPrefs.SetInt("own" + i, 1); PlayerPrefs.Save(); }

    public static int OwnedCount()
    {
        int n = 0;
        for (int i = 0; i < All.Length; i++) if (Owned(i)) n++;
        return n;
    }
}
