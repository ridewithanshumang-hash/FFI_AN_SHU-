using UnityEngine;

/// <summary>Standing character model for the lobby (same look as the in-match player).</summary>
public static class Avatar
{
    static Transform Part(PrimitiveType t, Transform parent, Vector3 pos, Vector3 scale, Color c)
    {
        return MapKit.Prim(t, parent, pos, scale, MapKit.Mat(c, 0.15f), false).transform;
    }

    public static Transform Build(Transform parent, CharacterSkin s)
    {
        var rc = RiggedCharacter.Build(parent, s);
        rc.IdleAnim = true;
        return rc.Root;
    }
}
