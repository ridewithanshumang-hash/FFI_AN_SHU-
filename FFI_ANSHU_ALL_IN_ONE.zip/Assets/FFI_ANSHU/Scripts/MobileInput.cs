using UnityEngine;

/// <summary>Shared input state written by the touch HUD (or keyboard in editor) and read by gameplay.</summary>
public static class MobileInput
{
    public static Vector2 Move;          // left joystick, -1..1
    public static Vector2 LookDelta;     // accumulated right-side drag in pixels, consumed by camera
    public static bool JumpPressed;      // one-shot
    public static bool Crouching;        // toggled
    public static bool Sprinting;        // toggled
    public static bool Firing;           // held (either fire button)
    public static bool Aiming;           // toggled (aim down sights)
    public static bool ReloadPressed, SwitchPressed; // one-shots

    static float _sens = -1f;
    public static float Sensitivity
    {
        get { if (_sens < 0f) _sens = PlayerPrefs.GetFloat("sens", 1f); return _sens; }
        set { _sens = Mathf.Clamp(value, 0.3f, 3f); PlayerPrefs.SetFloat("sens", _sens); }
    }

    public static Vector2 ConsumeLook()
    {
        var l = LookDelta;
        LookDelta = Vector2.zero;
        return l;
    }

    public static bool ConsumeReload() { bool r = ReloadPressed; ReloadPressed = false; return r; }
    public static bool ConsumeSwitch() { bool r = SwitchPressed; SwitchPressed = false; return r; }

    public static bool ConsumeJump()
    {
        bool j = JumpPressed;
        JumpPressed = false;
        return j;
    }
}
