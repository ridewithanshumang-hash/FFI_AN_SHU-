using System.Collections.Generic;
using UnityEngine;

/// <summary>Drivable jeep: arcade movement that follows the ground, wall collision, run-over damage. Press DRIVE next to it.</summary>
public class Vehicle : MonoBehaviour
{
    public static Vehicle Driven;
    public static PlayerController Pc;
    public static ThirdPersonCamera Cam;
    public static readonly List<Vehicle> All = new List<Vehicle>();

    float speed, yawDeg, nextHit;
    readonly Transform[] spin = new Transform[4];
    readonly Transform[] steer = new Transform[2];
    AudioSource engine;
    Health playerHp;
    CharacterController cc;

    void Awake() { All.Add(this); }
    void OnDestroy() { All.Remove(this); if (Driven == this) Driven = null; }

    public static Vehicle Nearest(Vector3 p, float r)
    {
        Vehicle best = null;
        float bd = r * r;
        foreach (var v in All)
        {
            float d = (v.transform.position - p).sqrMagnitude;
            if (d < bd) { bd = d; best = v; }
        }
        return best;
    }

    public static void Toggle()
    {
        if (Pc == null) return;
        if (Driven != null) { Driven.Exit(); return; }
        if (Pc.Flying || Pc.Locked) return;
        var v = Nearest(Pc.transform.position, 4f);
        if (v != null) v.Enter();
    }

    public static Vehicle Create(Vector3 pos, float yaw, Color bodyCol)
    {
        var g = new GameObject("Vehicle");
        g.transform.position = pos;
        g.transform.rotation = Quaternion.Euler(0f, yaw, 0f);
        var v = g.AddComponent<Vehicle>();
        v.yawDeg = yaw;
        var t = g.transform;
        var body = MapKit.Mat(bodyCol, 0.35f);
        var dark = MapKit.Mat(new Color(0.08f, 0.08f, 0.1f), 0.1f);
        var glass = MapKit.Mat(new Color(0.25f, 0.4f, 0.5f), 0.6f);
        var lamp = MapKit.Mat(new Color(1f, 0.95f, 0.6f), 0f);
        var tail = MapKit.Mat(new Color(0.9f, 0.1f, 0.1f), 0f);

        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0f, 0.75f, 0f), new Vector3(2.0f, 0.6f, 4.2f), body, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0f, 1.35f, -0.3f), new Vector3(1.8f, 0.7f, 2.2f), body, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0f, 1.38f, 0.82f), new Vector3(1.7f, 0.5f, 0.1f), glass, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0f, 0.5f, 2.15f), new Vector3(2.1f, 0.2f, 0.2f), dark, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0f, 0.5f, -2.15f), new Vector3(2.1f, 0.2f, 0.2f), dark, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(-0.7f, 0.85f, 2.12f), new Vector3(0.3f, 0.2f, 0.1f), lamp, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0.7f, 0.85f, 2.12f), new Vector3(0.3f, 0.2f, 0.1f), lamp, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(-0.7f, 0.85f, -2.12f), new Vector3(0.3f, 0.2f, 0.1f), tail, false);
        MapKit.Prim(PrimitiveType.Cube, t, new Vector3(0.7f, 0.85f, -2.12f), new Vector3(0.3f, 0.2f, 0.1f), tail, false);

        int wi = 0;
        for (int sx = -1; sx <= 1; sx += 2)
            for (int sz = -1; sz <= 1; sz += 2)
            {
                var sp = new GameObject("WheelSteer").transform;
                sp.SetParent(t, false);
                sp.localPosition = new Vector3(sx * 1.05f, 0.4f, sz * 1.4f);
                var spinT = new GameObject("WheelSpin").transform;
                spinT.SetParent(sp, false);
                var m = MapKit.Prim(PrimitiveType.Cylinder, spinT, Vector3.zero, new Vector3(0.8f, 0.2f, 0.8f), dark, false);
                m.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                v.spin[wi] = spinT;
                if (sz > 0) v.steer[sx < 0 ? 0 : 1] = sp;
                wi++;
            }

        var bc = g.AddComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.center = new Vector3(0f, 1f, 0f);
        bc.size = new Vector3(2.2f, 2f, 4.4f);

        v.engine = g.AddComponent<AudioSource>();
        v.engine.clip = Sfx.EngineLoop;
        v.engine.loop = true;
        v.engine.playOnAwake = false;
        v.engine.spatialBlend = 1f;
        v.engine.rolloffMode = AudioRolloffMode.Linear;
        v.engine.maxDistance = 120f;
        return v;
    }

    void Enter()
    {
        cc = Pc.GetComponent<CharacterController>();
        playerHp = Pc.GetComponent<Health>();
        Driven = this;
        Pc.Flying = true;
        cc.enabled = false;
        Pc.Model.gameObject.SetActive(false);
        MobileInput.Aiming = false;
        Cam.distance = 8f;
        Cam.pivotHeight = 2.2f;
        yawDeg = transform.eulerAngles.y;
        speed = 0f;
        if (engine != null) engine.Play();
    }

    void Exit()
    {
        Vector3 p = transform.position + transform.right * 2.6f;
        RaycastHit h;
        if (Physics.Raycast(p + Vector3.up * 5f, Vector3.down, out h, 20f, ~(1 << 2), QueryTriggerInteraction.Ignore))
            p = h.point + Vector3.up * 0.1f;
        Pc.transform.position = p;
        cc.enabled = true;
        Pc.Flying = false;
        Pc.Model.gameObject.SetActive(true);
        Cam.distance = 4.3f;
        Cam.pivotHeight = 1.55f;
        if (engine != null) engine.Stop();
        speed = 0f;
        Driven = null;
    }

    void Update()
    {
        if (Driven != this) return;
        float dt = Time.deltaTime;
        if (playerHp.Dead) { Exit(); return; }

        Vector2 mv = MobileInput.Move;
#if ENABLE_LEGACY_INPUT_MANAGER
        mv = Vector2.ClampMagnitude(mv + new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), 1f);
        if (Input.GetKeyDown(KeyCode.Space)) MobileInput.JumpPressed = true;
#endif
        float target = mv.y * (mv.y > 0f ? 22f : 8f);
        float rate = Mathf.Abs(target) > Mathf.Abs(speed) ? 10f : 16f;
        speed = Mathf.MoveTowards(speed, target, rate * dt);
        if (MobileInput.ConsumeJump()) speed *= 0.4f;   // handbrake

        yawDeg += mv.x * 70f * Mathf.Clamp(speed / 6f, -1f, 1f) * dt;
        Quaternion yawQ = Quaternion.Euler(0f, yawDeg, 0f);
        Vector3 fwd = yawQ * Vector3.forward;

        float step = speed * dt;
        Vector3 pos = transform.position;
        if (Mathf.Abs(step) > 0.0001f)
        {
            Vector3 dir = fwd * Mathf.Sign(step);
            RaycastHit hit;
            if (Physics.SphereCast(pos + Vector3.up * 1f, 0.8f, dir, out hit, Mathf.Abs(step) + 1.6f, ~(1 << 2), QueryTriggerInteraction.Ignore)
                && hit.normal.y < 0.6f && hit.distance < Mathf.Abs(step) + 1.4f)
            {
                if (Mathf.Abs(speed) > 6f) Sfx.Play(Sfx.Hurt, pos, 0.8f);
                speed = -speed * 0.25f;
                step = 0f;
            }
            pos += fwd * step;
        }

        RaycastHit g;
        Quaternion rot = yawQ;
        if (Physics.Raycast(pos + Vector3.up * 3f, Vector3.down, out g, 12f, ~(1 << 2), QueryTriggerInteraction.Ignore))
        {
            pos.y = Mathf.Lerp(pos.y, g.point.y, 12f * dt);
            rot = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(Vector3.ProjectOnPlane(fwd, g.normal), g.normal), 8f * dt);
        }
        else pos.y -= 20f * dt;
        transform.position = pos;
        transform.rotation = rot;

        float spinDeg = speed * dt / 0.4f * Mathf.Rad2Deg;
        for (int i = 0; i < 4; i++) if (spin[i] != null) spin[i].Rotate(spinDeg, 0f, 0f, Space.Self);
        for (int i = 0; i < 2; i++) if (steer[i] != null) steer[i].localRotation = Quaternion.Euler(0f, mv.x * 30f, 0f);

        if (engine != null)
        {
            engine.pitch = 0.7f + Mathf.Abs(speed) / 22f * 1.2f;
            engine.volume = (0.25f + Mathf.Abs(speed) / 22f * 0.5f) * Sfx.SfxVolume;
        }

        // camera + player follow
        Pc.transform.position = pos;
        Pc.transform.rotation = rot;
        if (Mathf.Abs(speed) > 3f && MobileInput.LookDelta.sqrMagnitude < 1f)
            Cam.Yaw = Mathf.LerpAngle(Cam.Yaw, yawDeg, dt * 1.2f);

        // run-over damage
        if (Mathf.Abs(speed) > 6f && Time.time >= nextHit)
        {
            foreach (var h in Health.All)
            {
                if (h == null || h.Dead || h.IsPlayer) continue;
                if ((h.transform.position - pos).sqrMagnitude < 5.5f)
                {
                    h.Take(Mathf.Abs(speed) * 5f, Pc.gameObject);
                    nextHit = Time.time + 0.5f;
                    break;
                }
            }
        }
    }
}

public static class VehicleManager
{
    public static void Spawn(PlayerController pc, ThirdPersonCamera cam)
    {
        Vehicle.Pc = pc; Vehicle.Cam = cam; Vehicle.Driven = null;
        // x, z, yaw (0 = along +Z road, 90 = along +X road)
        float[,] spots =
        {
            { 404f, 380f, 0f }, { 396f, 460f, 0f }, { 410f, 495f, 0f }, { 250f, 303f, 90f }, { 480f, 297f, 90f },
            { 625f, 303f, 90f }, { 703f, 450f, 0f }, { 697f, 540f, 0f }, { 130f, 330f, 0f }, { 300f, 297f, 90f }
        };
        if (MapBuilder.Variant == 1)
            spots = new float[,]
            {
                { 404f, 300f, 0f }, { 396f, 380f, 0f }, { 300f, 280f, 60f }, { 520f, 270f, 70f }, { 400f, 470f, 0f },
                { 320f, 520f, 40f }, { 520f, 540f, 40f }, { 180f, 350f, 0f }, { 660f, 330f, 0f }, { 400f, 215f, 0f }
            };
        Color[] cols =
        {
            new Color(1f, 0.55f, 0.1f), new Color(0.15f, 0.4f, 0.8f), new Color(0.92f, 0.92f, 0.88f),
            new Color(0.7f, 0.15f, 0.15f), new Color(0.2f, 0.55f, 0.35f)
        };
        var root = new GameObject("Vehicles").transform;
        for (int i = 0; i < spots.GetLength(0); i++)
        {
            float x = spots[i, 0], z = spots[i, 1];
            float y = MapBuilder.Ground.SampleHeight(new Vector3(x, 0f, z)) + 0.1f;
            var v = Vehicle.Create(new Vector3(x, y, z), spots[i, 2], cols[i % cols.Length]);
            v.transform.SetParent(root, true);
        }
    }
}
