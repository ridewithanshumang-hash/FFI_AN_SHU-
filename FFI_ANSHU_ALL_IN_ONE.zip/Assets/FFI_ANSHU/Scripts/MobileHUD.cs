using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem.UI;
#endif

/// <summary>Builds the whole touch HUD in code: joystick, look pad, Jump / Crouch / Sprint, sensitivity, FPS.</summary>
public partial class MobileHUD : MonoBehaviour
{
    Font font;
    Sprite circle;
    Text fpsText, sensText;
    Image sprintImg, crouchImg;
    float fpsTimer; int frames;

    public static MobileHUD Create() { return new GameObject("HUD").AddComponent<MobileHUD>(); }

    void Awake()
    {
        font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        circle = MakeCircle();

        if (FindFirstObjectByType<EventSystem>() == null)
        {
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
            var m = es.AddComponent<InputSystemUIInputModule>();
            m.AssignDefaultActions();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        var cg = new GameObject("Canvas");
        cg.transform.SetParent(transform, false);
        var cv = cg.AddComponent<Canvas>();
        cv.renderMode = RenderMode.ScreenSpaceOverlay;
        var sc = cg.AddComponent<CanvasScaler>();
        sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        sc.referenceResolution = new Vector2(1920, 1080);
        sc.matchWidthOrHeight = 0.5f;
        cg.AddComponent<GraphicRaycaster>();
        Build(cg.transform);
    }

    // ---------- helpers ----------
    static Sprite MakeCircle()
    {
        int n = 128;
        var t = new Texture2D(n, n, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        float r = n * 0.5f;
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(r, r));
                float a = Mathf.Clamp01((r - 1f - d) / 2f);
                t.SetPixel(x, y, new Color(1, 1, 1, a));
            }
        t.Apply();
        return Sprite.Create(t, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
    }

    RectTransform NewRect(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = go.GetComponent<RectTransform>();
        rt.SetParent(parent, false);
        return rt;
    }

    RectTransform Zone(string name, Transform parent, Vector2 amin, Vector2 amax)
    {
        var rt = NewRect(name, parent);
        rt.anchorMin = amin; rt.anchorMax = amax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        rt.pivot = Vector2.zero;
        var img = rt.gameObject.AddComponent<Image>();
        img.color = new Color(0, 0, 0, 0);
        img.raycastTarget = true;
        return rt;
    }

    Image Disc(string name, Transform parent, Vector2 anchor, Vector2 pos, float size, Color c)
    {
        var rt = NewRect(name, parent);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(size, size);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = circle;
        img.color = c;
        return img;
    }

    Text Label(Transform parent, string s, int size, TextAnchor a)
    {
        var rt = NewRect("Text", parent);
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        var t = rt.gameObject.AddComponent<Text>();
        t.font = font; t.text = s; t.fontSize = size; t.alignment = a;
        t.color = Color.white; t.raycastTarget = false;
        return t;
    }

    Image Button(string name, string label, Vector2 anchor, Vector2 pos, float size, System.Action down, System.Action up = null, int fs = 30)
    {
        var img = Disc(name, transform.GetChild(0), anchor, pos, size, new Color(1, 1, 1, 0.35f));
        Label(img.transform, label, fs, TextAnchor.MiddleCenter);
        var b = img.gameObject.AddComponent<TapButton>();
        b.onDown = down; b.onUp = up;
        return img;
    }

    // ---------- layout ----------
    void Build(Transform root)
    {
        // Touch zones (added first => drawn/raycast underneath buttons)
        var left = Zone("MoveZone", root, new Vector2(0, 0), new Vector2(0.45f, 1));
        var right = Zone("LookZone", root, new Vector2(0.45f, 0), new Vector2(1, 1));
        right.gameObject.AddComponent<LookPad>();

        var jsBase = Disc("JoyBase", left, Vector2.zero, new Vector2(230, 230), 260, new Color(1, 1, 1, 0.25f));
        var jsKnob = Disc("JoyKnob", jsBase.transform, new Vector2(0.5f, 0.5f), Vector2.zero, 110, new Color(1, 1, 1, 0.6f));
        var js = left.gameObject.AddComponent<VirtualJoystick>();
        js.zone = left; js.baseRt = jsBase.rectTransform; js.knob = jsKnob.rectTransform;

        Vector2 br = new Vector2(1, 0);
        Button("Jump", "JUMP", br, new Vector2(-190, 190), 170, () => MobileInput.JumpPressed = true, null, 30);
        crouchImg = Button("Crouch", "CROUCH", br, new Vector2(-410, 110), 120, () => MobileInput.Crouching = !MobileInput.Crouching, null, 20);
        sprintImg = Button("Sprint", "SPRINT", br, new Vector2(-400, 290), 130, () => MobileInput.Sprinting = !MobileInput.Sprinting, null, 22);

        // Top-right: FPS + sensitivity
        var tr = new Vector2(1, 1);
        var fpsRt = NewRect("FPS", root);
        fpsRt.anchorMin = fpsRt.anchorMax = tr; fpsRt.pivot = tr;
        fpsRt.anchoredPosition = new Vector2(-20, -16); fpsRt.sizeDelta = new Vector2(300, 40);
        fpsText = Label(fpsRt, "FPS", 28, TextAnchor.MiddleRight);

        Button("SensMinus", "-", tr, new Vector2(-270, -110), 80, () => { MobileInput.Sensitivity -= 0.1f; UpdateSens(); }, null, 44);
        Button("SensPlus", "+", tr, new Vector2(-70, -110), 80, () => { MobileInput.Sensitivity += 0.1f; UpdateSens(); }, null, 44);
        var sRt = NewRect("Sens", root);
        sRt.anchorMin = sRt.anchorMax = tr; sRt.pivot = tr;
        sRt.anchoredPosition = new Vector2(-110, -70); sRt.sizeDelta = new Vector2(180, 80);
        sensText = Label(sRt, "", 24, TextAnchor.MiddleCenter);
        UpdateSens();

        // Title
        var tl = new Vector2(0, 1);
        var tRt = NewRect("Title", root);
        tRt.anchorMin = tRt.anchorMax = tl; tRt.pivot = tl;
        tRt.anchoredPosition = new Vector2(24, -16); tRt.sizeDelta = new Vector2(600, 40);
        Label(tRt, "FFI_ANSHU  -  Prototype 0.2", 26, TextAnchor.MiddleLeft);
        BuildCombat(root);
    }

    void UpdateSens() { sensText.text = "SENS " + MobileInput.Sensitivity.ToString("0.0"); }

    void Update()
    {
        sprintImg.color = new Color(1, 0.8f, 0.2f, MobileInput.Sprinting ? 0.85f : 0.35f);
        crouchImg.color = new Color(0.3f, 0.8f, 1f, MobileInput.Crouching ? 0.85f : 0.35f);

        UpdateCombat();
        frames++; fpsTimer += Time.unscaledDeltaTime;
        if (fpsTimer >= 0.5f)
        {
            fpsText.text = Mathf.RoundToInt(frames / fpsTimer) + " FPS";
            frames = 0; fpsTimer = 0f;
        }
    }
}
