using UnityEngine;
using UnityEngine.UI;

/// <summary>Minimap: generated from the map height/road data, with player dot, current zone ring and next-zone ring.</summary>
public partial class MobileHUD
{
    const float MapPx = 230f;
    RectTransform mapPlayer, mapZone, mapNext;
    Sprite ringSprite;

    static Sprite MakeRing()
    {
        int n = 128;
        var t = new Texture2D(n, n, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        float r = n * 0.5f;
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(r, r));
                float a = Mathf.Clamp01(1f - Mathf.Abs(d - (r - 3f)) / 1.5f);
                t.SetPixel(x, y, new Color(1f, 1f, 1f, a));
            }
        t.Apply();
        return Sprite.Create(t, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
    }

    RectTransform Ring(Transform parent, Color c)
    {
        var rt = NewRect("Ring", parent);
        rt.anchorMin = rt.anchorMax = Vector2.zero;
        rt.pivot = new Vector2(0.5f, 0.5f);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = ringSprite; img.color = c; img.raycastTarget = false;
        return rt;
    }

    void BuildMap(Transform root)
    {
        int n = 128;
        var tex = new Texture2D(n, n, TextureFormat.RGB24, false);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float wx = (x + 0.5f) / n * MapBuilder.Size, wz = (y + 0.5f) / n * MapBuilder.Size;
                float h = MapBuilder.Height(wx, wz);
                Color c = MapBuilder.Variant == 1
                    ? Color.Lerp(new Color(0.78f, 0.36f, 0.20f), new Color(0.50f, 0.22f, 0.14f), Mathf.Clamp01((h - 8f) / 50f))
                    : Color.Lerp(new Color(0.93f, 0.80f, 0.52f), new Color(0.72f, 0.52f, 0.30f), Mathf.Clamp01((h - 8f) / 50f));
                if (h < 5f) c = new Color(0.25f, 0.30f, 0.40f);
                else if (MapBuilder.InSettlement(wx, wz)) c = new Color(0.95f, 0.65f, 0.25f);
                if (MapBuilder.RoadDistance(wx, wz) < 5f && h >= 5f) c = new Color(0.45f, 0.33f, 0.22f);
                tex.SetPixel(x, y, c);
            }
        tex.Apply();

        var frame = NewRect("MiniMap", root);
        frame.anchorMin = frame.anchorMax = new Vector2(0f, 1f);
        frame.pivot = new Vector2(0f, 1f);
        frame.anchoredPosition = new Vector2(24, -150);
        frame.sizeDelta = new Vector2(MapPx, MapPx);
        var bg = frame.gameObject.AddComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.6f); bg.raycastTarget = false;
        frame.gameObject.AddComponent<RectMask2D>();
        var imgRt = NewRect("MapImg", frame);
        imgRt.anchorMin = Vector2.zero; imgRt.anchorMax = Vector2.one;
        imgRt.offsetMin = imgRt.offsetMax = Vector2.zero;
        var raw = imgRt.gameObject.AddComponent<RawImage>();
        raw.texture = tex; raw.raycastTarget = false;

        ringSprite = MakeRing();
        mapZone = Ring(frame, new Color(0.3f, 0.6f, 1f, 1f));
        mapNext = Ring(frame, Color.white);
        var pd = Disc("You", frame, Vector2.zero, Vector2.zero, 14, new Color(1f, 0.2f, 0.2f, 1f));
        pd.raycastTarget = false;
        mapPlayer = pd.rectTransform;
    }

    void UpdateMap()
    {
        var w = WeaponController.Instance;
        if (w == null || mapPlayer == null) return;
        float k = MapPx / MapBuilder.Size;
        Vector3 p = w.transform.position;
        mapPlayer.anchoredPosition = new Vector2(p.x * k, p.z * k);
        var z = SafeZone.Instance;
        if (z == null) return;
        mapZone.anchoredPosition = new Vector2(z.Center.x * k, z.Center.z * k);
        mapZone.sizeDelta = Vector2.one * (z.Radius * 2f * k);
        bool show = z.ShowNext;
        if (mapNext.gameObject.activeSelf != show) mapNext.gameObject.SetActive(show);
        if (show)
        {
            mapNext.anchoredPosition = new Vector2(z.NextCenter.x * k, z.NextCenter.y * k);
            mapNext.sizeDelta = Vector2.one * (z.NextRadius * 2f * k);
        }
    }
}
