using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Procedural Jaisalmer-inspired 800x800m desert map: dunes, edge mountains, a canyon with a bridge,
/// a big fort, a bazaar town, three villages, roads, market stalls, trees and rocks.
/// </summary>
public static partial class MapBuilder
{
    public const float Size = 800f, MaxH = 90f, FlatH = 10f, BridgeZ = 300f;

    struct Zone { public Vector2 c; public float r; public Zone(float x, float z, float rad) { c = new Vector2(x, z); r = rad; } }
    struct Seg { public Vector2 a, b; public Seg(float ax, float az, float bx, float bz) { a = new Vector2(ax, az); b = new Vector2(bx, bz); } }

    static readonly List<Zone> zones = new List<Zone>();
    static readonly List<Seg> roads = new List<Seg>();
    public static Terrain Ground;
    public static int Variant;   // 0 = Jaisalmer, 1 = Kalahari
    public static Vector3 SpawnPos = new Vector3(400f, FlatH + 0.15f, 330f);
    public static Vector2 HotSpot = new Vector2(400f, 560f);

    static void InitData()
    {
        zones.Clear(); roads.Clear();
        if (Variant == 1) { InitKalahari(); return; }
        SpawnPos = new Vector3(400f, FlatH + 0.15f, 330f);
        HotSpot = new Vector2(400f, 560f);
        zones.Add(new Zone(400, 560, 90));  // Fort
        zones.Add(new Zone(400, 300, 75));  // Sonar Bazaar town
        zones.Add(new Zone(130, 300, 55));  // West village
        zones.Add(new Zone(700, 300, 55));  // East village
        zones.Add(new Zone(700, 600, 55));  // North-east village
        roads.Add(new Seg(400, 505, 400, 300));
        roads.Add(new Seg(400, 300, 130, 300));
        roads.Add(new Seg(400, 300, 700, 300));
        roads.Add(new Seg(700, 300, 700, 600));
    }

    static float CanyonX(float z) { return Variant == 1 ? -1000f : 560f + Mathf.Sin(z * 0.01f) * 15f; }

    static float Smooth(float a, float b, float x)
    {
        float t = Mathf.Clamp01((x - a) / (b - a));
        return t * t * (3f - 2f * t);
    }

    static Vector2 NearestOnSeg(Vector2 p, Seg s)
    {
        Vector2 ab = s.b - s.a;
        float t = Mathf.Clamp01(Vector2.Dot(p - s.a, ab) / ab.sqrMagnitude);
        return s.a + ab * t;
    }

    static float RoadDist(Vector2 p)
    {
        float m = 9999f;
        foreach (var s in roads) m = Mathf.Min(m, (p - NearestOnSeg(p, s)).magnitude);
        return m;
    }

    static Vector2 NearestRoadVec(Vector2 p)
    {
        float m = 9999f; Vector2 best = Vector2.up;
        foreach (var s in roads)
        {
            Vector2 q = NearestOnSeg(p, s) - p;
            if (q.magnitude < m) { m = q.magnitude; best = q; }
        }
        return best;
    }

    static bool InZone(Vector2 p, float scale)
    {
        foreach (var z in zones) if ((p - z.c).magnitude < z.r * scale) return true;
        return false;
    }

    /// <summary>True for open ground (not in a settlement, canyon or map edge). Used for bot spawns.</summary>
    public static bool IsOpen(float x, float z)
    {
        var p = new Vector2(x, z);
        float edge = Mathf.Min(Mathf.Min(x, Size - x), Mathf.Min(z, Size - z));
        return !InZone(p, 1.2f) && Mathf.Abs(x - CanyonX(z)) > 25f && edge > 110f;
    }

    public static float RoadDistance(float x, float z) { return RoadDist(new Vector2(x, z)); }
    public static bool InSettlement(float x, float z) { return InZone(new Vector2(x, z), 1f); }

    public static float Height(float x, float z)
    {
        float h = 8f + Mathf.PerlinNoise(x * 0.008f + 11.3f, z * 0.008f + 4.7f) * 16f
                     + Mathf.PerlinNoise(x * 0.035f, z * 0.035f) * 3f;
        float edge = Mathf.Min(Mathf.Min(x, Size - x), Mathf.Min(z, Size - z));
        if (Variant == 1) h += (Mathf.Sin((x * 0.6f + z * 0.8f) * 0.045f + Mathf.PerlinNoise(x * 0.01f, z * 0.01f) * 4f) * 0.5f + 0.5f) * 7f;
        float m = 1f - Smooth(0f, 90f, edge);
        h += m * (25f + Mathf.PerlinNoise(x * 0.02f + 50f, z * 0.02f) * 30f);

        float cm = (1f - Smooth(7f, 16f, Mathf.Abs(x - CanyonX(z)))) * (1f - m);
        h = Mathf.Lerp(h, 2f, cm);

        Vector2 p = new Vector2(x, z);
        foreach (var zn in zones)
        {
            float mask = 1f - Smooth(zn.r * 0.85f, zn.r * 1.25f, (p - zn.c).magnitude);
            h = Mathf.Lerp(h, FlatH, mask * (1f - cm));
        }
        float rm = 1f - Smooth(7f, 13f, RoadDist(p));
        h = Mathf.Lerp(h, FlatH, rm * (1f - cm));
        return Mathf.Min(h, MaxH - 1f);
    }

    // ---------------- textures ----------------
    static Texture2D TileTex(Color a, Color b, float freq, int n)
    {
        var t = new Texture2D(n, n, TextureFormat.RGB24, true);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float v = Tile(x * freq / n, y * freq / n, freq) * 0.65f + Tile(x * freq * 4f / n, y * freq * 4f / n, freq * 4f) * 0.35f;
                t.SetPixel(x, y, Color.Lerp(a, b, v));
            }
        t.wrapMode = TextureWrapMode.Repeat;
        t.Apply();
        return t;
    }

    static float PN(float x, float y) { return Mathf.PerlinNoise(x + 100f, y + 100f); }

    // seamless tiling by blending 4 shifted samples
    static float Tile(float x, float y, float w)
    {
        return (PN(x, y) * (w - x) * (w - y) + PN(x - w, y) * x * (w - y) + PN(x, y - w) * (w - x) * y + PN(x - w, y - w) * x * y) / (w * w);
    }

    static Terrain BuildTerrain(Transform parent)
    {
        const int res = 513, ar = 512;
        var td = new TerrainData();
        td.heightmapResolution = res;
        td.size = new Vector3(Size, MaxH, Size);
        var hs = new float[res, res];
        for (int z = 0; z < res; z++)
            for (int x = 0; x < res; x++)
                hs[z, x] = Height(x / (res - 1f) * Size, z / (res - 1f) * Size) / MaxH;
        td.SetHeights(0, 0, hs);

        var sand = new TerrainLayer { diffuseTexture = Variant == 1 ? TileTex(MapKit.C(176, 78, 44), MapKit.C(206, 104, 60), 6f, 128) : TileTex(MapKit.C(214, 176, 112), MapKit.C(238, 206, 140), 6f, 128), tileSize = new Vector2(12, 12) };
        var road = new TerrainLayer { diffuseTexture = Variant == 1 ? TileTex(MapKit.C(110, 52, 34), MapKit.C(138, 70, 44), 6f, 128) : TileTex(MapKit.C(120, 96, 70), MapKit.C(150, 122, 90), 6f, 128), tileSize = new Vector2(8, 8) };
        td.terrainLayers = new[] { sand, road };

        td.alphamapResolution = ar;
        var a = new float[ar, ar, 2];
        for (int z = 0; z < ar; z++)
            for (int x = 0; x < ar; x++)
            {
                var p = new Vector2((x + 0.5f) / ar * Size, (z + 0.5f) / ar * Size);
                float rw = 1f - Smooth(4.5f, 7f, RoadDist(p));
                a[z, x, 0] = 1f - rw; a[z, x, 1] = rw;
            }
        td.SetAlphamaps(0, 0, a);

        var go = Terrain.CreateTerrainGameObject(td);
        go.name = "Terrain";
        go.transform.SetParent(parent, false);
        var t = go.GetComponent<Terrain>();
        t.heightmapPixelError = 10f;
        t.basemapDistance = 250f;
        t.drawInstanced = true;
        return t;
    }

    // ---------------- build ----------------
    public static GameObject Build()
    {
        InitData();
        Buildings.LootSpots.Clear();
        var root = new GameObject("Map");
        Ground = BuildTerrain(root.transform);

        var structures = new GameObject("Structures").transform;
        structures.SetParent(root.transform, false);

        var gold = MapKit.Mat(MapKit.C(228, 182, 98));
        var goldTrim = MapKit.Mat(MapKit.C(178, 118, 58));
        var mud = MapKit.Mat(MapKit.C(200, 150, 100));
        var terra = MapKit.Mat(MapKit.C(158, 80, 48));
        var floorM = MapKit.Mat(MapKit.C(190, 160, 120));

        if (Variant == 1) BuildKalahari(structures);
        else
        {
        Fort(structures, gold, goldTrim, floorM);
        Settlement(structures, new Vector2(400, 300), 58f, 26f, true, gold, goldTrim, floorM);
        Settlement(structures, new Vector2(130, 300), 38f, 24f, false, mud, terra, floorM);
        Settlement(structures, new Vector2(700, 300), 38f, 24f, false, mud, terra, floorM);
        Settlement(structures, new Vector2(700, 600), 38f, 24f, true, gold, terra, floorM);
        Market(structures);
        Bridge(structures, goldTrim);
        }
        StaticBatchingUtility.Combine(structures.gameObject);

        var nature = new GameObject("Nature").transform;
        nature.SetParent(root.transform, false);
        if (Variant == 1) NatureKalahari(nature); else Nature(nature);
        StaticBatchingUtility.Combine(nature.gameObject);
        return root;
    }

    static float Pick(params float[] v) { return v[Random.Range(0, v.Length)]; }

    static void Settlement(Transform parent, Vector2 c, float r, float step, bool big, Material wall, Material trim, Material floorM)
    {
        int n = Mathf.RoundToInt(r / step);
        for (int gx = -n; gx <= n; gx++)
            for (int gz = -n; gz <= n; gz++)
            {
                Vector2 p = c + new Vector2(gx, gz) * step + new Vector2(Random.Range(-2f, 2f), Random.Range(-2f, 2f));
                if ((p - c).magnitude > r) continue;
                if (RoadDist(p) < 13f) continue;
                float w = Pick(7f, 8f, 9f), d = Pick(7f, 9f, 10f);
                int fl = (big && w >= 8f && d >= 9f && Random.value < 0.5f) ? 2 : 1;
                Vector2 v = NearestRoadVec(p);
                float yaw = Mathf.Round(Mathf.Atan2(-v.x, -v.y) * Mathf.Rad2Deg / 90f) * 90f;
                Buildings.House(parent, new Vector3(p.x, FlatH, p.y), yaw, w, d, fl, wall, trim, floorM);
            }
    }

    static void Fort(Transform parent, Material wall, Material trim, Material floorM)
    {
        const float half = 50f, H = 9f, T = 2.5f;
        float L = 2 * half + T;
        var root = new GameObject("Fort").transform;
        root.SetParent(parent, false);
        root.position = new Vector3(400, FlatH, 560);

        MapKit.Wall(root, new Vector3(0, 0, -half), true, L, H, T, wall, new MapKit.Op(0, 10f, 0, 7f)); // south wall + gate
        MapKit.Wall(root, new Vector3(0, 0, half), true, L, H, T, wall);
        MapKit.Wall(root, new Vector3(half, 0, 0), false, L, H, T, wall);
        MapKit.Wall(root, new Vector3(-half, 0, 0), false, L, H, T, wall);
        MapKit.Box(root, new Vector3(0, 7.3f, -half), new Vector3(11f, 0.6f, T + 0.4f), trim);

        for (float u = -half; u <= half; u += 3f)
        {
            MapKit.Box(root, new Vector3(u, H + 0.6f, -half), new Vector3(1.4f, 1.2f, T * 0.5f), wall);
            MapKit.Box(root, new Vector3(u, H + 0.6f, half), new Vector3(1.4f, 1.2f, T * 0.5f), wall);
            MapKit.Box(root, new Vector3(-half, H + 0.6f, u), new Vector3(T * 0.5f, 1.2f, 1.4f), wall);
            MapKit.Box(root, new Vector3(half, H + 0.6f, u), new Vector3(T * 0.5f, 1.2f, 1.4f), wall);
        }

        float[] cs = { -half, half };
        foreach (float tx in cs)
            foreach (float tz in cs)
            {
                MapKit.Prim(PrimitiveType.Cylinder, root, new Vector3(tx, 6.5f, tz), new Vector3(10f, 6.5f, 10f), wall);
                MapKit.Prim(PrimitiveType.Sphere, root, new Vector3(tx, 13f, tz), new Vector3(9f, 4f, 9f), trim);
                MapKit.Prim(PrimitiveType.Cylinder, root, new Vector3(tx, 17f, tz), new Vector3(0.3f, 1.5f, 0.3f), trim, false);
            }

        // Courtyard well
        MapKit.Prim(PrimitiveType.Cylinder, root, new Vector3(0, 0.5f, -12), new Vector3(3f, 0.5f, 3f), trim);

        Vector3 fc = root.position;
        Buildings.House(parent, fc + new Vector3(0, 0, 30), 0, 22f, 14f, 2, wall, trim, floorM); // palace
        float[] zs = { -20f, 5f, 30f };
        foreach (float z in zs)
        {
            Buildings.House(parent, fc + new Vector3(-36, 0, z), -90, 8f, 9f, 1, wall, trim, floorM);
            Buildings.House(parent, fc + new Vector3(36, 0, z), 90, 8f, 9f, 1, wall, trim, floorM);
        }
        Buildings.House(parent, fc + new Vector3(-20, 0, -36), 180, 8f, 9f, 2, wall, trim, floorM);
        Buildings.House(parent, fc + new Vector3(20, 0, -36), 180, 8f, 9f, 2, wall, trim, floorM);
    }

    static void Market(Transform parent)
    {
        Material[] cans =
        {
            MapKit.Mat(MapKit.C(240,150,30)), MapKit.Mat(MapKit.C(190,40,40)),
            MapKit.Mat(MapKit.C(30,140,140)), MapKit.Mat(MapKit.C(240,230,200))
        };
        var wood = MapKit.Mat(MapKit.C(110, 70, 40));
        int k = 0;
        for (int side = -1; side <= 1; side += 2)
            for (float z = 330f; z <= 480f; z += 12f)
            {
                Vector3 p = new Vector3(400f + side * 9f, 0, z);
                p.y = Ground.SampleHeight(p);
                MapKit.Box(parent, p + new Vector3(0, 0.5f, 0), new Vector3(3f, 1f, 1.4f), wood);
                MapKit.Box(parent, p + new Vector3(0, 2.4f, 0), new Vector3(3.6f, 0.12f, 2.4f), cans[k++ % cans.Length]);
                foreach (float sx in new[] { -1.6f, 1.6f })
                    foreach (float sz in new[] { -1f, 1f })
                        MapKit.Prim(PrimitiveType.Cube, parent, p + new Vector3(sx, 1.2f, sz), new Vector3(0.1f, 2.4f, 0.1f), wood, false);
            }
    }

    static void Bridge(Transform parent, Material stone)
    {
        float cx = CanyonX(BridgeZ);
        var root = new GameObject("Bridge").transform;
        root.SetParent(parent, false);
        MapKit.Box(root, new Vector3(cx, FlatH - 0.25f, BridgeZ), new Vector3(38f, 0.5f, 7f), stone);
        MapKit.Box(root, new Vector3(cx, FlatH + 0.5f, BridgeZ - 3.4f), new Vector3(38f, 1f, 0.3f), stone);
        MapKit.Box(root, new Vector3(cx, FlatH + 0.5f, BridgeZ + 3.4f), new Vector3(38f, 1f, 0.3f), stone);
        foreach (float dx in new[] { -9f, 0f, 9f })
            MapKit.Box(root, new Vector3(cx + dx, (FlatH - 0.5f + 2f) * 0.5f, BridgeZ), new Vector3(1.6f, FlatH - 2.5f, 6f), stone);
    }

    static void Nature(Transform parent)
    {
        var trunk = MapKit.Mat(MapKit.C(100, 72, 46));
        var leaf = MapKit.Mat(MapKit.C(120, 128, 60));
        var shrub = MapKit.Mat(MapKit.C(140, 130, 70));
        Material[] rocks =
        {
            MapKit.Mat(MapKit.C(180,140,96)), MapKit.Mat(MapKit.C(150,112,80)), MapKit.Mat(MapKit.C(200,165,115))
        };

        for (int i = 0; i < 450; i++)
        {
            float x = Random.Range(40f, Size - 40f), z = Random.Range(40f, Size - 40f);
            Vector2 p = new Vector2(x, z);
            if (InZone(p, 1.3f) || RoadDist(p) < 14f || Mathf.Abs(x - CanyonX(z)) < 22f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0, z));
            float s = Random.Range(0.8f, 1.5f);
            MapKit.Prim(PrimitiveType.Cylinder, parent, new Vector3(x, y + 1.5f * s, z), new Vector3(0.5f * s, 1.5f * s, 0.5f * s), trunk);
            MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x, y + 3.6f * s, z), new Vector3(5f * s, 2.6f * s, 5f * s), leaf, false);
        }
        for (int i = 0; i < 260; i++)
        {
            float x = Random.Range(30f, Size - 30f), z = Random.Range(30f, Size - 30f);
            Vector2 p = new Vector2(x, z);
            if (InZone(p, 1.2f) || RoadDist(p) < 12f || Mathf.Abs(x - CanyonX(z)) < 20f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0, z));
            float s = Random.Range(1f, 4.5f);
            var g = MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x, y + s * 0.2f, z), new Vector3(s, s * 0.6f, s * 0.8f), rocks[Random.Range(0, rocks.Length)]);
            g.transform.rotation = Quaternion.Euler(Random.Range(-8f, 8f), Random.Range(0f, 360f), Random.Range(-8f, 8f));
        }
        for (int i = 0; i < 300; i++)
        {
            float x = Random.Range(30f, Size - 30f), z = Random.Range(30f, Size - 30f);
            if (InZone(new Vector2(x, z), 1.1f) || RoadDist(new Vector2(x, z)) < 8f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0, z));
            MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x, y + 0.3f, z), new Vector3(1.2f, 0.7f, 1.2f), shrub, false);
        }
    }
}
