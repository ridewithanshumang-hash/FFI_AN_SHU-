using UnityEngine;

/// <summary>Fire, aim (ADS), reload, weapon swap, hit detection and damage for the player.</summary>
public class WeaponController : MonoBehaviour
{
    public static WeaponController Instance;
    public Health Hp;
    public event System.Action HitConfirmed;

    ThirdPersonCamera cam;
    PlayerController pc;
    int cur;
    int[] ammo, reserve;
    bool[] owned;
    float nextFire, reloadEnd, flashEnd;
    bool reloading;
    Transform gun, muzzle;
    Material gunMat;
    GameObject flash;

    public WeaponDef Current { get { return Weapons.All[cur]; } }
    public int Ammo { get { return ammo[cur]; } }
    public bool Reloading { get { return reloading; } }
    public int Reserve { get { return reserve[cur]; } }
    public int Cur { get { return cur; } }
    public bool Owned(int i) { return owned[i]; }
    public int AmmoOf(int i) { return ammo[i]; }
    public int ReserveOf(int i) { return reserve[i]; }

    public void Equip(int i)
    {
        if (!owned[i] || i == cur) return;
        cur = i; reloading = false; ApplyGun(); nextFire = Time.time + 0.3f;
    }

    /// <summary>Returns true if the weapon was new.</summary>
    public bool GiveWeapon(int i)
    {
        if (owned[i]) { reserve[i] += Weapons.All[i].mag; return false; }
        owned[i] = true;
        ammo[i] = Weapons.All[i].mag;
        reserve[i] += Weapons.All[i].mag * 2;
        Equip(i);
        return true;
    }

    public void AddAmmoAll()
    {
        for (int i = 0; i < owned.Length; i++) if (owned[i]) reserve[i] += Weapons.All[i].mag * 2;
    }

    public void Init(ThirdPersonCamera c, PlayerController p)
    {
        Instance = this;
        cam = c; pc = p;
        Hp = GetComponent<Health>();
        ammo = new int[Weapons.All.Length];
        for (int i = 0; i < ammo.Length; i++) ammo[i] = Weapons.All[i].mag;
        reserve = new int[ammo.Length];
        owned = new bool[ammo.Length];
        owned[0] = true;
        reserve[0] = 36;
        BuildGun();
        ApplyGun();
        Hp.OnDied += OnDied;
    }

    void BuildGun()
    {
        gunMat = MapKit.Mat(Color.gray, 0.3f);
        gun = MapKit.Prim(PrimitiveType.Cube, pc.Model, Vector3.zero, Vector3.one, gunMat, false).transform;
        MapKit.Prim(PrimitiveType.Cube, gun, new Vector3(0f, -0.9f, 0.15f), new Vector3(0.8f, 1.2f, 0.15f), gunMat, false);
        muzzle = new GameObject("Muzzle").transform;
        muzzle.SetParent(pc.Model, false);
        flash = MapKit.Prim(PrimitiveType.Sphere, muzzle, Vector3.zero, new Vector3(0.18f, 0.18f, 0.18f),
                            MapKit.Mat(new Color(1f, 0.85f, 0.3f), 0f), false);
        flash.SetActive(false);
    }

    void ApplyGun()
    {
        var d = Current;
        gunMat.color = d.color;
        gun.localScale = d.size;
        float len = d.size.z;
        gun.localPosition = new Vector3(0.28f, 1.2f, 0.2f + len * 0.5f);
        muzzle.localPosition = new Vector3(0.28f, 1.22f, 0.2f + len + 0.04f);
    }

    void Update()
    {
        if (Hp == null || Hp.Dead || pc.Flying) return;
        if (flash.activeSelf && Time.time > flashEnd) flash.SetActive(false);

        bool fire = MobileInput.Firing;
#if ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetKey(KeyCode.F)) fire = true;
        if (Input.GetKeyDown(KeyCode.R)) MobileInput.ReloadPressed = true;
        if (Input.GetKeyDown(KeyCode.Q)) MobileInput.SwitchPressed = true;
        if (Input.GetKeyDown(KeyCode.E)) MobileInput.Aiming = !MobileInput.Aiming;
#endif
        if (MobileInput.ConsumeSwitch())
        {
            for (int k = 1; k <= owned.Length; k++)
            {
                int c = (cur + k) % owned.Length;
                if (owned[c]) { cur = c; break; }
            }
            reloading = false;
            ApplyGun();
            nextFire = Time.time + 0.3f;
        }
        if (MobileInput.ConsumeReload()) StartReload();
        if (reloading && Time.time >= reloadEnd)
        {
            reloading = false;
            int take = Mathf.Min(Current.mag - ammo[cur], reserve[cur]);
            ammo[cur] += take;
            reserve[cur] -= take;
        }

        if (fire && !reloading && Time.time >= nextFire)
        {
            if (ammo[cur] <= 0) StartReload(); else Fire();
        }
    }

    void StartReload()
    {
        if (reloading || ammo[cur] >= Current.mag || reserve[cur] <= 0) return;
        reloading = true;
        reloadEnd = Time.time + Current.reload;
        Sfx.Play(Sfx.Reload, transform.position, 0.8f);
    }

    void Fire()
    {
        var d = Current;
        nextFire = Time.time + d.interval;
        ammo[cur]--;

        Transform ct = cam.transform;
        Vector3 chest = transform.position + Vector3.up * 1.4f;
        float depth = Mathf.Max(0.5f, Vector3.Dot(chest - ct.position, ct.forward));
        Vector3 origin = ct.position + ct.forward * depth;
        float spread = d.spread * (MobileInput.Aiming ? 0.5f : 1f) * (pc.PlanarSpeed > 1f ? 1.4f : 1f);
        float tan = Mathf.Tan(spread * Mathf.Deg2Rad);
        bool hitAny = false;

        for (int p = 0; p < d.pellets; p++)
        {
            Vector2 r = Random.insideUnitCircle * tan;
            Vector3 dir = (ct.forward + ct.right * r.x + ct.up * r.y).normalized;
            Vector3 end = origin + dir * d.range;
            RaycastHit hit;
            if (Physics.Raycast(origin, dir, out hit, d.range, ~(1 << 2), QueryTriggerInteraction.Ignore))
            {
                end = hit.point;
                var h = hit.collider.GetComponentInParent<Health>();
                if (h != null && h != Hp && !h.Dead)
                {
                    float dmg = d.damage;
                    if (hit.point.y > h.transform.position.y + 1.5f) dmg *= 2f; // headshot
                    h.Take(dmg, gameObject);
                    hitAny = true;
                }
            }
            Tracers.Spawn(muzzle.position, end);
        }

        flash.SetActive(true);
        flashEnd = Time.time + 0.04f;
        Sfx.Play(Sfx.Shot(cur), muzzle.position, 1f);
        cam.AddRecoil(d.recoil);
        if (hitAny && HitConfirmed != null) HitConfirmed();
        if (ammo[cur] <= 0) StartReload();
    }

    void OnDied(GameObject killer)
    {
        reloading = false;
        MobileInput.Aiming = false;
        MobileInput.Firing = false;
        pc.Locked = true;
        pc.Model.localRotation = Quaternion.Euler(-80f, 0f, 0f);
    }

    public void Respawn()
    {
        pc.Model.localRotation = Quaternion.identity;
        pc.Respawn();
        Hp.Revive();
        pc.Locked = false;
        reloading = false;
        for (int i = 0; i < ammo.Length; i++) { ammo[i] = Weapons.All[i].mag; reserve[i] = 0; owned[i] = (i == 0); }
        reserve[0] = 36;
        cur = 0;
        ApplyGun();
        Inv.Medkits = 0; Inv.Plates = 0;
    }
}
