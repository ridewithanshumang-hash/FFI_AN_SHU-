using UnityEngine;

/// <summary>Match start: ride the plane, tap JUMP to drop, free-fall, tap JUMP again (or auto at 90 m) to open the parachute.</summary>
public class ParachuteController : MonoBehaviour
{
    public static string Prompt = "";

    enum S { Plane, Fall, Chute, Landed }
    const float PlaneSpeed = 35f, PlaneH = 250f;

    S state;
    ThirdPersonCamera cam;
    PlayerController pc;
    CharacterController cc;
    Transform plane, canopy;
    Vector3 planePos, pos;
    float vel;

    public void Init(ThirdPersonCamera c, PlayerController p)
    {
        cam = c; pc = p;
        cc = GetComponent<CharacterController>();
        planePos = new Vector3(-30f, PlaneH, Random.Range(250f, 550f));
        pos = planePos;
        pc.Flying = true;
        cc.enabled = false;
        GameStats.PlayerFlying = true;
        pc.Model.gameObject.SetActive(false);
        transform.position = pos;
        BuildPlane();
        state = S.Plane;
    }

    void BuildPlane()
    {
        plane = new GameObject("Plane").transform;
        var white = MapKit.Mat(new Color(0.93f, 0.93f, 0.9f), 0.2f);
        var saffron = MapKit.Mat(new Color(1f, 0.55f, 0.1f), 0.2f);
        MapKit.Prim(PrimitiveType.Cube, plane, Vector3.zero, new Vector3(4f, 4f, 20f), white, false);
        MapKit.Prim(PrimitiveType.Cube, plane, new Vector3(0f, 0.2f, 1f), new Vector3(26f, 0.5f, 4.5f), saffron, false);
        MapKit.Prim(PrimitiveType.Cube, plane, new Vector3(0f, 3f, -9f), new Vector3(0.6f, 5f, 3.5f), saffron, false);
        MapKit.Prim(PrimitiveType.Cube, plane, new Vector3(0f, 0.8f, -9f), new Vector3(8f, 0.4f, 2.5f), saffron, false);
        plane.rotation = Quaternion.Euler(0f, 90f, 0f);   // nose points +X
    }

    float HeightAboveGround()
    {
        RaycastHit hit;
        if (Physics.Raycast(pos + Vector3.up * 0.5f, Vector3.down, out hit, 1000f, ~(1 << 2), QueryTriggerInteraction.Ignore))
            return hit.distance - 0.5f;
        return pos.y;
    }

    void Steer(Vector2 mv, float speed, float dt)
    {
        Vector3 wish = Quaternion.Euler(0f, cam.Yaw, 0f) * new Vector3(mv.x, 0f, mv.y) * speed;
        pos += wish * dt;
        pos.x = Mathf.Clamp(pos.x, 0f, 800f);
        pos.z = Mathf.Clamp(pos.z, 0f, 800f);
        pos.y += vel * dt;
    }

    void Update()
    {
        float dt = Time.deltaTime;
        if (plane != null)
        {
            planePos += Vector3.right * PlaneSpeed * dt;
            plane.position = planePos + Vector3.down * 5.5f;
            if (planePos.x > 1000f) { Destroy(plane.gameObject); plane = null; }
        }
        if (state == S.Landed) return;

        Vector2 mv = MobileInput.Move;
#if ENABLE_LEGACY_INPUT_MANAGER
        mv = Vector2.ClampMagnitude(mv + new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), 1f);
        if (Input.GetKeyDown(KeyCode.Space)) MobileInput.JumpPressed = true;
#endif
        switch (state)
        {
            case S.Plane:
                pos = planePos;
                Prompt = "TAP JUMP TO DROP  (" + Mathf.CeilToInt(Mathf.Max(0f, (840f - pos.x) / PlaneSpeed)) + "s)";
                if (MobileInput.ConsumeJump() || pos.x > 840f)
                {
                    state = S.Fall;
                    vel = 0f;
                    pc.Model.gameObject.SetActive(true);
                    pc.Model.localRotation = Quaternion.Euler(80f, 0f, 0f);
                }
                break;

            case S.Fall:
                vel = Mathf.Max(vel - 30f * dt, -45f);
                Steer(mv, 14f, dt);
                float h = HeightAboveGround();
                Prompt = "TAP JUMP TO OPEN PARACHUTE   ALT " + Mathf.RoundToInt(h) + "m";
                if (MobileInput.ConsumeJump() || h < 90f) OpenChute();
                break;

            case S.Chute:
                vel = Mathf.MoveTowards(vel, -7f, 40f * dt);
                Steer(mv, 11f, dt);
                float h2 = HeightAboveGround();
                Prompt = "ALT " + Mathf.RoundToInt(h2) + "m";
                if (h2 <= 1.2f) Land();
                break;
        }

        if (state != S.Landed)
        {
            transform.position = pos;
            transform.rotation = Quaternion.Euler(0f, cam.Yaw, 0f);
        }
    }

    void OpenChute()
    {
        state = S.Chute;
        pc.Model.localRotation = Quaternion.identity;
        var c = MapKit.Prim(PrimitiveType.Sphere, transform, new Vector3(0f, 3.4f, 0f), new Vector3(4.5f, 2.2f, 4.5f),
                            MapKit.Mat(new Color(1f, 0.55f, 0.1f), 0.1f), false);
        canopy = c.transform;
    }

    void Land()
    {
        RaycastHit hit;
        if (Physics.Raycast(pos + Vector3.up * 0.5f, Vector3.down, out hit, 20f, ~(1 << 2), QueryTriggerInteraction.Ignore))
            pos = hit.point + Vector3.up * 0.05f;
        transform.position = pos;
        if (canopy != null) Destroy(canopy.gameObject);
        cc.enabled = true;
        pc.Flying = false;
        GameStats.PlayerFlying = false;
        Prompt = "";
        state = S.Landed;
    }
}
