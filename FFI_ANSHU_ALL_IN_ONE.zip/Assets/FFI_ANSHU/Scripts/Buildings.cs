using UnityEngine;
using Op = MapKit.Op;

/// <summary>Enterable sandstone buildings: door, windows, interior, roof, and a real staircase on 2-storey ones.</summary>
public static class Buildings
{
    const float FH = 3.2f;   // floor height
    const float T = 0.3f;    // wall thickness
    public static readonly System.Collections.Generic.List<Vector3> LootSpots = new System.Collections.Generic.List<Vector3>();

    static void Slab(Transform r, float x0, float x1, float z0, float z1, float y, float th, Material m)
    {
        if (x1 - x0 < 0.01f || z1 - z0 < 0.01f) return;
        MapKit.Box(r, new Vector3((x0 + x1) * 0.5f, y, (z0 + z1) * 0.5f), new Vector3(x1 - x0, th, z1 - z0), m);
    }

    /// <summary>Front (door side) is local -Z. For 2 floors use w>=8, d>=9.</summary>
    public static Transform House(Transform parent, Vector3 pos, float yaw, float w, float d, int floors, Material wall, Material trim, Material floorM)
    {
        var root = new GameObject("House").transform;
        root.SetParent(parent, false);
        root.position = pos;
        root.rotation = Quaternion.Euler(0, yaw, 0);
        float H = FH * floors;

        // Plinth / ground floor (top at y=0.05)
        MapKit.Box(root, new Vector3(0, -0.15f, 0), new Vector3(w + 0.4f, 0.4f, d + 0.4f), trim);
        Slab(root, -w / 2 + T, w / 2 - T, -d / 2 + T, d / 2 - T, -0.12f, 0.34f, floorM);

        for (int f = 0; f < floors; f++)
        {
            float y0 = f * FH;
            Op[] front = f == 0
                ? new[] { new Op(0, 1.7f, 0, 2.5f), new Op(-w / 3, 1.1f, 1f, 2.2f), new Op(w / 3, 1.1f, 1f, 2.2f) }
                : new[] { new Op(-w / 3, 1.1f, 1f, 2.2f), new Op(0, 1.1f, 1f, 2.2f), new Op(w / 3, 1.1f, 1f, 2.2f) };
            MapKit.Wall(root, new Vector3(0, y0, -(d / 2 - T / 2)), true, w, FH, T, wall, front);
            MapKit.Wall(root, new Vector3(0, y0, (d / 2 - T / 2)), true, w, FH, T, wall,
                new Op(-w / 3, 1.1f, 1f, 2.2f), new Op(0, 1.1f, 1f, 2.2f), new Op(w / 3, 1.1f, 1f, 2.2f));
            MapKit.Wall(root, new Vector3(-(w / 2 - T / 2), y0, 0), false, d - 2 * T, FH, T, wall,
                new Op(-d / 4, 1.1f, 1f, 2.2f), new Op(d / 4, 1.1f, 1f, 2.2f));
            MapKit.Wall(root, new Vector3((w / 2 - T / 2), y0, 0), false, d - 2 * T, FH, T, wall,
                new Op(-d / 4, 1.1f, 1f, 2.2f), new Op(d / 4, 1.1f, 1f, 2.2f));
            if (f == 0)
            {
                MapKit.Box(root, new Vector3(0, 2.62f, -(d / 2 - T / 2)), new Vector3(2.2f, 0.28f, T + 0.2f), trim);
            }
        }

        if (floors == 2)
        {
            const int n = 16;
            float run = 0.3f, top0 = 0.05f, rise = (FH - top0) / n;
            float sx = w / 2 - T - 1f;                 // stair centre x (width 2)
            float zs = -d / 2 + T + 1.3f, ze = zs + n * run;
            float sy = FH - 0.15f;
            Slab(root, -w / 2, sx - 1, -d / 2, d / 2, sy, 0.3f, floorM);
            Slab(root, sx - 1, w / 2, -d / 2, zs, sy, 0.3f, floorM);
            Slab(root, sx - 1, w / 2, ze, d / 2, sy, 0.3f, floorM);
            for (int i = 0; i < n; i++)
            {
                float top = top0 + (i + 1) * rise;
                MapKit.Box(root, new Vector3(sx, top * 0.5f, zs + (i + 0.5f) * run), new Vector3(2f, top, run), trim);
            }
        }
        else
        {
            // Interior props: a charpai (rope bed) and a crate
            var wood = MapKit.Mat(MapKit.C(110, 70, 40));
            MapKit.Box(root, new Vector3(-w / 2 + 1.2f, 0.4f, d / 2 - 1.6f), new Vector3(0.95f, 0.5f, 1.9f), wood);
            MapKit.Box(root, new Vector3(w / 2 - 1.0f, 0.45f, -d / 2 + 1.1f), new Vector3(0.8f, 0.8f, 0.8f), wood);
        }

        // Roof + parapet
        MapKit.Box(root, new Vector3(0, H + 0.15f, 0), new Vector3(w + 0.3f, 0.3f, d + 0.3f), wall);
        MapKit.Box(root, new Vector3(0, H + 0.7f, -(d / 2 - 0.125f)), new Vector3(w, 0.8f, 0.25f), trim);
        MapKit.Box(root, new Vector3(0, H + 0.7f, (d / 2 - 0.125f)), new Vector3(w, 0.8f, 0.25f), trim);
        MapKit.Box(root, new Vector3(-(w / 2 - 0.125f), H + 0.7f, 0), new Vector3(0.25f, 0.8f, d - 0.5f), trim);
        MapKit.Box(root, new Vector3((w / 2 - 0.125f), H + 0.7f, 0), new Vector3(0.25f, 0.8f, d - 0.5f), trim);
        LootSpots.Add(pos + Vector3.up * 0.7f);
        if (floors == 2) LootSpots.Add(pos + Vector3.up * (FH + 0.7f));
        return root;
    }
}
