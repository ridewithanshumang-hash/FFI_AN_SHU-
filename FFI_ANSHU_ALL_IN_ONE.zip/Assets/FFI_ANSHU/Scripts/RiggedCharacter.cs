using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Procedurally generated RIGGED character: one skinned mesh (smooth tubes, joint-blended bone weights) bound to a 17-bone skeleton.
/// The mesh is built once and shared; each character only creates its own bones + materials (skin colours).
/// </summary>
public class RiggedCharacter : MonoBehaviour
{
    public const int HIPS = 0, SPINE = 1, CHEST = 2, NECK = 3, HEAD = 4,
                     UAL = 5, LAL = 6, HAL = 7, UAR = 8, LAR = 9, HAR = 10,
                     ULL = 11, LLL = 12, FL = 13, ULR = 14, LLR = 15, FR = 16;

    static readonly string[] Names =
    {
        "Hips", "Spine", "Chest", "Neck", "Head", "UpperArmL", "LowerArmL", "HandL", "UpperArmR", "LowerArmR", "HandR",
        "UpperLegL", "LowerLegL", "FootL", "UpperLegR", "LowerLegR", "FootR"
    };
    static readonly int[] ParentOf = { -1, 0, 1, 2, 3, 2, 5, 6, 2, 8, 9, 0, 11, 12, 0, 14, 15 };
    static readonly Vector3[] RestPos =
    {
        new Vector3(0f, 0.95f, 0f), new Vector3(0f, 1.15f, 0f), new Vector3(0f, 1.40f, 0f), new Vector3(0f, 1.58f, 0f), new Vector3(0f, 1.66f, 0f),
        new Vector3(-0.27f, 1.50f, 0f), new Vector3(-0.30f, 1.22f, 0f), new Vector3(-0.31f, 0.96f, 0f),
        new Vector3(0.27f, 1.50f, 0f), new Vector3(0.30f, 1.22f, 0f), new Vector3(0.31f, 0.96f, 0f),
        new Vector3(-0.11f, 0.95f, 0f), new Vector3(-0.115f, 0.50f, 0f), new Vector3(-0.115f, 0.07f, 0f),
        new Vector3(0.11f, 0.95f, 0f), new Vector3(0.115f, 0.50f, 0f), new Vector3(0.115f, 0.07f, 0f)
    };

    static Mesh sharedMesh;
    static Matrix4x4[] bind;
    static readonly Dictionary<Color, Material> matCache = new Dictionary<Color, Material>();

    public Transform Root;
    public bool IdleAnim;
    readonly Transform[] bones = new Transform[17];

    public Transform Bone(int i) { return bones[i]; }

    static Material Mat(Color c)
    {
        Material m;
        if (matCache.TryGetValue(c, out m) && m != null) return m;
        m = MapKit.Mat(c, 0.12f);
        matCache[c] = m;
        return m;
    }

    public static RiggedCharacter Build(Transform parent, CharacterSkin s)
    {
        EnsureMesh();
        var go = new GameObject("Rig");
        go.transform.SetParent(parent, false);
        var rc = go.AddComponent<RiggedCharacter>();
        rc.Root = go.transform;
        for (int i = 0; i < 17; i++)
        {
            var b = new GameObject(Names[i]).transform;
            b.SetParent(ParentOf[i] < 0 ? go.transform : rc.bones[ParentOf[i]], false);
            b.localPosition = ParentOf[i] < 0 ? RestPos[i] : RestPos[i] - RestPos[ParentOf[i]];
            rc.bones[i] = b;
        }
        var smr = go.AddComponent<SkinnedMeshRenderer>();
        smr.sharedMesh = sharedMesh;
        smr.bones = rc.bones;
        smr.rootBone = rc.bones[HIPS];
        smr.sharedMaterials = new[] { Mat(s.skin), Mat(s.shirt), Mat(s.pants), Mat(s.turban), Mat(s.sash) };
        smr.localBounds = new Bounds(new Vector3(0f, 1f, 0f), new Vector3(2.6f, 3f, 2.6f));
        return rc;
    }

    // ---------------- mesh generation (runs once) ----------------
    class MB
    {
        public List<Vector3> v = new List<Vector3>();
        public List<BoneWeight> w = new List<BoneWeight>();
        public List<int>[] tris = new List<int>[5];
        public MB() { for (int i = 0; i < 5; i++) tris[i] = new List<int>(); }
    }

    static BoneWeight Weights(float t, int bA, int bEnd, int bStart)
    {
        var bw = new BoneWeight();
        float wA = 1f;
        if (bEnd >= 0 && t > 0.75f)
        {
            float f = (t - 0.75f) / 0.25f * 0.5f;
            wA -= f; bw.boneIndex1 = bEnd; bw.weight1 = f;
        }
        else if (bStart >= 0 && t < 0.25f)
        {
            float f = (0.25f - t) / 0.25f * 0.5f;
            wA -= f; bw.boneIndex1 = bStart; bw.weight1 = f;
        }
        bw.boneIndex0 = bA; bw.weight0 = wA;
        return bw;
    }

    // sub: 0 skin, 1 shirt, 2 pants, 3 turban, 4 accent (sash / boots)
    static void Tube(MB mb, int sub, Vector3 p0, Vector3 p1, float r0, float r1, float sx, float sz, int bA, int bEnd, int bStart, bool ell)
    {
        const int seg = 8;
        int rings = ell ? 8 : 4;
        Vector3 up = (p1 - p0).normalized;
        Vector3 right = Vector3.Cross(up, Vector3.forward);
        if (right.sqrMagnitude < 0.01f) right = Vector3.right;
        right.Normalize();
        Vector3 fwd = Vector3.Cross(right, up);
        int start = mb.v.Count;
        for (int i = 0; i <= rings; i++)
        {
            float t = (float)i / rings;
            float r = Mathf.Lerp(r0, r1, t);
            if (ell) { float k = 2f * t - 1f; r *= Mathf.Sqrt(Mathf.Max(0.0004f, 1f - k * k)); }
            Vector3 c = Vector3.Lerp(p0, p1, t);
            var bw = Weights(t, bA, bEnd, bStart);
            for (int j = 0; j < seg; j++)
            {
                float a = j * 6.2832f / seg;
                mb.v.Add(c + right * (Mathf.Cos(a) * r * sx) + fwd * (Mathf.Sin(a) * r * sz));
                mb.w.Add(bw);
            }
        }
        var tr = mb.tris[sub];
        for (int i = 0; i < rings; i++)
            for (int j = 0; j < seg; j++)
            {
                int a = start + i * seg + j;
                int b = start + i * seg + (j + 1) % seg;
                int c2 = a + seg;
                int d = b + seg;
                tr.Add(a); tr.Add(c2); tr.Add(b);
                tr.Add(b); tr.Add(c2); tr.Add(d);
            }
        if (!ell)
        {
            int c0 = mb.v.Count; mb.v.Add(p0); mb.w.Add(Weights(0f, bA, bEnd, bStart));
            int c1 = mb.v.Count; mb.v.Add(p1); mb.w.Add(Weights(1f, bA, bEnd, bStart));
            int rs = start + rings * seg;
            for (int j = 0; j < seg; j++)
            {
                tr.Add(c0); tr.Add(start + j); tr.Add(start + (j + 1) % seg);
                tr.Add(c1); tr.Add(rs + (j + 1) % seg); tr.Add(rs + j);
            }
        }
    }

    static void EnsureMesh()
    {
        if (sharedMesh != null) return;
        var mb = new MB();
        // torso
        Tube(mb, 1, new Vector3(0f, 0.88f, 0f), new Vector3(0f, 1.15f, 0f), 0.20f, 0.205f, 1.18f, 0.72f, HIPS, SPINE, -1, false);
        Tube(mb, 1, new Vector3(0f, 1.15f, 0f), new Vector3(0f, 1.40f, 0f), 0.205f, 0.235f, 1.18f, 0.72f, SPINE, CHEST, HIPS, false);
        Tube(mb, 1, new Vector3(0f, 1.40f, 0f), new Vector3(0f, 1.57f, 0f), 0.235f, 0.17f, 1.18f, 0.72f, CHEST, -1, SPINE, false);
        Tube(mb, 4, new Vector3(0f, 0.90f, 0f), new Vector3(0f, 1.04f, 0f), 0.212f, 0.212f, 1.2f, 0.74f, HIPS, -1, -1, false);
        // neck, head, turban
        Tube(mb, 0, new Vector3(0f, 1.54f, 0f), new Vector3(0f, 1.66f, 0f), 0.06f, 0.055f, 1f, 1f, NECK, HEAD, CHEST, false);
        Tube(mb, 0, new Vector3(0f, 1.64f, 0f), new Vector3(0f, 1.90f, 0f), 0.108f, 0.108f, 1f, 1.05f, HEAD, -1, -1, true);
        Tube(mb, 3, new Vector3(0f, 1.74f, 0f), new Vector3(0f, 2.00f, 0f), 0.135f, 0.135f, 1f, 1.05f, HEAD, -1, -1, true);
        Tube(mb, 3, new Vector3(0f, 1.72f, 0f), new Vector3(0f, 1.82f, 0f), 0.13f, 0.13f, 1f, 1.05f, HEAD, -1, -1, false);
        // arms and legs (both sides)
        for (int side = -1; side <= 1; side += 2)
        {
            float x = side;
            int ua = side < 0 ? UAL : UAR, la = side < 0 ? LAL : LAR, ha = side < 0 ? HAL : HAR;
            int ul = side < 0 ? ULL : ULR, ll = side < 0 ? LLL : LLR, ft = side < 0 ? FL : FR;
            Tube(mb, 1, new Vector3(x * 0.27f, 1.50f, 0f), new Vector3(x * 0.30f, 1.22f, 0f), 0.068f, 0.058f, 1f, 1f, ua, la, -1, false);
            Tube(mb, 0, new Vector3(x * 0.30f, 1.22f, 0f), new Vector3(x * 0.31f, 0.96f, 0f), 0.056f, 0.046f, 1f, 1f, la, ha, ua, false);
            Tube(mb, 0, new Vector3(x * 0.31f, 0.97f, 0f), new Vector3(x * 0.31f, 0.84f, 0f), 0.05f, 0.05f, 1f, 1.2f, ha, -1, -1, true);
            Tube(mb, 2, new Vector3(x * 0.11f, 0.95f, 0f), new Vector3(x * 0.115f, 0.50f, 0f), 0.088f, 0.066f, 1f, 1f, ul, ll, -1, false);
            Tube(mb, 2, new Vector3(x * 0.115f, 0.50f, 0f), new Vector3(x * 0.115f, 0.10f, 0f), 0.066f, 0.05f, 1f, 1f, ll, ft, ul, false);
            Tube(mb, 4, new Vector3(x * 0.115f, 0.065f, -0.07f), new Vector3(x * 0.115f, 0.065f, 0.24f), 0.058f, 0.05f, 1f, 0.75f, ft, -1, -1, true);
        }
        var m = new Mesh();
        m.name = "RiggedCharacter";
        m.SetVertices(mb.v);
        m.boneWeights = mb.w.ToArray();
        m.subMeshCount = 5;
        for (int i = 0; i < 5; i++) m.SetTriangles(mb.tris[i], i);
        m.RecalculateNormals();
        m.RecalculateBounds();
        bind = new Matrix4x4[17];
        for (int i = 0; i < 17; i++) bind[i] = Matrix4x4.TRS(-RestPos[i], Quaternion.identity, Vector3.one);
        m.bindposes = bind;
        sharedMesh = m;
    }

    // ---------------- procedural posing (elbows / knees follow the upper limbs) ----------------
    static float Norm(float a) { return a > 180f ? a - 360f : a; }

    void LateUpdate()
    {
        Elbow(UAL, LAL); Elbow(UAR, LAR);
        Knee(ULL, LLL); Knee(ULR, LLR);
        if (IdleAnim)
        {
            float t = Time.time;
            bones[SPINE].localRotation = Quaternion.Euler(Mathf.Sin(t * 1.6f) * 1.2f, 0f, 0f);
            bones[HEAD].localRotation = Quaternion.Euler(0f, Mathf.Sin(t * 0.5f) * 6f, 0f);
        }
    }

    void Elbow(int ua, int la)
    {
        float a = Norm(bones[ua].localEulerAngles.x);
        float bend = a < -60f ? 20f : Mathf.Clamp(15f + Mathf.Abs(a) * 0.35f, 10f, 70f);
        bones[la].localRotation = Quaternion.Euler(-bend, 0f, 0f);
    }

    void Knee(int ul, int ll)
    {
        float a = Norm(bones[ul].localEulerAngles.x);
        bones[ll].localRotation = Quaternion.Euler(Mathf.Clamp(a, 0f, 80f) * 0.9f + 4f, 0f, 0f);
    }
}
