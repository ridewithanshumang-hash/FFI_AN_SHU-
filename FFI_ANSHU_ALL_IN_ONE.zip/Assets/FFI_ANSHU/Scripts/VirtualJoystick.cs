using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>Floating left-side joystick: appears where the thumb lands inside the zone.</summary>
public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform zone, baseRt, knob;
    public float radius = 110f;
    Vector2 restPos;
    Vector2 origin;
    int activeId = int.MinValue;

    void Start() { restPos = baseRt.anchoredPosition; SetAlpha(0.45f); }

    void SetAlpha(float a)
    {
        foreach (var g in baseRt.GetComponentsInChildren<UnityEngine.UI.Image>())
        { var c = g.color; c.a = a; g.color = c; }
    }

    Vector2 Local(PointerEventData e)
    {
        Vector2 lp;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(zone, e.position, e.pressEventCamera, out lp);
        return lp; // zone pivot is bottom-left, so this is relative to bottom-left
    }

    public void OnPointerDown(PointerEventData e)
    {
        if (activeId != int.MinValue) return;
        activeId = e.pointerId;
        origin = Local(e);
        baseRt.anchoredPosition = origin;
        knob.anchoredPosition = Vector2.zero;
        SetAlpha(0.85f);
    }

    public void OnDrag(PointerEventData e)
    {
        if (e.pointerId != activeId) return;
        Vector2 off = Local(e) - origin;
        Vector2 clamped = Vector2.ClampMagnitude(off, radius);
        knob.anchoredPosition = clamped;
        Vector2 v = clamped / radius;
        // small dead zone, then rescale
        float m = v.magnitude;
        MobileInput.Move = m < 0.1f ? Vector2.zero : v;
    }

    public void OnPointerUp(PointerEventData e)
    {
        if (e.pointerId != activeId) return;
        activeId = int.MinValue;
        MobileInput.Move = Vector2.zero;
        knob.anchoredPosition = Vector2.zero;
        baseRt.anchoredPosition = restPos;
        SetAlpha(0.45f);
    }
}
