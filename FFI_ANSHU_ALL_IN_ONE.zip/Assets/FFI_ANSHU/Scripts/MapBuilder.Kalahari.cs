using UnityEngine;

/// <summary>Kalahari map: red desert, tent camps with fires and watchtowers, ranger lodges, red mesas and a giant dinosaur fossil.</summary>
public static partial class MapBuilder
{
    static void InitKalahari()
    {
        zones.Add(new Zone(400, 240, 60));
        zones.Add(new Zone(150, 330, 45));
        zones.Add(new Zone(680, 300, 50));
        zones.Add(new Zone(240, 620, 45));
        zones.Add(new Zone(620, 640, 52));
        zones.Add(new Zone(400, 430, 75));   // dinosaur dig site
        roads.Add(new Seg(400, 240, 400, 430));
        roads.Add(new Seg(400, 240, 150, 330));
        roads.Add(new Seg(400, 240, 680, 300));
        roads.Add(new Seg(400, 430, 240, 620));
        roads.Add(new Seg(400, 430, 620, 640));
        SpawnPos = new Vector3(400f, FlatH + 0.15f, 205f);
        HotSpot = new Vector2(400f, 430f);
    }

    static Material KM(int r, int g, int b, float s)
    {
        return MapKit.Mat(MapKit.C(r, g, b), s);
    }

    static void BuildKalahari(Transform parent)
    {
        var canvas = new[] { KM(222, 206, 170, 0.05f), KM(120, 125, 85, 0.05f), KM(205, 115, 45, 0.05f), KM(190, 60, 50, 0.05f) };
        var wood = KM(110, 70, 40, 0.05f);
        var dark = KM(60, 45, 35, 0.05f);
        var fire = MapKit.Mat(new Color(1f, 0.55f, 0.1f), 0f);
        var adobe = KM(176, 88, 58, 0.05f);
        var adobeTrim = KM(112, 60, 40, 0.05f);
        var floorM = KM(150, 105, 75, 0.05f);

        Camp(parent, new Vector2(400, 240), 6, 14f, true, true, canvas, wood, dark, fire);
        Camp(parent, new Vector2(150, 330), 5, 12f, false, true, canvas, wood, dark, fire);
        Camp(parent, new Vector2(680, 300), 5, 13f, true, false, canvas, wood, dark, fire);
        Camp(parent, new Vector2(240, 620), 4, 12f, false, true, canvas, wood, dark, fire);
        Camp(parent, new Vector2(620, 640), 6, 14f, true, false, canvas, wood, dark, fire);
        Camp(parent, new Vector2(448, 430), 3, 8f, false, true, canvas, wood, dark, fire);   // dig camp

        Buildings.House(parent, new Vector3(436, FlatH, 262), 90f, 10f, 12f, 2, adobe, adobeTrim, floorM);
        Buildings.House(parent, new Vector3(250, FlatH, 650), 0f, 8f, 9f, 1, adobe, adobeTrim, floorM);
        Buildings.House(parent, new Vector3(648, FlatH, 664), 180f, 10f, 12f, 2, adobe, adobeTrim, floorM);
        Buildings.House(parent, new Vector3(705, FlatH, 275), 270f, 8f, 9f, 1, adobe, adobeTrim, floorM);
        Buildings.House(parent, new Vector3(120, FlatH, 305), 0f, 8f, 9f, 1, adobe, adobeTrim, floorM);

        Dino(parent, new Vector3(400f, FlatH - 0.4f, 405f));
    }

    static void Camp(Transform parent, Vector2 c, int tents, float rad, bool tower, bool light,
                     Material[] canvas, Material wood, Material dark, Material fireM)
    {
        var root = new GameObject("Camp").transform;
        root.SetParent(parent, false);
        Vector3 cp = new Vector3(c.x, FlatH, c.y);

        for (int i = 0; i < 6; i++)
        {
            float a = i * Mathf.PI / 3f;
            var l = MapKit.Box(root, cp + new Vector3(Mathf.Cos(a) * 0.6f, 0.15f, Mathf.Sin(a) * 0.6f), new Vector3(0.25f, 0.25f, 0.7f), dark);
            l.transform.rotation = Quaternion.Euler(0f, -a * Mathf.Rad2Deg + 90f, 0f);
        }
        MapKit.Prim(PrimitiveType.Sphere, root, cp + new Vector3(0f, 0.55f, 0f), new Vector3(0.55f, 0.9f, 0.55f), fireM, false);
        if (light)
        {
            var lg = new GameObject("FireLight").transform;
            lg.SetParent(root, false);
            lg.position = cp + Vector3.up * 1.4f;
            var li = lg.gameObject.AddComponent<Light>();
            li.type = LightType.Point; li.color = new Color(1f, 0.55f, 0.2f);
            li.intensity = 1.4f; li.range = 11f; li.shadows = LightShadows.None;
        }
        for (int i = 0; i < tents; i++)
        {
            float a = i * Mathf.PI * 2f / tents + 0.3f;
            Vector3 tp = cp + new Vector3(Mathf.Cos(a) * rad, 0f, Mathf.Sin(a) * rad);
            float yaw = Mathf.Atan2(cp.x - tp.x, cp.z - tp.z) * Mathf.Rad2Deg;
            Tent(root, tp, yaw, canvas[i % canvas.Length], dark);
        }
        for (int i = 0; i < 4; i++)
        {
            float a = 0.8f + i * 1.7f;
            Vector3 p = cp + new Vector3(Mathf.Cos(a) * 4.5f, 0f, Mathf.Sin(a) * 4.5f);
            MapKit.Box(root, p + new Vector3(0f, 0.5f, 0f), new Vector3(1f, 1f, 1f), wood);
            if (i % 2 == 0) MapKit.Box(root, p + new Vector3(0.1f, 1.45f, 0f), new Vector3(0.8f, 0.8f, 0.8f), wood);
        }
        for (int i = 0; i < 2; i++)
        {
            float a = 2.4f + i * 2.2f;
            Vector3 p = cp + new Vector3(Mathf.Cos(a) * 6f, 0.55f, Mathf.Sin(a) * 6f);
            MapKit.Prim(PrimitiveType.Cylinder, root, p, new Vector3(0.7f, 0.55f, 0.7f), dark);
        }
        Buildings.LootSpots.Add(cp + new Vector3(2.5f, 0.7f, 2.5f));
        if (tower) Tower(root, cp + new Vector3(-28f, 0f, 6f), wood);
    }

    static void Tent(Transform parent, Vector3 pos, float yaw, Material m, Material floor)
    {
        var r = new GameObject("Tent").transform;
        r.SetParent(parent, false);
        r.position = pos;
        r.rotation = Quaternion.Euler(0f, yaw, 0f);
        var l = MapKit.Box(r, new Vector3(-0.8f, 1.15f, 0f), new Vector3(2.8f, 0.08f, 4.2f), m);
        l.transform.localRotation = Quaternion.Euler(0f, 0f, 55.2f);
        var rr = MapKit.Box(r, new Vector3(0.8f, 1.15f, 0f), new Vector3(2.8f, 0.08f, 4.2f), m);
        rr.transform.localRotation = Quaternion.Euler(0f, 0f, -55.2f);
        MapKit.Box(r, new Vector3(0f, 0.9f, -2.1f), new Vector3(3f, 1.8f, 0.08f), m);
        MapKit.Box(r, new Vector3(0f, 0.03f, 0f), new Vector3(3.1f, 0.06f, 4.2f), floor);
        Buildings.LootSpots.Add(pos + Vector3.up * 0.7f);
    }

    static void Tower(Transform parent, Vector3 pos, Material wood)
    {
        var r = new GameObject("Tower").transform;
        r.SetParent(parent, false);
        r.position = pos;
        foreach (float sx in new[] { -2f, 2f })
            foreach (float sz in new[] { -2f, 2f })
                MapKit.Box(r, new Vector3(sx, 4f, sz), new Vector3(0.35f, 8f, 0.35f), wood);
        MapKit.Box(r, new Vector3(0f, 8.15f, 0f), new Vector3(5.4f, 0.3f, 5.4f), wood);
        MapKit.Box(r, new Vector3(0f, 8.8f, 2.6f), new Vector3(5.4f, 1f, 0.12f), wood);
        MapKit.Box(r, new Vector3(2.6f, 8.8f, 0f), new Vector3(0.12f, 1f, 5.4f), wood);
        MapKit.Box(r, new Vector3(-2.6f, 8.8f, 0f), new Vector3(0.12f, 1f, 5.4f), wood);
        var ramp = MapKit.Box(r, new Vector3(0f, 4f, -9.63f), new Vector3(2.2f, 0.25f, 16f), wood);
        ramp.transform.localRotation = Quaternion.Euler(-30f, 0f, 0f);
        Buildings.LootSpots.Add(pos + Vector3.up * 9f);
    }

    static void Dino(Transform parent, Vector3 basePos)
    {
        var bone = KM(232, 224, 200, 0.1f);
        var socket = KM(35, 28, 22, 0.05f);
        var root = new GameObject("DinosaurFossil").transform;
        root.SetParent(parent, false);
        root.position = basePos;

        // spine: tail (z=-24) to neck (z=+12), arched over the torso
        int n = 30;
        for (int i = 0; i < n; i++)
        {
            float t = i / (float)(n - 1);
            float z = Mathf.Lerp(-24f, 12f, t);
            float h = 1.2f + 5.2f * Mathf.Sin(t * Mathf.PI);
            float w = Mathf.Lerp(0.5f, 1.5f, Mathf.Sin(t * Mathf.PI));
            MapKit.Box(root, new Vector3(0f, h, z), new Vector3(w, w * 0.9f, 1.05f), bone);
            if (t > 0.2f && t < 0.85f)
                MapKit.Prim(PrimitiveType.Cube, root, new Vector3(0f, h + w * 0.9f, z), new Vector3(0.18f, w * 1.2f, 0.5f), bone, false);
        }

        // ribs: 9 pairs, some broken
        for (int k = 0; k < 9; k++)
        {
            float zr = Mathf.Lerp(-8f, 7f, k / 8f);
            float t = (zr + 24f) / 36f;
            float yTop = 1.2f + 5.2f * Mathf.Sin(t * Mathf.PI);
            float ry = yTop * 0.52f;
            float rx = 1.8f + 2.6f * Mathf.Sin(Mathf.Clamp01((zr + 9f) / 18f) * Mathf.PI);
            float cy = yTop - ry;
            float aMax = (k % 3 == 1 ? 120f : 160f) * Mathf.Deg2Rad;
            for (int side = -1; side <= 1; side += 2)
            {
                const int S = 8;
                Vector3 prev = new Vector3(0f, yTop, zr);
                for (int s = 1; s <= S; s++)
                {
                    float a = aMax * s / S;
                    Vector3 p = new Vector3(side * rx * Mathf.Sin(a), cy + ry * Mathf.Cos(a), zr);
                    Vector3 d = p - prev;
                    var g = MapKit.Box(root, (prev + p) * 0.5f, new Vector3(0.38f, 0.38f, d.magnitude + 0.05f), bone);
                    g.transform.localRotation = Quaternion.LookRotation(d);
                    prev = p;
                }
            }
        }

        // skull
        MapKit.Box(root, new Vector3(0f, 2.2f, 15.5f), new Vector3(3.4f, 3.2f, 3.6f), bone);
        MapKit.Box(root, new Vector3(0f, 1.8f, 20.2f), new Vector3(2.4f, 2.0f, 6.2f), bone);
        var jaw = MapKit.Box(root, new Vector3(0f, 0.5f, 20.0f), new Vector3(2.0f, 0.7f, 6.0f), bone);
        jaw.transform.localRotation = Quaternion.Euler(5f, 0f, 0f);
        MapKit.Prim(PrimitiveType.Sphere, root, new Vector3(-1.75f, 3.0f, 15.2f), new Vector3(0.9f, 0.9f, 0.9f), socket, false);
        MapKit.Prim(PrimitiveType.Sphere, root, new Vector3(1.75f, 3.0f, 15.2f), new Vector3(0.9f, 0.9f, 0.9f), socket, false);
        MapKit.Prim(PrimitiveType.Sphere, root, new Vector3(-0.5f, 2.7f, 23.2f), new Vector3(0.5f, 0.5f, 0.5f), socket, false);
        MapKit.Prim(PrimitiveType.Sphere, root, new Vector3(0.5f, 2.7f, 23.2f), new Vector3(0.5f, 0.5f, 0.5f), socket, false);
        for (int i = 0; i < 9; i++)
        {
            float z = 17.6f + i * 0.7f;
            MapKit.Prim(PrimitiveType.Cube, root, new Vector3(-1.2f, 0.85f, z), new Vector3(0.22f, 0.8f, 0.22f), bone, false);
            MapKit.Prim(PrimitiveType.Cube, root, new Vector3(1.2f, 0.85f, z), new Vector3(0.22f, 0.8f, 0.22f), bone, false);
        }

        // legs and tiny arms
        foreach (float sx in new[] { -2.7f, 2.7f })
        {
            var fem = MapKit.Box(root, new Vector3(sx, 3.0f, -9f), new Vector3(1.3f, 1.3f, 5.5f), bone);
            fem.transform.localRotation = Quaternion.Euler(35f, 0f, 0f);
            var tib = MapKit.Box(root, new Vector3(sx, 1.4f, -12.5f), new Vector3(0.9f, 0.9f, 5f), bone);
            tib.transform.localRotation = Quaternion.Euler(-30f, 0f, 0f);
            MapKit.Box(root, new Vector3(sx, 0.25f, -14.5f), new Vector3(1.8f, 0.5f, 2.8f), bone);
        }
        foreach (float sx in new[] { -1.6f, 1.6f })
        {
            var arm = MapKit.Box(root, new Vector3(sx, 3f, 5.5f), new Vector3(0.5f, 0.5f, 2.2f), bone);
            arm.transform.localRotation = Quaternion.Euler(40f, 0f, 0f);
        }
        // loose bone fragments
        for (int i = 0; i < 14; i++)
        {
            var f = MapKit.Prim(PrimitiveType.Cube, root, new Vector3(Random.Range(-9f, 9f), 0.2f, Random.Range(-26f, 26f)),
                                new Vector3(Random.Range(0.3f, 0.9f), 0.25f, Random.Range(0.8f, 2.2f)), bone, false);
            f.transform.localRotation = Quaternion.Euler(0f, Random.Range(0f, 180f), 0f);
        }
        Buildings.LootSpots.Add(basePos + new Vector3(0f, 1.2f, -2f));
        Buildings.LootSpots.Add(basePos + new Vector3(6f, 1.2f, 6f));
        Buildings.LootSpots.Add(basePos + new Vector3(-6f, 1.2f, 14f));
    }

    static void NatureKalahari(Transform parent)
    {
        var trunk = KM(100, 72, 46, 0.05f);
        var leaf = KM(105, 118, 55, 0.05f);
        var dry = KM(150, 110, 70, 0.05f);
        Material[] rocks = { KM(150, 70, 45, 0.05f), KM(176, 92, 58, 0.05f), KM(120, 55, 40, 0.05f) };

        // red mesas
        int made = 0, tries = 0;
        while (made < 16 && tries < 500)
        {
            tries++;
            float x = Random.Range(80f, 720f), z = Random.Range(80f, 720f);
            if (!IsOpen(x, z) || RoadDist(new Vector2(x, z)) < 35f) continue;
            float r = Random.Range(9f, 24f), h = Random.Range(8f, 22f);
            float y = Ground.SampleHeight(new Vector3(x, 0f, z));
            float h1 = h * 0.6f, h2 = h * 0.4f;
            MapKit.Prim(PrimitiveType.Cylinder, parent, new Vector3(x, y - 1f + h1 * 0.5f, z), new Vector3(r * 2f, h1 * 0.5f, r * 2f), rocks[0]);
            MapKit.Prim(PrimitiveType.Cylinder, parent, new Vector3(x, y - 1f + h1 + h2 * 0.5f, z), new Vector3(r * 1.56f, h2 * 0.5f, r * 1.56f), rocks[1]);
            made++;
        }
        // acacia trees
        for (int i = 0; i < 200; i++)
        {
            float x = Random.Range(40f, Size - 40f), z = Random.Range(40f, Size - 40f);
            if (!IsOpen(x, z) || RoadDist(new Vector2(x, z)) < 14f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0f, z));
            MapKit.Prim(PrimitiveType.Cylinder, parent, new Vector3(x, y + 1.7f, z), new Vector3(0.4f, 1.7f, 0.4f), trunk);
            MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x, y + 3.9f, z), new Vector3(7f, 1.3f, 7f), leaf, false);
        }
        // baobabs
        made = 0; tries = 0;
        while (made < 6 && tries < 300)
        {
            tries++;
            float x = Random.Range(60f, 740f), z = Random.Range(60f, 740f);
            if (!IsOpen(x, z) || RoadDist(new Vector2(x, z)) < 20f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0f, z));
            MapKit.Prim(PrimitiveType.Cylinder, parent, new Vector3(x, y + 5.5f, z), new Vector3(3f, 5.5f, 3f), trunk);
            MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x - 2f, y + 11.8f, z), new Vector3(6f, 3f, 6f), leaf, false);
            MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x + 2f, y + 12.2f, z + 1.5f), new Vector3(6f, 3f, 6f), leaf, false);
            made++;
        }
        // rocks and dry bushes
        for (int i = 0; i < 240; i++)
        {
            float x = Random.Range(30f, Size - 30f), z = Random.Range(30f, Size - 30f);
            if (!IsOpen(x, z) || RoadDist(new Vector2(x, z)) < 12f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0f, z));
            float s = Random.Range(1f, 5f);
            var g = MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x, y + s * 0.2f, z), new Vector3(s, s * 0.6f, s * 0.8f), rocks[Random.Range(0, rocks.Length)]);
            g.transform.rotation = Quaternion.Euler(Random.Range(-8f, 8f), Random.Range(0f, 360f), Random.Range(-8f, 8f));
        }
        for (int i = 0; i < 260; i++)
        {
            float x = Random.Range(30f, Size - 30f), z = Random.Range(30f, Size - 30f);
            if (InZone(new Vector2(x, z), 1.1f) || RoadDist(new Vector2(x, z)) < 8f) continue;
            float y = Ground.SampleHeight(new Vector3(x, 0f, z));
            MapKit.Prim(PrimitiveType.Sphere, parent, new Vector3(x, y + 0.3f, z), new Vector3(1.2f, 0.7f, 1.2f), dry, false);
        }
    }
}
