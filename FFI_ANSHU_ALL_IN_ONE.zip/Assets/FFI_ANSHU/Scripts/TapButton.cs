using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class TapButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public Action onDown, onUp;
    public void OnPointerDown(PointerEventData e) { if (onDown != null) onDown(); }
    public void OnPointerUp(PointerEventData e) { if (onUp != null) onUp(); }
}
