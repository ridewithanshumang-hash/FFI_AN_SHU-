using System.Collections.Generic;
using UnityEngine;

public static class Inv
{
    public static int Medkits, Plates;
}

public enum LootType { Weapon, Ammo, Medkit, Plate }

/// <summary>Spawns loot in houses and open ground, spins it, and auto-picks it up when the player walks close.</summary>
public class LootManager : MonoBehaviour
{
    class Item
    {
        public GameObject go;
        public Transform vis;
        public LootType type;
        public int weaponIdx;
        public float phase;
    }

    static string msg = "";
    static float msgTime = -10f;
    public static string Message { get { return Time.time - msgTime < 2f ? msg : ""; } }
    static void Say(string s) { msg = s; msgTime = Time.time; }

    readonly List<Item> items = new List<Item>();
    readonly Dictionary<Color, Material> mats = new Dictionary<Color, Material>();
    Transform player;
    PlayerController pcomp;
    WeaponController wc;
    Health hp;
    float nextCheck;

    public static LootManager Create(Transform playerT, WeaponController w)
    {
        Inv.Medkits = 0; Inv.Plates = 0;
        var g = new GameObject("Loot");
        var m = g.AddComponent<LootManager>();
        m.player = playerT;
        m.pcomp = playerT.GetComponent<PlayerController>();
        m.wc = w;
        m.hp = playerT.GetComponent<Health>();
        m.SpawnAll();
        return m;
    }

    Material M(Color c)
    {
        Material m;
        if (!mats.TryGetValue(c, out m)) { m = MapKit.Mat(c, 0.2f); mats[c] = m; }
        return m;
    }

    void SpawnAll()
    {
        Vector2 fort = MapBuilder.HotSpot;
        foreach (var p in Buildings.LootSpots)
        {
            if (Random.value < 0.15f) continue;
            bool hot = Vector2.Distance(new Vector2(p.x, p.z), fort) < 75f;
            Add(p, hot);
        }
        int made = 0, tries = 0;
        while (made < 60 && tries < 600)
        {
            tries++;
            float x = Random.Range(80f, 720f), z = Random.Range(80f, 720f);
            if (!MapBuilder.IsOpen(x, z)) continue;
            float y = MapBuilder.Ground.SampleHeight(new Vector3(x, 0f, z)) + 0.7f;
            Add(new Vector3(x, y, z), false);
            made++;
        }
    }

    void Add(Vector3 pos, bool hot)
    {
        var it = new Item();
        float wChance = hot ? 0.4f : 0.2f;
        float r = Random.value;
        if (r < wChance)
        {
            it.type = LootType.Weapon;
            int[] pool = hot ? new[] { 2, 2, 3, 1 } : new[] { 1, 1, 0, 2, 3 };
            it.weaponIdx = pool[Random.Range(0, pool.Length)];
        }
        else
        {
            float s = (r - wChance) / (1f - wChance);
            it.type = s < 0.45f ? LootType.Ammo : (s < 0.75f ? LootType.Medkit : LootType.Plate);
        }

        it.go = new GameObject("LootItem");
        it.go.transform.position = pos;
        it.vis = new GameObject("Vis").transform;
        it.vis.SetParent(it.go.transform, false);
        it.phase = Random.Range(0f, 6.28f);

        Color baseCol;
        switch (it.type)
        {
            case LootType.Weapon:
                baseCol = new Color(1f, 0.85f, 0.2f);
                MapKit.Prim(PrimitiveType.Cube, it.vis, Vector3.zero, new Vector3(0.12f, 0.16f, 0.65f), M(Weapons.All[it.weaponIdx].color), false);
                break;
            case LootType.Ammo:
                baseCol = new Color(1f, 0.55f, 0.1f);
                MapKit.Prim(PrimitiveType.Cube, it.vis, Vector3.zero, new Vector3(0.4f, 0.25f, 0.28f), M(baseCol), false);
                break;
            case LootType.Medkit:
                baseCol = new Color(0.3f, 1f, 0.4f);
                MapKit.Prim(PrimitiveType.Cube, it.vis, Vector3.zero, new Vector3(0.4f, 0.3f, 0.3f), M(Color.white), false);
                MapKit.Prim(PrimitiveType.Cube, it.vis, new Vector3(0f, 0.16f, 0f), new Vector3(0.28f, 0.04f, 0.08f), M(Color.red), false);
                MapKit.Prim(PrimitiveType.Cube, it.vis, new Vector3(0f, 0.16f, 0f), new Vector3(0.08f, 0.04f, 0.28f), M(Color.red), false);
                break;
            default:
                baseCol = new Color(0.4f, 0.6f, 1f);
                MapKit.Prim(PrimitiveType.Cylinder, it.vis, Vector3.zero, new Vector3(0.45f, 0.06f, 0.45f), M(baseCol), false);
                break;
        }
        // coloured pad on the floor so loot is easy to spot
        MapKit.Prim(PrimitiveType.Cylinder, it.go.transform, new Vector3(0f, -0.65f, 0f), new Vector3(0.9f, 0.02f, 0.9f), M(baseCol), false);
        items.Add(it);
    }

    void Update()
    {
        float t = Time.time;
        for (int i = 0; i < items.Count; i++)
        {
            var it = items[i];
            it.vis.localRotation = Quaternion.Euler(0f, t * 90f + it.phase * 57f, 0f);
            it.vis.localPosition = new Vector3(0f, 0.1f + Mathf.Sin(t * 2f + it.phase) * 0.08f, 0f);
        }

        if (Time.time < nextCheck) return;
        nextCheck = Time.time + 0.1f;
        if (hp.Dead || pcomp.Flying) return;
        Vector3 pp = player.position + Vector3.up * 0.9f;
        for (int i = items.Count - 1; i >= 0; i--)
        {
            var it = items[i];
            if ((it.go.transform.position - pp).sqrMagnitude > 6.25f) continue;
            Pickup(it);
            Destroy(it.go);
            items.RemoveAt(i);
        }
    }

    void Pickup(Item it)
    {
        Sfx.Play2D(Sfx.Pickup, 0.8f);
        switch (it.type)
        {
            case LootType.Weapon:
                bool isNew = wc.GiveWeapon(it.weaponIdx);
                Say((isNew ? "PICKED UP " : "+AMMO  ") + Weapons.All[it.weaponIdx].name);
                break;
            case LootType.Ammo: wc.AddAmmoAll(); Say("AMMO PACK"); break;
            case LootType.Medkit: Inv.Medkits++; Say("MEDKIT"); break;
            default: Inv.Plates++; Say("ARMOR PLATE"); break;
        }
    }
}
