using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Match flow, saved profile stats and recent-match history.</summary>
public static class GameFlow
{
    public static bool AutoStart;      // set by PLAY AGAIN: skip the lobby after the scene reloads
    public static float MatchStart;

    public static int Matches { get { return PlayerPrefs.GetInt("matches", 0); } }
    public static int Wins { get { return PlayerPrefs.GetInt("wins", 0); } }
    public static int TotalKills { get { return PlayerPrefs.GetInt("kills", 0); } }
    public static int Best { get { return PlayerPrefs.GetInt("best", 0); } }   // 0 = none yet
    public static int Coins { get { return PlayerPrefs.GetInt("coins", 500); } set { PlayerPrefs.SetInt("coins", Mathf.Max(0, value)); } }
    public static string History { get { return PlayerPrefs.GetString("hist", ""); } }

    public static int RecordResult(int place, int kills, float secs, int players)
    {
        PlayerPrefs.SetInt("matches", Matches + 1);
        if (place == 1) PlayerPrefs.SetInt("wins", Wins + 1);
        PlayerPrefs.SetInt("kills", TotalKills + kills);
        if (Best == 0 || place < Best) PlayerPrefs.SetInt("best", place);
        string entry = place + "|" + kills + "|" + (int)secs + "|" + players;
        var old = History.Split(new[] { ';' }, System.StringSplitOptions.RemoveEmptyEntries);
        string h = entry;
        for (int i = 0; i < old.Length && i < 4; i++) h += ";" + old[i];
        PlayerPrefs.SetString("hist", h);
        int earned = kills * 20 + Mathf.Max(0, players - place) * 5 + (place == 1 ? 200 : 0);
        Coins += earned;
        PlayerPrefs.Save();
        return earned;
    }

    public static void ToLobby() { AutoStart = false; Reload(); }
    public static void PlayAgain() { AutoStart = true; Reload(); }

    static void Reload()
    {
        var sc = SceneManager.GetActiveScene();
#if UNITY_EDITOR
        if (sc.buildIndex < 0 && !string.IsNullOrEmpty(sc.path))
        {
            UnityEditor.SceneManagement.EditorSceneManager.LoadSceneInPlayMode(sc.path, new LoadSceneParameters(LoadSceneMode.Single));
            return;
        }
#endif
        SceneManager.LoadScene(sc.buildIndex >= 0 ? sc.buildIndex : 0);
    }
}
