using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>Right-side drag area that rotates the camera.</summary>
public class LookPad : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    int activeId = int.MinValue;

    public void OnPointerDown(PointerEventData e) { if (activeId == int.MinValue) activeId = e.pointerId; }

    public void OnDrag(PointerEventData e)
    {
        if (e.pointerId != activeId) return;
        MobileInput.LookDelta += e.delta;
    }

    public void OnPointerUp(PointerEventData e) { if (e.pointerId == activeId) activeId = int.MinValue; }
}
