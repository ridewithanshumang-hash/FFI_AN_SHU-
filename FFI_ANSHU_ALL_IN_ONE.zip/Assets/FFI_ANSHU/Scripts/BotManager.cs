using UnityEngine;

public static class GameStats
{
    public static int Kills;
    public static int BotsAlive;
    public static bool PlayerFlying;
}

public static class BotManager
{
    /// <summary>Scatters n bots over open ground, at least 80 m away from the player.</summary>
    public static void Spawn(int n, Transform player)
    {
        GameStats.Kills = 0;
        GameStats.BotsAlive = 0;
        var root = new GameObject("Bots").transform;
        int made = 0, tries = 0;
        Vector2 pp = new Vector2(player.position.x, player.position.z);
        while (made < n && tries < 800)
        {
            tries++;
            float x = Random.Range(100f, 700f), z = Random.Range(100f, 700f);
            if (!MapBuilder.IsOpen(x, z)) continue;
            if (Vector2.Distance(new Vector2(x, z), pp) < 80f) continue;
            float y = MapBuilder.Ground.SampleHeight(new Vector3(x, 0f, z)) + 0.3f;
            var b = Bot.Create(new Vector3(x, y, z), player, made % 4);
            b.transform.SetParent(root, true);
            b.StartDrop(Random.Range(4f, 30f));
            made++;
            GameStats.BotsAlive++;
        }
    }
}
