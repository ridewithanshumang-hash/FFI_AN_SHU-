using UnityEngine;

/// <summary>Player-adjustable settings, saved in PlayerPrefs.</summary>
public static class GameSettings
{
    public static int Quality { get { return PlayerPrefs.GetInt("gfx", 1); } set { PlayerPrefs.SetInt("gfx", Mathf.Clamp(value, 0, 2)); } }
    public static float MusicVol { get { return PlayerPrefs.GetFloat("music", 0.5f); } set { PlayerPrefs.SetFloat("music", Mathf.Clamp01(value)); } }
    public static float SfxVol { get { return PlayerPrefs.GetFloat("sfx", 0.8f); } set { PlayerPrefs.SetFloat("sfx", Mathf.Clamp01(value)); } }
    public static int Players { get { return PlayerPrefs.GetInt("players", 20); } set { PlayerPrefs.SetInt("players", value); } }   // 20 / 35 / 50
    public static int Fps { get { return PlayerPrefs.GetInt("fps", 60); } set { PlayerPrefs.SetInt("fps", value); } }               // 30 / 60

    public static string QualityName { get { int q = Quality; return q == 0 ? "LOW" : (q == 1 ? "MEDIUM" : "HIGH"); } }

    /// <summary>Applies graphics + audio settings. Note: shadow settings need the Built-in pipeline ("3D" template); URP reads them from its asset.</summary>
    public static void Apply()
    {
        int q = Quality;
        QualitySettings.shadows = q == 0 ? ShadowQuality.Disable : (q == 1 ? ShadowQuality.HardOnly : ShadowQuality.All);
        QualitySettings.shadowDistance = q == 0 ? 0f : (q == 1 ? 45f : 75f);
        QualitySettings.shadowCascades = q == 2 ? 2 : 1;
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = Fps;
        var cam = Camera.main;
        if (cam != null) cam.farClipPlane = q == 0 ? 420f : 700f;
#if !UNITY_EDITOR
        float sc = q == 0 ? 0.6f : (q == 1 ? 0.8f : 1f);
        Screen.SetResolution(Mathf.RoundToInt(Display.main.systemWidth * sc), Mathf.RoundToInt(Display.main.systemHeight * sc), true);
#endif
        Sfx.ApplyVolumes();
    }
}
