using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Lobby store: TOP UP (test mode), REDEEM / REFERRAL codes, SPIN WHEEL, shortcut to rare skins.</summary>
public partial class Lobby
{
    struct Prize { public string label; public int kind, amount, weight; public Color col; }   // kind 0 coins, 1 diamonds, 2 rare skin

    static readonly Prize[] Prizes =
    {
        new Prize{ label="200 COINS",     kind=0, amount=200,  weight=25, col=new Color(0.95f,0.60f,0.15f) },
        new Prize{ label="50 DIAMONDS",   kind=1, amount=50,   weight=22, col=new Color(0.20f,0.55f,0.85f) },
        new Prize{ label="500 COINS",     kind=0, amount=500,  weight=12, col=new Color(0.85f,0.45f,0.10f) },
        new Prize{ label="100 DIAMONDS",  kind=1, amount=100,  weight=12, col=new Color(0.15f,0.65f,0.70f) },
        new Prize{ label="RARE SKIN",     kind=2, amount=0,    weight=3,  col=new Color(0.65f,0.25f,0.85f) },
        new Prize{ label="20 DIAMONDS",   kind=1, amount=20,   weight=18, col=new Color(0.25f,0.45f,0.75f) },
        new Prize{ label="1000 COINS",    kind=0, amount=1000, weight=6,  col=new Color(0.80f,0.30f,0.15f) },
        new Prize{ label="300 DIAMONDS",  kind=1, amount=300,  weight=2,  col=new Color(0.90f,0.75f,0.15f) },
    };

    GameObject panelTop, panelRedeem, panelSpin;
    Transform wheel;
    Text spinStatus, spinResult, spinBtnLbl, topBal, redeemMsg;
    InputField redeemIn, refIn;
    bool spinning;
    float spinT, spinFrom, spinTo, wheelCw;
    string spinMsg = "";
    static Sprite circleSprite;

    static Sprite Circle()
    {
        if (circleSprite != null) return circleSprite;
        const int n = 128;
        var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(n * 0.5f, n * 0.5f));
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, Mathf.Clamp01(n * 0.5f - d)));
            }
        tex.Apply();
        circleSprite = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
        return circleSprite;
    }

    InputField MakeInput(Transform parent, string hint, Vector2 pos, Vector2 size)
    {
        var bg = UiKit.Box("Input", parent, Half, pos, size, new Color(1f, 1f, 1f, 0.16f), true);
        var inp = bg.gameObject.AddComponent<InputField>();
        var txt = UiKit.Label(bg.transform, "", 34, TextAnchor.MiddleCenter);
        txt.supportRichText = false;
        var ph = UiKit.Label(bg.transform, hint, 28, TextAnchor.MiddleCenter);
        ph.color = new Color(1f, 1f, 1f, 0.4f);
        inp.targetGraphic = bg;
        inp.textComponent = txt;
        inp.placeholder = ph;
        inp.characterLimit = 20;
        inp.onValueChanged.AddListener(v => { string u = v.ToUpper(); if (u != v) inp.text = u; });
        return inp;
    }

    void BuildStoreUI(Transform cv)
    {
        // main-screen buttons (right column)
        Vector2 tr = new Vector2(1f, 1f);
        var bsz = new Vector2(340, 84);
        var gold = new Color(0.9f, 0.7f, 0.1f, 0.97f);
        UiKit.Btn(cv, "TOP UP", 32, tr, new Vector2(-220, -150), bsz, gold, () => ShowPanel(panelTop));
        UiKit.Btn(cv, "SPIN WHEEL", 32, tr, new Vector2(-220, -250), bsz, new Color(0.65f, 0.3f, 0.85f, 0.97f), () => ShowPanel(panelSpin));
        UiKit.Btn(cv, "REDEEM CODE", 32, tr, new Vector2(-220, -350), bsz, BtnCol, () => ShowPanel(panelRedeem));
        UiKit.Btn(cv, "RARE SKINS", 32, tr, new Vector2(-220, -450), bsz, new Color(0.25f, 0.55f, 0.95f, 0.97f), OpenRareSkins);

        // ---- TOP UP (test mode) ----
        panelTop = MakePanel("TOP UP DIAMONDS", new Vector2(-80, 0), new Vector2(880, 620));
        topBal = UiKit.LabelAt(panelTop.transform, "", 34, TextAnchor.MiddleCenter, Half, new Vector2(0, 205), new Vector2(800, 56));
        topBal.color = new Color(0.5f, 0.85f, 1f);
        int[] amt = { 100, 520, 1100, 2400 };
        string[] price = { "Rs 79", "Rs 399", "Rs 799", "Rs 1,599" };
        for (int i = 0; i < amt.Length; i++)
        {
            int a = amt[i];
            UiKit.Btn(panelTop.transform, a + " DIAMONDS     " + price[i], 32, Half, new Vector2(0, 120 - i * 95), new Vector2(620, 80), BtnCol, () => TopUp(a));
        }
        UiKit.LabelAt(panelTop.transform, "TEST MODE: no real money is charged, diamonds are added free.\nReal payments need Google Play Billing, which is not connected yet.", 22, TextAnchor.MiddleCenter, Half, new Vector2(0, -255), new Vector2(820, 80)).color = new Color(1f, 1f, 1f, 0.65f);
        refresh.Add(() => { topBal.text = "YOUR DIAMONDS:  " + Wallet.Diamonds; });

        // ---- REDEEM / REFERRAL ----
        panelRedeem = MakePanel("REDEEM & REFERRAL", new Vector2(-80, 0), new Vector2(880, 620));
        var rp = panelRedeem.transform;
        UiKit.LabelAt(rp, "REDEEM CODE", 28, TextAnchor.MiddleLeft, Half, new Vector2(-140, 160), new Vector2(520, 44)).color = Saffron;
        redeemIn = MakeInput(rp, "ENTER CODE", new Vector2(-110, 100), new Vector2(520, 80));
        UiKit.Btn(rp, "REDEEM", 30, Half, new Vector2(250, 100), new Vector2(230, 80), new Color(0.2f, 0.75f, 0.3f, 0.97f), () =>
        {
            redeemMsg.text = Wallet.Redeem(redeemIn.text); redeemIn.text = ""; RefreshChar();
        });
        UiKit.LabelAt(rp, "REFERRAL CODE", 28, TextAnchor.MiddleLeft, Half, new Vector2(-140, 20), new Vector2(520, 44)).color = Saffron;
        refIn = MakeInput(rp, "ENTER REFERRAL CODE", new Vector2(-110, -40), new Vector2(520, 80));
        UiKit.Btn(rp, "APPLY", 30, Half, new Vector2(250, -40), new Vector2(230, 80), new Color(0.2f, 0.75f, 0.3f, 0.97f), () =>
        {
            redeemMsg.text = Wallet.UseReferral(refIn.text); refIn.text = "";
        });
        redeemMsg = UiKit.LabelAt(rp, "", 30, TextAnchor.MiddleCenter, Half, new Vector2(0, -150), new Vector2(820, 100));
        redeemMsg.color = new Color(0.6f, 1f, 0.6f);
        UiKit.LabelAt(rp, "Each code works once on this device.", 22, TextAnchor.MiddleCenter, Half, new Vector2(0, -250), new Vector2(800, 40)).color = new Color(1f, 1f, 1f, 0.55f);

        // ---- SPIN WHEEL ----
        panelSpin = MakePanel("SPIN WHEEL", new Vector2(-80, 0), new Vector2(1000, 720));
        var sp = panelSpin.transform;
        const float D = 440f;
        Vector2 wc = new Vector2(-250f, -30f);
        var wrt = UiKit.Rect("Wheel", sp);
        wrt.anchorMin = wrt.anchorMax = Half; wrt.pivot = Half;
        wrt.anchoredPosition = wc; wrt.sizeDelta = new Vector2(D, D);
        wheel = wrt;
        var rim = UiKit.Box("Rim", wheel, Half, Vector2.zero, new Vector2(D + 24f, D + 24f), new Color(0.95f, 0.8f, 0.3f), false);
        rim.sprite = Circle();
        int n = Prizes.Length;
        float seg = 360f / n;
        for (int i = 0; i < n; i++)
        {
            var w = UiKit.Box("Wedge" + i, wheel, Half, Vector2.zero, new Vector2(D, D), Prizes[i].col, false);
            w.sprite = Circle();
            w.type = Image.Type.Filled;
            w.fillMethod = Image.FillMethod.Radial360;
            w.fillOrigin = (int)Image.Origin360.Top;
            w.fillClockwise = true;
            w.fillAmount = 1f / n;
            w.rectTransform.localRotation = Quaternion.Euler(0f, 0f, -seg * i);
            float ang = seg * i + seg * 0.5f;
            float th = ang * Mathf.Deg2Rad;
            var t = UiKit.LabelAt(wheel, Prizes[i].label, 20, TextAnchor.MiddleCenter, Half, new Vector2(Mathf.Sin(th), Mathf.Cos(th)) * 140f, new Vector2(130, 36));
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.rectTransform.localRotation = Quaternion.Euler(0f, 0f, 90f - ang);
        }
        var hub = UiKit.Box("Hub", wheel, Half, Vector2.zero, new Vector2(60, 60), new Color(0.1f, 0.08f, 0.12f), false);
        hub.sprite = Circle();
        var ptr = UiKit.Box("Pointer", sp, Half, wc + new Vector2(0f, D * 0.5f + 8f), new Vector2(40, 40), new Color(0.9f, 0.15f, 0.15f), false);
        ptr.rectTransform.localRotation = Quaternion.Euler(0f, 0f, 45f);

        spinStatus = UiKit.LabelAt(sp, "", 28, TextAnchor.MiddleCenter, Half, new Vector2(230, 130), new Vector2(430, 140));
        spinResult = UiKit.LabelAt(sp, "", 34, TextAnchor.MiddleCenter, Half, new Vector2(230, 0), new Vector2(430, 140));
        spinResult.color = Saffron;
        var sb = UiKit.Btn(sp, "", 30, Half, new Vector2(230, -130), new Vector2(400, 90), new Color(0.2f, 0.75f, 0.3f, 0.97f), DoSpin);
        spinBtnLbl = sb.GetComponentInChildren<Text>();
        refresh.Add(() =>
        {
            bool free = Wallet.FreeSpinReady;
            spinStatus.text = (free ? "FREE SPIN READY!" : "FREE SPIN USED TODAY\nCome back tomorrow") + "\nDIAMONDS:  " + Wallet.Diamonds;
            spinBtnLbl.text = spinning ? "SPINNING..." : (free ? "SPIN  (FREE)" : "SPIN  -  " + Wallet.PaidSpinCost + " DIAMONDS");
        });
    }

    void TopUp(int amount)
    {
        Wallet.Diamonds += amount;
        PlayerPrefs.Save();
        topBal.text = "YOUR DIAMONDS:  " + Wallet.Diamonds + "     (+" + amount + ")";
    }

    void OpenRareSkins()
    {
        int first = 0;
        for (int i = 0; i < CharacterSkins.All.Length; i++)
            if (CharacterSkins.All[i].rarity > 0) { first = i; break; }
        SetSkin(first);
        ShowPanel(panelChar);
    }

    int PickPrize()
    {
        int total = 0;
        foreach (var p in Prizes) total += p.weight;
        int r = Random.Range(0, total);
        for (int i = 0; i < Prizes.Length; i++)
        {
            r -= Prizes[i].weight;
            if (r < 0) return i;
        }
        return 0;
    }

    string GrantPrize(int idx)
    {
        var p = Prizes[idx];
        string msg;
        if (p.kind == 0) { GameFlow.Coins += p.amount; msg = "YOU WON\n" + p.amount + " COINS"; }
        else if (p.kind == 1) { Wallet.Diamonds += p.amount; msg = "YOU WON\n" + p.amount + " DIAMONDS"; }
        else
        {
            var pool = new List<int>();
            for (int i = 0; i < CharacterSkins.All.Length; i++)
                if (CharacterSkins.All[i].rarity > 0 && !CharacterSkins.Owned(i)) pool.Add(i);
            if (pool.Count == 0) { Wallet.Diamonds += 500; msg = "ALL RARE SKINS OWNED\n+500 DIAMONDS"; }
            else
            {
                int s = pool[Random.Range(0, pool.Count)];
                CharacterSkins.Unlock(s);
                msg = "YOU WON " + CharacterSkins.RarityNames[CharacterSkins.All[s].rarity] + " SKIN\n" + CharacterSkins.All[s].name.ToUpper();
            }
        }
        PlayerPrefs.Save();
        RefreshChar();
        return msg;
    }

    void DoSpin()
    {
        if (spinning) return;
        bool free = Wallet.FreeSpinReady;
        if (!free && !Wallet.Spend(Wallet.PaidSpinCost)) { spinResult.text = "NOT ENOUGH DIAMONDS"; return; }
        if (free) Wallet.UseFreeSpin();
        int idx = PickPrize();
        spinMsg = GrantPrize(idx);   // applied immediately so closing the app mid-spin cannot lose the prize
        spinResult.text = "";
        float seg = 360f / Prizes.Length;
        float centre = seg * idx + seg * 0.5f;
        float cur = wheelCw % 360f;
        float delta = (((360f - centre) - cur) % 360f + 360f) % 360f;
        spinFrom = wheelCw;
        spinTo = wheelCw + 360f * 5f + delta;
        spinT = 0f;
        spinning = true;
    }

    void StoreUpdate()
    {
        if (!spinning) return;
        spinT += Time.deltaTime / 4.5f;
        float k = Mathf.Clamp01(spinT);
        float e = 1f - Mathf.Pow(1f - k, 3f);
        wheelCw = Mathf.Lerp(spinFrom, spinTo, e);
        wheel.localRotation = Quaternion.Euler(0f, 0f, -wheelCw);
        if (k >= 1f) { spinning = false; spinResult.text = spinMsg; }
    }
}
