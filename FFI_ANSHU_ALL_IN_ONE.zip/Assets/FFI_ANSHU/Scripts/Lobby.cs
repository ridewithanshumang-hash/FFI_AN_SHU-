using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>3D lobby (sandstone courtyard, lanterns, character on a podium) + menus: character, map, inventory/profile, settings, matchmaking.</summary>
public partial class Lobby : MonoBehaviour
{
    static readonly Vector2 Half = new Vector2(0.5f, 0.5f);
    static readonly Color Dark = new Color(0.07f, 0.06f, 0.09f, 0.93f);
    static readonly Color BtnCol = new Color(0.95f, 0.6f, 0.15f, 0.95f);
    static readonly Color Saffron = new Color(1f, 0.62f, 0.1f, 1f);

    GameBootstrap boot;
    Camera cam;
    Transform root3d, avatar;
    Canvas canvas;
    GameObject panelChar, panelMap, panelInv, panelSet, panelMatch, openPanel;
    Text charName, charSub, matchCount, matchStatus, invText, profileText, charBtnLbl;
    readonly List<System.Action> refresh = new List<System.Action>();
    int skin;
    float matchT;
    bool matching, started;

    public static Lobby Create(GameBootstrap b, Camera c, DayNightCycle dn)
    {
        dn.timeOfDay = 0.68f;
        dn.dayLengthSeconds = 1000000f;   // freeze at golden hour
        var g = new GameObject("Lobby");
        var l = g.AddComponent<Lobby>();
        l.boot = b; l.cam = c;
        l.skin = PlayerPrefs.GetInt("skin", 0);
        l.Build3D();
        l.BuildUI();
        return l;
    }

    // ---------------- 3D stage ----------------
    void Build3D()
    {
        root3d = new GameObject("LobbyStage").transform;
        var sandM = MapKit.Mat(MapKit.C(214, 176, 112));
        var goldM = MapKit.Mat(MapKit.C(228, 182, 98));
        var trimM = MapKit.Mat(MapKit.C(178, 118, 58));
        var carpet = MapKit.Mat(MapKit.C(150, 30, 40));
        var lamp = MapKit.Mat(MapKit.C(255, 170, 60), 0f);

        MapKit.Prim(PrimitiveType.Cube, root3d, new Vector3(0f, -0.5f, 0f), new Vector3(70f, 1f, 70f), sandM, false);
        MapKit.Wall(root3d, new Vector3(0f, 0f, -4f), true, 16f, 7f, 0.6f, goldM,
            new MapKit.Op(-5f, 2.2f, 1.4f, 4.4f), new MapKit.Op(0f, 2.2f, 1.4f, 4.4f), new MapKit.Op(5f, 2.2f, 1.4f, 4.4f));
        for (float x = -7.5f; x <= 7.6f; x += 1.5f)
            MapKit.Prim(PrimitiveType.Cube, root3d, new Vector3(x, 7.4f, -4f), new Vector3(0.9f, 0.8f, 0.5f), goldM, false);

        foreach (float sx in new[] { -3.6f, 3.6f })
        {
            MapKit.Prim(PrimitiveType.Cube, root3d, new Vector3(sx, 2.5f, -2f), new Vector3(0.7f, 5f, 0.7f), trimM, false);
            MapKit.Prim(PrimitiveType.Sphere, root3d, new Vector3(sx, 3.7f, -1.3f), new Vector3(0.5f, 0.6f, 0.5f), lamp, false);
            var lg = new GameObject("Lantern").transform;
            lg.SetParent(root3d, false);
            lg.position = new Vector3(sx, 3.7f, -1.0f);
            var li = lg.gameObject.AddComponent<Light>();
            li.type = LightType.Point; li.color = new Color(1f, 0.7f, 0.35f); li.intensity = 1.6f; li.range = 9f;
        }
        MapKit.Prim(PrimitiveType.Cube, root3d, new Vector3(0f, 5.2f, -2f), new Vector3(8f, 0.6f, 0.9f), trimM, false);
        MapKit.Prim(PrimitiveType.Sphere, root3d, new Vector3(0f, 5.9f, -2f), new Vector3(1.8f, 1.5f, 1.8f), goldM, false);
        MapKit.Prim(PrimitiveType.Cylinder, root3d, new Vector3(0f, 7.0f, -2f), new Vector3(0.12f, 0.6f, 0.12f), trimM, false);

        MapKit.Prim(PrimitiveType.Cube, root3d, new Vector3(1f, 0.03f, 2.5f), new Vector3(4.5f, 0.04f, 8f), carpet, false);
        MapKit.Prim(PrimitiveType.Cylinder, root3d, new Vector3(1f, 0.12f, 0.8f), new Vector3(3.2f, 0.12f, 3.2f), trimM, false);

        MapKit.Prim(PrimitiveType.Sphere, root3d, new Vector3(-30f, -4f, -35f), new Vector3(80f, 14f, 40f), sandM, false);
        MapKit.Prim(PrimitiveType.Sphere, root3d, new Vector3(35f, -5f, -40f), new Vector3(90f, 18f, 40f), sandM, false);

        RebuildAvatar();
        cam.transform.position = new Vector3(0.2f, 1.45f, 5.6f);
        cam.transform.LookAt(new Vector3(0.9f, 1.1f, 0f));
        cam.fieldOfView = 38f;
    }

    void RebuildAvatar()
    {
        if (avatar != null) Destroy(avatar.gameObject);
        avatar = Avatar.Build(root3d, CharacterSkins.Get(skin));
        avatar.position = new Vector3(1f, 0.24f, 0.8f);
    }

    void SetSkin(int i)
    {
        int n = CharacterSkins.All.Length;
        skin = ((i % n) + n) % n;
        RebuildAvatar();
        RefreshChar();
    }

    // ---------------- UI ----------------
    readonly Text[] mapLbl = new Text[2];

    void SetMap(int m)
    {
        PlayerPrefs.SetInt("map", m);
        mapLbl[0].text = "JAISALMER FORT  -  golden desert city  -  800 x 800 m" + (m == 0 ? "   [SELECTED]" : "");
        mapLbl[1].text = "KALAHARI  -  red desert, camps, dinosaur fossil  -  800 x 800 m" + (m == 1 ? "   [SELECTED]" : "");
    }

    GameObject MakePanel(string title, Vector2 pos, Vector2 size)
    {
        var p = UiKit.Box(title, canvas.transform, Half, pos, size, Dark, true);
        UiKit.LabelAt(p.transform, title, 44, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0, -45), new Vector2(size.x - 160, 70)).color = Saffron;
        UiKit.Btn(p.transform, "X", 34, new Vector2(1f, 1f), new Vector2(-45, -45), new Vector2(64, 64), new Color(0.8f, 0.25f, 0.2f, 0.95f), ClosePanel);
        p.gameObject.SetActive(false);
        return p.gameObject;
    }

    void ShowPanel(GameObject g)
    {
        if (openPanel != null) openPanel.SetActive(false);
        openPanel = g;
        g.SetActive(true);
        PlayerPrefs.Save();
    }

    void ClosePanel()
    {
        if (openPanel != null) openPanel.SetActive(false);
        openPanel = null;
        PlayerPrefs.Save();
    }

    void BuildUI()
    {
        canvas = UiKit.NewCanvas("LobbyUI");
        var cv = canvas.transform;

        UiKit.LabelAt(cv, "FFI_ANSHU", 90, TextAnchor.MiddleLeft, new Vector2(0f, 1f), new Vector2(420, -75), new Vector2(760, 120)).color = Saffron;
        UiKit.LabelAt(cv, "DESERT ROYALE  -  JAISALMER  /  KALAHARI", 30, TextAnchor.MiddleLeft, new Vector2(0f, 1f), new Vector2(420, -150), new Vector2(760, 50));
        profileText = UiKit.LabelAt(cv, "", 26, TextAnchor.MiddleRight, new Vector2(1f, 1f), new Vector2(-40, -45), new Vector2(900, 50));

        Vector2 lc = new Vector2(0f, 0.5f);
        var sz = new Vector2(340, 84);
        UiKit.Btn(cv, "CHARACTER", 32, lc, new Vector2(220, 110), sz, BtnCol, () => ShowPanel(panelChar));
        UiKit.Btn(cv, "MAP", 32, lc, new Vector2(220, 10), sz, BtnCol, () => ShowPanel(panelMap));
        UiKit.Btn(cv, "INVENTORY", 32, lc, new Vector2(220, -90), sz, BtnCol, () => ShowPanel(panelInv));
        UiKit.Btn(cv, "SETTINGS", 32, lc, new Vector2(220, -190), sz, BtnCol, () => ShowPanel(panelSet));
        UiKit.Btn(cv, "PLAY", 56, new Vector2(1f, 0f), new Vector2(-280, 120), new Vector2(440, 140), new Color(0.2f, 0.75f, 0.3f, 0.97f), StartMatchmaking);

        // Character
        panelChar = MakePanel("CHARACTER", new Vector2(-120, -230), new Vector2(760, 420));
        charName = UiKit.LabelAt(panelChar.transform, "", 52, TextAnchor.MiddleCenter, Half, new Vector2(0, 10), new Vector2(520, 70));
        charSub = UiKit.LabelAt(panelChar.transform, "", 28, TextAnchor.MiddleCenter, Half, new Vector2(0, -60), new Vector2(700, 50));
        UiKit.LabelAt(panelChar.transform, "Premium outfits cost diamonds or can be won on the spin wheel.", 22, TextAnchor.MiddleCenter, Half, new Vector2(0, -115), new Vector2(700, 40)).color = new Color(1, 1, 1, 0.6f);
        UiKit.Btn(panelChar.transform, "<", 44, Half, new Vector2(-300, 10), new Vector2(90, 90), BtnCol, () => SetSkin(skin - 1));
        UiKit.Btn(panelChar.transform, ">", 44, Half, new Vector2(300, 10), new Vector2(90, 90), BtnCol, () => SetSkin(skin + 1));
        var act = UiKit.Btn(panelChar.transform, "", 30, Half, new Vector2(0, -170), new Vector2(380, 70), new Color(0.2f, 0.75f, 0.3f, 0.97f), CharAction);
        charBtnLbl = act.GetComponentInChildren<Text>();
        RefreshChar();

        // Map
        panelMap = MakePanel("MAP", new Vector2(-80, 0), new Vector2(860, 420));
        var mb1 = UiKit.Btn(panelMap.transform, "", 28, Half, new Vector2(0, 50), new Vector2(780, 120), BtnCol, () => SetMap(0));
        mapLbl[0] = mb1.GetComponentInChildren<Text>();
        var mb2 = UiKit.Btn(panelMap.transform, "", 28, Half, new Vector2(0, -90), new Vector2(780, 120), BtnCol, () => SetMap(1));
        mapLbl[1] = mb2.GetComponentInChildren<Text>();
        SetMap(PlayerPrefs.GetInt("map", 0));

        // Inventory / profile / recent matches
        panelInv = MakePanel("INVENTORY & PROFILE", new Vector2(-80, 0), new Vector2(880, 600));
        invText = UiKit.LabelAt(panelInv.transform, "", 26, TextAnchor.UpperLeft, Half, new Vector2(0, -40), new Vector2(800, 460));
        refresh.Add(RefreshInv);

        // Settings
        panelSet = MakePanel("SETTINGS", new Vector2(-80, 0), new Vector2(880, 600));
        var sp = panelSet.transform;
        Row(sp, 170f, "GRAPHICS", () => GameSettings.QualityName, () => GameSettings.Quality--, () => GameSettings.Quality++);
        Row(sp, 95f, "FPS LIMIT", () => GameSettings.Fps.ToString(), () => GameSettings.Fps = 30, () => GameSettings.Fps = 60);
        Row(sp, 20f, "MUSIC", () => Mathf.RoundToInt(GameSettings.MusicVol * 100f) + "%", () => GameSettings.MusicVol -= 0.1f, () => GameSettings.MusicVol += 0.1f);
        Row(sp, -55f, "SOUND EFFECTS", () => Mathf.RoundToInt(GameSettings.SfxVol * 100f) + "%", () => GameSettings.SfxVol -= 0.1f, () => GameSettings.SfxVol += 0.1f);
        Row(sp, -130f, "SENSITIVITY", () => MobileInput.Sensitivity.ToString("0.0"), () => MobileInput.Sensitivity -= 0.1f, () => MobileInput.Sensitivity += 0.1f);
        Row(sp, -205f, "MATCH SIZE", () => GameSettings.Players + " PLAYERS", () => CycleSize(-1), () => CycleSize(1));

        BuildStoreUI(cv);

        // Matchmaking overlay
        var mm = UiKit.Box("Matchmaking", cv, Half, Vector2.zero, new Vector2(4000, 4000), new Color(0f, 0f, 0f, 0.88f), true);
        panelMatch = mm.gameObject;
        matchStatus = UiKit.LabelAt(mm.transform, "FINDING PLAYERS...", 64, TextAnchor.MiddleCenter, Half, new Vector2(0, 120), new Vector2(1400, 100));
        matchCount = UiKit.LabelAt(mm.transform, "", 90, TextAnchor.MiddleCenter, Half, new Vector2(0, 0), new Vector2(900, 130));
        matchCount.color = Saffron;
        UiKit.LabelAt(mm.transform, "Offline match: free slots are filled with bots.", 28, TextAnchor.MiddleCenter, Half, new Vector2(0, -90), new Vector2(1200, 50)).color = new Color(1, 1, 1, 0.6f);
        UiKit.Btn(mm.transform, "CANCEL", 34, Half, new Vector2(0, -190), new Vector2(300, 90), new Color(0.8f, 0.25f, 0.2f, 0.95f), CancelMatch);
        panelMatch.SetActive(false);
    }

    void Row(Transform p, float y, string label, System.Func<string> val, System.Action minus, System.Action plus)
    {
        UiKit.LabelAt(p, label, 30, TextAnchor.MiddleLeft, Half, new Vector2(-260, y), new Vector2(380, 60));
        UiKit.Btn(p, "<", 34, Half, new Vector2(40, y), new Vector2(70, 56), BtnCol, () => { minus(); GameSettings.Apply(); });
        var t = UiKit.LabelAt(p, "", 30, TextAnchor.MiddleCenter, Half, new Vector2(190, y), new Vector2(210, 56));
        UiKit.Btn(p, ">", 34, Half, new Vector2(340, y), new Vector2(70, 56), BtnCol, () => { plus(); GameSettings.Apply(); });
        refresh.Add(() => { t.text = val(); });
    }

    void CycleSize(int d)
    {
        int[] sizes = { 20, 35, 50 };
        int i = System.Array.IndexOf(sizes, GameSettings.Players);
        if (i < 0) i = 0;
        GameSettings.Players = sizes[Mathf.Clamp(i + d, 0, sizes.Length - 1)];
    }

    string charNote = "";

    void RefreshChar()
    {
        if (charName == null) return;
        var sk = CharacterSkins.Get(skin);
        charName.text = sk.name.ToUpper();
        charName.color = CharacterSkins.RarityColor(sk.rarity);
        bool owned = CharacterSkins.Owned(skin);
        bool equipped = owned && PlayerPrefs.GetInt("skin", 0) == skin;
        charSub.text = charNote.Length > 0 ? charNote :
            (skin + 1) + " / " + CharacterSkins.All.Length + "   " + CharacterSkins.RarityNames[sk.rarity] +
            "   COINS " + GameFlow.Coins + "   DIAMONDS " + Wallet.Diamonds;
        charNote = "";
        if (charBtnLbl != null)
            charBtnLbl.text = equipped ? "EQUIPPED" : (owned ? "EQUIP" : (sk.diamonds > 0 ? "BUY  " + sk.diamonds + " DIAMONDS" : "BUY  " + sk.price + " COINS"));
    }

    void CharAction()
    {
        var s = CharacterSkins.Get(skin);
        if (CharacterSkins.Owned(skin)) PlayerPrefs.SetInt("skin", skin);
        else if (s.diamonds > 0)
        {
            if (Wallet.Spend(s.diamonds)) { CharacterSkins.Unlock(skin); PlayerPrefs.SetInt("skin", skin); }
            else charNote = "NOT ENOUGH DIAMONDS";
        }
        else if (GameFlow.Coins >= s.price)
        {
            GameFlow.Coins -= s.price;
            CharacterSkins.Unlock(skin);
            PlayerPrefs.SetInt("skin", skin);
        }
        else charNote = "NOT ENOUGH COINS";
        PlayerPrefs.Save();
        RefreshChar();
    }

    void RefreshInv()
    {
        string s = "PROFILE\n  Matches played: " + GameFlow.Matches + "     Wins: " + GameFlow.Wins +
                   "     Total kills: " + GameFlow.TotalKills + "     Best place: " + (GameFlow.Best == 0 ? "-" : "#" + GameFlow.Best) +
                   "\n\nOUTFITS\n  " + CharacterSkins.OwnedCount() + " / " + CharacterSkins.All.Length + " unlocked\n\nWEAPONS (found as loot in a match)\n  ";
        for (int i = 0; i < Weapons.All.Length; i++) s += Weapons.All[i].name + (i < Weapons.All.Length - 1 ? "   -   " : "");
        s += "\n\nRECENT MATCHES\n";
        var hist = GameFlow.History.Split(new[] { ';' }, System.StringSplitOptions.RemoveEmptyEntries);
        if (hist.Length == 0) s += "  No matches yet.";
        for (int i = 0; i < hist.Length; i++)
        {
            var f = hist[i].Split('|');
            if (f.Length < 4) continue;
            int secs = int.Parse(f[2]);
            s += "  " + (i + 1) + ".   #" + f[0] + " / " + f[3] + "     " + f[1] + " kills     " + (secs / 60) + ":" + (secs % 60).ToString("00") + "\n";
        }
        invText.text = s;
    }

    // ---------------- matchmaking ----------------
    void StartMatchmaking()
    {
        if (matching) return;
        ClosePanel();
        matching = true; matchT = 0f;
        matchStatus.text = "FINDING PLAYERS...";
        panelMatch.SetActive(true);
    }

    void CancelMatch()
    {
        if (started) return;
        matching = false;
        panelMatch.SetActive(false);
    }

    void Update()
    {
        if (avatar != null)
        {
            avatar.localRotation = Quaternion.Euler(0f, Mathf.Sin(Time.time * 0.6f) * 22f, 0f);
            avatar.position = new Vector3(1f, 0.24f + Mathf.Sin(Time.time * 1.6f) * 0.01f, 0.8f);
        }
        profileText.text = "MATCHES " + GameFlow.Matches + "    WINS " + GameFlow.Wins + "    KILLS " + GameFlow.TotalKills + "    COINS " + GameFlow.Coins + "    DIAMONDS " + Wallet.Diamonds;
        StoreUpdate();
        if (openPanel != null) foreach (var r in refresh) r();

        if (!matching || started) return;
        matchT += Time.deltaTime;
        int n = GameSettings.Players;
        float k = Mathf.Clamp01(matchT / 3.5f);
        matchCount.text = (1 + Mathf.RoundToInt(k * (n - 1))) + " / " + n;
        if (matchT >= 3.5f) matchStatus.text = "MATCH FOUND  -  " + (PlayerPrefs.GetInt("map", 0) == 1 ? "KALAHARI" : "JAISALMER FORT");
        if (matchT >= 4.5f)
        {
            started = true;
            Destroy(canvas.gameObject);
            Destroy(root3d.gameObject);
            boot.StartMatch();
            Destroy(gameObject);
        }
    }
}
