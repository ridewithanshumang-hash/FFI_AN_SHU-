using UnityEngine;
using UnityEngine.UI;

/// <summary>Combat part of the HUD: fire/aim/reload/swap buttons, crosshair, health bar, ammo, kills, death screen.</summary>
public partial class MobileHUD
{
    Image hpFill, hurtFlash, deathPanel, aimBtn;
    GameObject respawnBtn;
    Text hpText, ammoText, killText, centerText, hitMark;
    bool fireA, fireB, hooked;
    Text zoneText, toastText, promptText, healLbl, armorLbl, bagInfo;
    GameObject bagPanel;
    readonly Text[] bagRows = new Text[4];
    Image carBtn;
    GameObject lobbyBtn;
    Text deathTitle, deathStats;
    bool resultShown;
    Text carLbl;
    float hurtAlpha, hitTimer;

    Image Bar(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color c)
    {
        var rt = NewRect(name, parent);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        var img = rt.gameObject.AddComponent<Image>();
        img.color = c;
        img.raycastTarget = false;
        return img;
    }

    RectTransform Anchored(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var rt = NewRect(name, parent);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = anchor;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    void BuildCombat(Transform root)
    {
        var half = new Vector2(0.5f, 0.5f);

        // Damage flash (full screen)
        var hf = NewRect("Hurt", root);
        hf.anchorMin = Vector2.zero; hf.anchorMax = Vector2.one;
        hf.offsetMin = hf.offsetMax = Vector2.zero;
        hurtFlash = hf.gameObject.AddComponent<Image>();
        hurtFlash.color = new Color(0.8f, 0f, 0f, 0f);
        hurtFlash.raycastTarget = false;

        // Crosshair
        Color ch = new Color(1f, 1f, 1f, 0.9f);
        Bar("ChDot", root, half, Vector2.zero, new Vector2(6, 6), ch);
        Bar("ChL", root, half, new Vector2(-18, 0), new Vector2(14, 3), ch);
        Bar("ChR", root, half, new Vector2(18, 0), new Vector2(14, 3), ch);
        Bar("ChU", root, half, new Vector2(0, 18), new Vector2(3, 14), ch);
        Bar("ChD", root, half, new Vector2(0, -18), new Vector2(3, 14), ch);

        // Hit marker
        var hm = NewRect("HitMark", root);
        hm.anchorMin = hm.anchorMax = half; hm.pivot = half;
        hm.anchoredPosition = Vector2.zero; hm.sizeDelta = new Vector2(80, 80);
        hitMark = Label(hm, "X", 44, TextAnchor.MiddleCenter);
        hitMark.color = new Color(1f, 0.3f, 0.2f, 1f);
        hitMark.enabled = false;

        // Health bar (bottom centre)
        var bg = Bar("HpBg", root, new Vector2(0.5f, 0f), new Vector2(0, 48), new Vector2(520, 28), new Color(0, 0, 0, 0.55f));
        var fr = NewRect("HpFill", bg.transform);
        fr.anchorMin = fr.anchorMax = new Vector2(0f, 0.5f);
        fr.pivot = new Vector2(0f, 0.5f);
        fr.anchoredPosition = new Vector2(2, 0);
        fr.sizeDelta = new Vector2(516, 24);
        hpFill = fr.gameObject.AddComponent<Image>();
        hpFill.raycastTarget = false;
        hpText = Label(bg.transform, "100", 20, TextAnchor.MiddleCenter);

        // Ammo / weapon (top centre), kills (top left)
        var ar = Anchored("Ammo", root, new Vector2(0.5f, 1f), new Vector2(0, -14), new Vector2(700, 64));
        ar.pivot = new Vector2(0.5f, 1f);
        ammoText = Label(ar, "", 38, TextAnchor.MiddleCenter);
        var kr = Anchored("Kills", root, new Vector2(0f, 1f), new Vector2(24, -60), new Vector2(600, 40));
        killText = Label(kr, "", 26, TextAnchor.MiddleLeft);
        var cr = Anchored("Center", root, half, new Vector2(0, 140), new Vector2(900, 120));
        cr.pivot = half;
        centerText = Label(cr, "", 72, TextAnchor.MiddleCenter);

        // Buttons
        Vector2 br = new Vector2(1f, 0f);
        var fireBig = Button("Fire", "FIRE", br, new Vector2(-170, 520), 190,
            () => { fireA = true; }, () => { fireA = false; }, 34);
        fireBig.color = new Color(1f, 0.3f, 0.2f, 0.5f);
        var fireLeft = Button("FireL", "FIRE", new Vector2(0f, 0.5f), new Vector2(140, 170), 150,
            () => { fireB = true; }, () => { fireB = false; }, 28);
        fireLeft.color = new Color(1f, 0.3f, 0.2f, 0.5f);
        aimBtn = Button("Aim", "AIM", br, new Vector2(-390, 470), 120,
            () => { MobileInput.Aiming = !MobileInput.Aiming; }, null, 26);
        Button("Reload", "RELOAD", br, new Vector2(-575, 210), 110,
            () => { MobileInput.ReloadPressed = true; }, null, 18);
        Button("Swap", "SWAP", br, new Vector2(-575, 345), 110,
            () => { MobileInput.SwitchPressed = true; }, null, 22);

        // Heal / armor quick buttons + BAG
        var heal = Button("Heal", "HEAL", br, new Vector2(-770, 110), 100,
            () => { var w = WeaponController.Instance; if (Inv.Medkits > 0 && w.Hp.hp < w.Hp.max) { Inv.Medkits--; w.Hp.Heal(50f); } }, null, 20);
        heal.color = new Color(0.3f, 1f, 0.4f, 0.45f);
        healLbl = heal.GetComponentInChildren<Text>();
        var arm = Button("ArmorUse", "ARMOR", br, new Vector2(-770, 235), 100,
            () => { var w = WeaponController.Instance; if (Inv.Plates > 0 && w.Hp.armor < w.Hp.maxArmor) { Inv.Plates--; w.Hp.armor = Mathf.Min(w.Hp.maxArmor, w.Hp.armor + 50f); } }, null, 18);
        arm.color = new Color(0.4f, 0.6f, 1f, 0.45f);
        armorLbl = arm.GetComponentInChildren<Text>();
        Button("Bag", "BAG", new Vector2(1f, 1f), new Vector2(-70, -215), 90, () => { bagPanel.SetActive(!bagPanel.activeSelf); }, null, 24);

        // Zone status, pickup toast, parachute prompt
        var zr = Anchored("Zone", root, new Vector2(0f, 1f), new Vector2(24, -100), new Vector2(1000, 40));
        zoneText = Label(zr, "", 24, TextAnchor.MiddleLeft);
        var tt = Anchored("Toast", root, half, new Vector2(0, -170), new Vector2(900, 60));
        toastText = Label(tt, "", 36, TextAnchor.MiddleCenter);
        toastText.color = new Color(1f, 0.9f, 0.3f, 1f);
        var pr = Anchored("Prompt", root, half, new Vector2(0, 260), new Vector2(1200, 80));
        promptText = Label(pr, "", 44, TextAnchor.MiddleCenter);

        // Bag panel (inventory): tap a weapon row to equip it
        var panel = Bar("BagPanel", root, half, Vector2.zero, new Vector2(720, 480), new Color(0.05f, 0.05f, 0.08f, 0.9f));
        panel.raycastTarget = true;
        bagPanel = panel.gameObject;
        var bt = Anchored("BagTitle", panel.transform, half, new Vector2(0, 205), new Vector2(660, 50));
        Label(bt, "BAG  (tap a weapon to equip)", 30, TextAnchor.MiddleCenter);
        for (int i = 0; i < 4; i++)
        {
            int idx = i;
            var row = Bar("Row" + i, panel.transform, half, new Vector2(0, 130 - i * 85), new Vector2(660, 72), new Color(1f, 1f, 1f, 0.15f));
            row.raycastTarget = true;
            row.gameObject.AddComponent<TapButton>().onDown = () => { var w = WeaponController.Instance; if (w != null) w.Equip(idx); };
            bagRows[i] = Label(row.transform, "", 30, TextAnchor.MiddleCenter);
        }
        var bi = Anchored("BagInfo", panel.transform, half, new Vector2(0, -205), new Vector2(660, 50));
        bagInfo = Label(bi, "", 28, TextAnchor.MiddleCenter);
        bagPanel.SetActive(false);

        Button("Emote", "EMOTE", br, new Vector2(-935, 110), 100,
            () => { var wc = WeaponController.Instance; if (wc != null) wc.GetComponent<PlayerController>().Emote(); }, null, 18);
        carBtn = Button("Car", "DRIVE", br, new Vector2(-770, 360), 110, () => { Vehicle.Toggle(); }, null, 22);
        carBtn.color = new Color(1f, 0.8f, 0.2f, 0.45f);
        carLbl = carBtn.GetComponentInChildren<Text>();
        BuildMap(root);

        // Death screen (added last so it sits on top)
        deathPanel = Bar("Death", root, half, Vector2.zero, new Vector2(4000, 4000), new Color(0, 0, 0, 0.65f));
        deathPanel.raycastTarget = true;
        var dt = NewRect("DeathText", deathPanel.transform);
        dt.anchorMin = dt.anchorMax = half; dt.pivot = half;
        dt.anchoredPosition = new Vector2(0, 120); dt.sizeDelta = new Vector2(900, 160);
        deathTitle = Label(dt, "ELIMINATED", 90, TextAnchor.MiddleCenter);
        var st = NewRect("DeathStats", deathPanel.transform);
        st.anchorMin = st.anchorMax = half; st.pivot = half;
        st.anchoredPosition = new Vector2(0, 10); st.sizeDelta = new Vector2(1200, 160);
        deathStats = Label(st, "", 40, TextAnchor.MiddleCenter);
        var again = Button("PlayAgain", "PLAY AGAIN", half, new Vector2(-170, -150), 200,
            () => { GameFlow.PlayAgain(); }, null, 26);
        again.color = new Color(1f, 0.55f, 0.2f, 0.9f);
        var lob = Button("Lobby", "LOBBY", half, new Vector2(170, -150), 200,
            () => { GameFlow.ToLobby(); }, null, 30);
        lob.color = new Color(0.3f, 0.6f, 1f, 0.9f);
        respawnBtn = again.gameObject;
        lobbyBtn = lob.gameObject;
        respawnBtn.SetActive(false);
        lobbyBtn.SetActive(false);
        deathPanel.gameObject.SetActive(false);
    }

    void UpdateCombat()
    {
        var w = WeaponController.Instance;
        if (w == null) return;
        MobileInput.Firing = fireA || fireB;
        UpdateMap();

        if (!hooked)
        {
            hooked = true;
            w.Hp.OnDamaged += (dmg, atk) => { hurtAlpha = 0.55f; Sfx.Play2D(Sfx.Hurt, 0.8f); };
            w.HitConfirmed += () => { hitTimer = 0.18f; };
        }

        var hp = w.Hp;
        float f = Mathf.Clamp01(hp.hp / hp.max);
        hpFill.rectTransform.sizeDelta = new Vector2(516f * f, 24f);
        hpFill.color = Color.Lerp(new Color(0.9f, 0.15f, 0.1f), new Color(0.2f, 0.85f, 0.3f), f);
        hpText.text = Mathf.CeilToInt(hp.hp) + " / " + Mathf.CeilToInt(hp.max);

        var wd = w.Current;
        ammoText.text = wd.name + "    " + (w.Reloading ? "RELOADING..." : (w.Ammo + " / " + w.Reserve));
        killText.text = "KILLS " + GameStats.Kills + "     ALIVE " + (GameStats.BotsAlive + (hp.Dead ? 0 : 1)) + Weather.Label;
        aimBtn.color = new Color(0.3f, 1f, 0.5f, MobileInput.Aiming ? 0.85f : 0.35f);

        hurtAlpha = Mathf.MoveTowards(hurtAlpha, 0f, Time.deltaTime * 1.2f);
        hurtFlash.color = new Color(0.8f, 0f, 0f, hurtAlpha);
        hitTimer -= Time.deltaTime;
        hitMark.enabled = hitTimer > 0f;

        healLbl.text = "HEAL\nx" + Inv.Medkits;
        armorLbl.text = "ARMOR\nx" + Inv.Plates;
        if (hp.armor > 0f) hpText.text += "     ARMOR " + Mathf.CeilToInt(hp.armor);
        toastText.text = LootManager.Message;
        promptText.text = ParachuteController.Prompt;
        var sz = SafeZone.Instance;
        if (sz != null)
        {
            zoneText.text = sz.Status(w.transform.position);
            zoneText.color = sz.Inside(w.transform.position) ? Color.white : new Color(1f, 0.4f, 0.3f, 1f);
        }
        if (bagPanel.activeSelf)
        {
            for (int i = 0; i < 4; i++)
            {
                bool own = w.Owned(i);
                bagRows[i].text = (i == w.Cur ? "> " : "   ") + Weapons.All[i].name + (own ? "    " + w.AmmoOf(i) + " / " + w.ReserveOf(i) : "    -- empty --");
                bagRows[i].color = own ? Color.white : new Color(1f, 1f, 1f, 0.4f);
            }
            bagInfo.text = "MEDKITS x" + Inv.Medkits + "        ARMOR PLATES x" + Inv.Plates;
        }

        var dv = Vehicle.Driven;
        var nv = dv != null ? dv : Vehicle.Nearest(w.transform.position, 4f);
        carBtn.gameObject.SetActive(!hp.Dead && nv != null);
        carLbl.text = dv != null ? "EXIT" : "DRIVE";

        bool dead = hp.Dead;
        bool win = !dead && GameStats.BotsAlive <= 0 && !GameStats.PlayerFlying;
        bool over = dead || win;
        if (over && !resultShown)
        {
            resultShown = true;
            int place = win ? 1 : GameStats.BotsAlive + 1;
            float secs = Time.time - GameFlow.MatchStart;
            int coins = GameFlow.RecordResult(place, GameStats.Kills, secs, GameSettings.Players);
            deathTitle.text = win ? "VICTORY!" : "ELIMINATED";
            deathTitle.color = win ? new Color(1f, 0.85f, 0.2f, 1f) : new Color(1f, 0.35f, 0.25f, 1f);
            deathStats.text = "PLACE #" + place + " / " + GameSettings.Players + "     KILLS " + GameStats.Kills + "     TIME " + (int)(secs / 60f) + ":" + ((int)secs % 60).ToString("00") + "\n+" + coins + " COINS";
        }
        deathPanel.gameObject.SetActive(over);
        respawnBtn.SetActive(over);
        lobbyBtn.SetActive(over);
        centerText.text = "";
    }
}
