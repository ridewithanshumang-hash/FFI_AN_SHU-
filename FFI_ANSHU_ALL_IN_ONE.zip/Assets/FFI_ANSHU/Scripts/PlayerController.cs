using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public float walkSpeed = 4.2f;
    public float runSpeed = 7.2f;
    public float crouchSpeed = 2.0f;
    public float jumpHeight = 1.2f;
    public float gravity = -22f;
    public float acceleration = 22f;
    public float turnSpeed = 720f;

    ThirdPersonCamera cam;
    CharacterController cc;
    Transform model, armL, armR, legL, legR;
    Vector3 planarVel;
    float vy, animT, crouchBlend, stepT;
    Vector3 spawn;

    public bool IsCrouching { get { return MobileInput.Crouching; } }
    public float PlanarSpeed { get { return planarVel.magnitude; } }
    public Transform Model { get { return model; } }
    public bool Locked;   // true while dead
    float emoteT;
    public void Emote() { if (!Locked && !Flying) emoteT = 2.5f; }
    public bool Flying;   // true on the plane / parachute (ParachuteController moves the player)

    public void Init(ThirdPersonCamera camera, CharacterSkin skin, Vector3 spawnPoint)
    {
        cam = camera;
        spawn = spawnPoint;
        cc = GetComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.35f; cc.center = new Vector3(0, 0.9f, 0);
        cc.stepOffset = 0.45f; cc.skinWidth = 0.03f; cc.slopeLimit = 55f;
        BuildModel(skin);
    }

    // ---------- Procedural character (placeholder until imported rigged models in Stage 3) ----------
    Transform Part(PrimitiveType t, Transform parent, Vector3 pos, Vector3 scale, Color c)
    {
        var g = GameObject.CreatePrimitive(t);
        Destroy(g.GetComponent<Collider>());
        g.transform.SetParent(parent, false);
        g.transform.localPosition = pos;
        g.transform.localScale = scale;
        g.GetComponent<Renderer>().sharedMaterial = MapKit.Mat(c, 0.1f);
        return g.transform;
    }

    Transform Pivot(string n, Transform parent, Vector3 pos)
    {
        var g = new GameObject(n).transform;
        g.SetParent(parent, false);
        g.localPosition = pos;
        return g;
    }

    void BuildModel(CharacterSkin s)
    {
        var rc = RiggedCharacter.Build(transform, s);
        model = rc.Root;
        legL = rc.Bone(RiggedCharacter.ULL); legR = rc.Bone(RiggedCharacter.ULR);
        armL = rc.Bone(RiggedCharacter.UAL); armR = rc.Bone(RiggedCharacter.UAR);
    }

    void Update()
    {
        if (cam == null || Flying) return;

        Vector2 kb = Vector2.zero;
        bool shiftHeld = false;
#if ENABLE_LEGACY_INPUT_MANAGER
        kb = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (Input.GetKeyDown(KeyCode.Space)) MobileInput.JumpPressed = true;
        if (Input.GetKeyDown(KeyCode.C)) MobileInput.Crouching = !MobileInput.Crouching;
        shiftHeld = Input.GetKey(KeyCode.LeftShift);
#endif
        Vector2 inp = Vector2.ClampMagnitude(MobileInput.Move + kb, 1f);
        if (Locked) inp = Vector2.zero;

        // Camera-relative direction
        Quaternion yawRot = Quaternion.Euler(0, cam.Yaw, 0);
        Vector3 wish = yawRot * new Vector3(inp.x, 0, inp.y);

        bool crouch = MobileInput.Crouching;
        bool sprint = (MobileInput.Sprinting || shiftHeld) && !crouch && !Locked;
        float spd = crouch ? crouchSpeed : (sprint ? runSpeed : walkSpeed);
        if (MobileInput.Aiming) spd *= 0.6f;
        Vector3 target = wish * spd;
        planarVel = Vector3.MoveTowards(planarVel, target, acceleration * Time.deltaTime);

        if (!Locked && (MobileInput.Firing || MobileInput.Aiming))
            transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0f, cam.Yaw, 0f), turnSpeed * 1.5f * Time.deltaTime);
        else if (wish.sqrMagnitude > 0.01f)
        {
            var look = Quaternion.LookRotation(wish, Vector3.up);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, look, turnSpeed * Time.deltaTime);
        }

        // Crouch capsule
        crouchBlend = Mathf.MoveTowards(crouchBlend, crouch ? 1f : 0f, Time.deltaTime * 8f);
        float h = Mathf.Lerp(1.8f, 1.15f, crouchBlend);
        cc.height = h; cc.center = new Vector3(0, h * 0.5f, 0);
        model.localScale = new Vector3(1f, Mathf.Lerp(1f, 0.66f, crouchBlend), 1f);

        // Jump / gravity
        bool grounded = cc.isGrounded;
        if (grounded && vy < 0f) vy = -2f;
        if (MobileInput.ConsumeJump() && grounded && !Locked)
        {
            if (crouch) MobileInput.Crouching = false;
            vy = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }
        vy += gravity * Time.deltaTime;

        cc.Move((planarVel + Vector3.up * vy) * Time.deltaTime);

        Animate(grounded, crouch);

        if (transform.position.y < -15f) Respawn();
    }

    void Animate(bool grounded, bool crouch)
    {
        float sp = planarVel.magnitude;
        float amp = Mathf.Clamp01(sp / runSpeed);
        animT += sp * Time.deltaTime * 1.7f;
        float swing = Mathf.Sin(animT) * 48f * amp;
        if (emoteT > 0f)
        {
            if (sp > 1f || !grounded) emoteT = 0f;
            else
            {
                emoteT -= Time.deltaTime;
                float ew = Mathf.Sin(Time.time * 10f);
                armL.localRotation = Quaternion.Euler(-150f + ew * 25f, 0f, 0f);
                armR.localRotation = Quaternion.Euler(-150f - ew * 25f, 0f, 0f);
                legL.localRotation = Quaternion.Euler(ew * 20f, 0f, 0f);
                legR.localRotation = Quaternion.Euler(-ew * 20f, 0f, 0f);
                model.localPosition = new Vector3(0f, Mathf.Abs(ew) * 0.08f, 0f);
                return;
            }
        }
        model.localPosition = Vector3.zero;
        if (!grounded)
        {
            legL.localRotation = Quaternion.Euler(-25, 0, 0);
            legR.localRotation = Quaternion.Euler(20, 0, 0);
            armL.localRotation = Quaternion.Euler(0, 0, -35);
            armR.localRotation = Quaternion.Euler(0, 0, 35);
            return;
        }
        if (sp > 1f)
        {
            stepT -= sp * Time.deltaTime;
            if (stepT <= 0f) { Sfx.Play(Sfx.Step, transform.position, 0.45f); stepT = 2.3f; }
        }
        legL.localRotation = Quaternion.Euler(swing, 0, 0);
        legR.localRotation = Quaternion.Euler(-swing, 0, 0);
        if (MobileInput.Firing || MobileInput.Aiming)
        {
            armL.localRotation = Quaternion.Euler(-75f, 10f, 0f);
            armR.localRotation = Quaternion.Euler(-85f, 0f, 0f);
        }
        else
        {
            armL.localRotation = Quaternion.Euler(-swing * 0.8f, 0, 0);
            armR.localRotation = Quaternion.Euler(swing * 0.8f, 0, 0);
        }
    }

    public void Respawn()
    {
        cc.enabled = false;
        transform.position = spawn;
        cc.enabled = true;
        vy = 0f; planarVel = Vector3.zero;
    }
}
