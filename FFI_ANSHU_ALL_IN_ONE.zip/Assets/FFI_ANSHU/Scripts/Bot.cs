using UnityEngine;

/// <summary>Enemy bot: wanders, spots the player, chases and shoots with limited accuracy.</summary>
public class Bot : MonoBehaviour
{
    const float SightRange = 60f;

    Health hp, playerHp;
    CharacterController cc;
    Transform model, legL, legR, player;
    Vector3 wander;
    float vy, nextShot, nextThink, nextWander, nextStrafe, alertUntil, animT, strafe = 1f;
    bool los;
    int dropState;   // 0 on ground, 1 waiting in the plane, 2 falling
    float dropAt, dropVel;
    Transform canopy;

    public static Bot Create(Vector3 pos, Transform playerT, int skinIdx)
    {
        var g = new GameObject("Bot");
        g.transform.position = pos;
        var c = g.AddComponent<CharacterController>();
        c.height = 1.8f; c.radius = 0.35f; c.center = new Vector3(0f, 0.9f, 0f);
        c.stepOffset = 0.45f; c.skinWidth = 0.03f; c.slopeLimit = 55f;
        g.AddComponent<Health>();
        var b = g.AddComponent<Bot>();
        b.Setup(playerT, CharacterSkins.Get(skinIdx));
        return b;
    }

    void Setup(Transform playerT, CharacterSkin s)
    {
        cc = GetComponent<CharacterController>();
        hp = GetComponent<Health>();
        player = playerT;
        playerHp = playerT.GetComponent<Health>();
        hp.OnDied += OnDied;
        hp.OnDamaged += (dmg, attacker) => { alertUntil = Time.time + 8f; };
        wander = transform.position;
        BuildModel(s);
    }

    Transform Part(PrimitiveType t, Transform parent, Vector3 pos, Vector3 scale, Color c)
    {
        return MapKit.Prim(t, parent, pos, scale, MapKit.Mat(c, 0.1f), false).transform;
    }

    Transform Pivot(string n, Transform parent, Vector3 pos)
    {
        var g = new GameObject(n).transform;
        g.SetParent(parent, false);
        g.localPosition = pos;
        return g;
    }

    void BuildModel(CharacterSkin s)
    {
        s.sash = Color.red;   // enemies wear a red sash/boots
        var rc = RiggedCharacter.Build(transform, s);
        model = rc.Root;
        legL = rc.Bone(RiggedCharacter.ULL); legR = rc.Bone(RiggedCharacter.ULR);
        rc.Bone(RiggedCharacter.UAL).localRotation = Quaternion.Euler(-80f, 0f, 0f);
        rc.Bone(RiggedCharacter.UAR).localRotation = Quaternion.Euler(-80f, 0f, 0f);
        Part(PrimitiveType.Cube, model, new Vector3(0.2f, 1.25f, 0.55f), new Vector3(0.07f, 0.1f, 0.6f), new Color(0.15f, 0.15f, 0.17f));
    }

    void Face(Vector3 dir)
    {
        dir.y = 0f;
        if (dir.sqrMagnitude < 0.001f) return;
        transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(dir), 360f * Time.deltaTime);
    }

    void Update()
    {
        if (hp.Dead) return;
        if (dropState != 0) { DropUpdate(); return; }
        float dt = Time.deltaTime;
        Vector3 pp = player.position;
        Vector3 to = pp - transform.position;
        to.y = 0f;
        float dist = to.magnitude;
        Vector3 dir = dist > 0.01f ? to / dist : transform.forward;

        if (Time.time >= nextThink)
        {
            nextThink = Time.time + 0.25f + Random.Range(0f, 0.1f);
            bool near = dist < 170f;   // hide far bots (big performance win with 50 players)
            if (model.gameObject.activeSelf != near) model.gameObject.SetActive(near);
            los = false;
            if (!playerHp.Dead && !GameStats.PlayerFlying && dist < SightRange * (1f - 0.45f * Weather.Intensity))
            {
                Vector3 eye = transform.position + Vector3.up * 1.6f;
                Vector3 tgt = pp + Vector3.up * 1.2f;
                los = !Physics.Linecast(eye, tgt, ~(1 << 2), QueryTriggerInteraction.Ignore);
            }
            if (los) alertUntil = Mathf.Max(alertUntil, Time.time + 6f);
        }

        bool engaged = !playerHp.Dead && !GameStats.PlayerFlying && Time.time < alertUntil;
        bool outside = SafeZone.Instance != null && !SafeZone.Instance.Inside(transform.position);
        Vector3 move = Vector3.zero;
        float speed = 0f;

        if (outside)
        {
            Vector3 zc = SafeZone.Instance.Center - transform.position;
            zc.y = 0f;
            move = zc.normalized; speed = 5f;
            Face(move);
        }
        else if (engaged)
        {
            Face(dir);
            if (Time.time > nextStrafe) { strafe = Random.value < 0.5f ? -1f : 1f; nextStrafe = Time.time + Random.Range(1f, 3f); }
            if (los)
            {
                if (dist > 26f) { move = dir; speed = 5f; }
                else if (dist < 10f) { move = -dir; speed = 3.5f; }
                else { move = Vector3.Cross(Vector3.up, dir) * strafe; speed = 2.5f; }
                if (Time.time >= nextShot) Shoot(dist);
            }
            else { move = dir; speed = 5f; }
        }
        else
        {
            Vector3 w = wander - transform.position;
            w.y = 0f;
            if (Time.time > nextWander || w.sqrMagnitude < 4f)
            {
                Vector3 p = transform.position + new Vector3(Random.Range(-45f, 45f), 0f, Random.Range(-45f, 45f));
                p.x = Mathf.Clamp(p.x, 70f, 730f);
                p.z = Mathf.Clamp(p.z, 70f, 730f);
                wander = p;
                nextWander = Time.time + Random.Range(6f, 12f);
                w = wander - transform.position; w.y = 0f;
            }
            if (w.magnitude > 1f) { move = w.normalized; speed = 2.8f; Face(move); }
        }

        vy = cc.isGrounded ? -2f : vy - 20f * dt;
        cc.Move((move * speed + Vector3.up * vy) * dt);

        animT += speed * dt * 1.7f;
        float swing = Mathf.Sin(animT) * 40f * Mathf.Clamp01(speed / 5f);
        legL.localRotation = Quaternion.Euler(swing, 0f, 0f);
        legR.localRotation = Quaternion.Euler(-swing, 0f, 0f);
    }

    /// <summary>Bot starts in the plane: appears after 'delay' seconds high above its spot and parachutes down.</summary>
    public void StartDrop(float delay)
    {
        dropState = 1;
        dropAt = Time.time + delay;
        cc.enabled = false;
        model.gameObject.SetActive(false);
        transform.position += Vector3.up * Random.Range(130f, 190f);
    }

    void DropUpdate()
    {
        if (dropState == 1)
        {
            if (Time.time < dropAt) return;
            dropState = 2;
            dropVel = 0f;
            model.gameObject.SetActive(true);
        }
        float dt = Time.deltaTime;
        RaycastHit hit;
        float h = 999f;
        bool found = Physics.Raycast(transform.position + Vector3.up * 0.5f, Vector3.down, out hit, 1000f, ~(1 << 2), QueryTriggerInteraction.Ignore);
        if (found) h = hit.distance - 0.5f;
        bool chute = h < 70f;
        dropVel = Mathf.MoveTowards(dropVel, chute ? -9f : -40f, 30f * dt);
        transform.position += Vector3.up * dropVel * dt;
        if (chute && canopy == null)
            canopy = MapKit.Prim(PrimitiveType.Sphere, transform, new Vector3(0f, 3.3f, 0f), new Vector3(3.5f, 1.8f, 3.5f),
                                 MapKit.Mat(new Color(0.9f, 0.3f, 0.1f), 0.1f), false).transform;
        if (h <= 1f)
        {
            if (found) transform.position = hit.point + Vector3.up * 0.05f;
            if (canopy != null) Destroy(canopy.gameObject);
            cc.enabled = true;
            dropState = 0;
        }
    }

    void Shoot(float dist)
    {
        nextShot = Time.time + Random.Range(0.35f, 0.6f);
        float chance = Mathf.Clamp(0.6f - dist * 0.015f, 0.08f, 0.5f);
        Vector3 from = transform.position + Vector3.up * 1.3f + transform.forward * 0.6f;
        Vector3 target = player.position + Vector3.up * 1.2f;
        if (Random.value < chance) playerHp.Take(8f, gameObject);
        else target += Random.insideUnitSphere * 2f;
        Tracers.Spawn(from, target);
        Sfx.Play(Sfx.Shot(2), from, 0.6f);
    }

    void OnDied(GameObject killer)
    {
        GameStats.BotsAlive--;
        if (killer != null && killer.GetComponent<PlayerController>() != null) GameStats.Kills++;
        cc.enabled = false;
        model.localRotation = Quaternion.Euler(-90f, 0f, 0f);
        model.localPosition = new Vector3(0f, 0.25f, 0f);
        Destroy(gameObject, 12f);
    }
}
