using UnityEngine;

/// <summary>
/// Diamonds wallet, redeem codes, referral code and the daily free spin.
/// IMPORTANT: everything is stored on this device (PlayerPrefs) and the codes are checked inside the app.
/// There is no server, so codes are not secret and can be reused after reinstall. Real, abuse-proof codes and
/// real-money top-ups need a backend (and Google Play Billing for payments).
/// </summary>
public static class Wallet
{
    public const string ReferralCode = "ANSHUU";
    public const int ReferralDiamonds = 10000;
    public const int PaidSpinCost = 50;

    public static int Diamonds
    {
        get { return PlayerPrefs.GetInt("dia", 100); }
        set { PlayerPrefs.SetInt("dia", Mathf.Max(0, value)); }
    }

    public static bool Spend(int n)
    {
        if (Diamonds < n) return false;
        Diamonds -= n;
        PlayerPrefs.Save();
        return true;
    }

    struct Code { public string code; public int dia, coins; public string skin; }

    static readonly Code[] Codes =
    {
        new Code{ code="FFIANSHU",   dia=500 },
        new Code{ code="KALAHARI",   dia=300 },
        new Code{ code="DINOBONE",   dia=200, coins=500 },
        new Code{ code="JAISALMER",  coins=1000 },
        new Code{ code="DESERTKING", skin="Dune Phantom" },
    };

    static bool Used(string key) { return PlayerPrefs.GetString("usedcodes", "").Contains(";" + key + ";"); }
    static void MarkUsed(string key) { PlayerPrefs.SetString("usedcodes", PlayerPrefs.GetString("usedcodes", "") + ";" + key + ";"); }
    static string Norm(string raw) { return string.IsNullOrEmpty(raw) ? "" : raw.Trim().ToUpper(); }

    /// <summary>Referral code: 10000 diamonds, once per device.</summary>
    public static string UseReferral(string raw)
    {
        string c = Norm(raw);
        if (c.Length == 0) return "ENTER A REFERRAL CODE";
        if (c != ReferralCode) return "INVALID REFERRAL CODE";
        if (PlayerPrefs.GetInt("ref_used", 0) == 1) return "REFERRAL CODE ALREADY USED";
        PlayerPrefs.SetInt("ref_used", 1);
        Diamonds += ReferralDiamonds;
        PlayerPrefs.Save();
        return "REFERRAL APPLIED!  +" + ReferralDiamonds + " DIAMONDS";
    }

    /// <summary>Redeem code (the referral code also works here).</summary>
    public static string Redeem(string raw)
    {
        string c = Norm(raw);
        if (c.Length == 0) return "ENTER A CODE";
        if (c == ReferralCode) return UseReferral(c);
        foreach (var k in Codes)
        {
            if (k.code != c) continue;
            if (Used(c)) return "CODE ALREADY USED";
            MarkUsed(c);
            string msg = "CODE REDEEMED!";
            if (k.dia > 0) { Diamonds += k.dia; msg += "  +" + k.dia + " DIAMONDS"; }
            if (k.coins > 0) { GameFlow.Coins += k.coins; msg += "  +" + k.coins + " COINS"; }
            if (!string.IsNullOrEmpty(k.skin))
            {
                int i = CharacterSkins.IndexOf(k.skin);
                if (i >= 0) { CharacterSkins.Unlock(i); msg += "  SKIN: " + k.skin.ToUpper(); }
            }
            PlayerPrefs.Save();
            return msg;
        }
        return "INVALID CODE";
    }

    // ---- daily free spin ----
    static string Today { get { return System.DateTime.Now.ToString("yyyyMMdd"); } }
    public static bool FreeSpinReady { get { return PlayerPrefs.GetString("spinday", "") != Today; } }
    public static void UseFreeSpin() { PlayerPrefs.SetString("spinday", Today); PlayerPrefs.Save(); }
}
