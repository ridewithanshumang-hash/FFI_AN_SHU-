using UnityEngine;

/// <summary>Shrinking safe zone: blue pillar ring, damage outside, status text for the HUD.</summary>
public class SafeZone : MonoBehaviour
{
    public static SafeZone Instance;

    struct Phase
    {
        public float radius, wait, shrink, dps;
        public Phase(float r, float w, float s, float d) { radius = r; wait = w; shrink = s; dps = d; }
    }

    static readonly Phase[] Phases =
    {
        new Phase(330f, 90f, 45f, 1f),
        new Phase(200f, 40f, 40f, 2f),
        new Phase(110f, 35f, 35f, 4f),
        new Phase(45f,  30f, 30f, 7f),
        new Phase(8f,   20f, 25f, 12f),
    };

    const int N = 160;
    public Vector3 Center { get; private set; }
    public float Radius { get; private set; }
    public Vector2 NextCenter { get { return toC; } }
    public float NextRadius { get { return toR; } }
    public bool ShowNext { get { return !shrinking && !finished; } }

    int phase;
    float t, nextTick, fromR, toR;
    bool shrinking, finished;
    Vector2 fromC, toC;
    Transform[] pillars, nextPillars;
    Transform nextRoot;

    public static SafeZone Create(Transform player)
    {
        var g = new GameObject("SafeZone");
        var z = g.AddComponent<SafeZone>();
        z.Setup();
        return z;
    }

    void Setup()
    {
        Instance = this;
        Radius = 560f; fromR = 560f;
        fromC = new Vector2(400f, 400f);
        Center = new Vector3(400f, 0f, 400f);
        phase = 0; t = 0f; shrinking = false; finished = false;
        PickNext();

        var mat = MapKit.Mat(new Color(0.2f, 0.5f, 1f), 0f);
        pillars = new Transform[N];
        for (int i = 0; i < N; i++)
        {
            var p = MapKit.Prim(PrimitiveType.Cube, transform, Vector3.zero, new Vector3(3f, 140f, 3f), mat, false);
            p.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            pillars[i] = p.transform;
        }
        Layout();

        nextRoot = new GameObject("NextZone").transform;
        nextRoot.SetParent(transform, false);
        var wm = MapKit.Mat(Color.white, 0f);
        nextPillars = new Transform[64];
        for (int i = 0; i < 64; i++)
        {
            var q = MapKit.Prim(PrimitiveType.Cube, nextRoot, Vector3.zero, new Vector3(1.2f, 90f, 1.2f), wm, false);
            q.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            nextPillars[i] = q.transform;
        }
    }

    void PickNext()
    {
        toR = Phases[phase].radius;
        Vector2 off = Random.insideUnitCircle * Mathf.Max(0f, fromR - toR);
        toC = fromC + off;
    }

    public bool Inside(Vector3 p)
    {
        float dx = p.x - Center.x, dz = p.z - Center.z;
        return Mathf.Sqrt(dx * dx + dz * dz) <= Radius;
    }

    float DistToEdge(Vector3 p)
    {
        float dx = p.x - Center.x, dz = p.z - Center.z;
        return Radius - Mathf.Sqrt(dx * dx + dz * dz);   // negative = outside
    }

    public string Status(Vector3 p)
    {
        string s;
        if (finished) s = "FINAL ZONE";
        else if (!shrinking) s = "ZONE SHRINKS IN " + Mathf.CeilToInt(Mathf.Max(0f, Phases[phase].wait - t)) + "s";
        else s = "ZONE SHRINKING";
        float d = DistToEdge(p);
        if (d < 0f) return s + "   OUTSIDE ZONE! " + Mathf.CeilToInt(-d) + "m  (taking damage)";
        return s + "   " + Mathf.CeilToInt(d) + "m to edge";
    }

    void Layout()
    {
        for (int i = 0; i < N; i++)
        {
            float a = i * Mathf.PI * 2f / N;
            pillars[i].position = new Vector3(Center.x + Mathf.Cos(a) * Radius, 60f, Center.z + Mathf.Sin(a) * Radius);
        }
    }

    void Update()
    {
        float dt = Time.deltaTime;
        if (!finished)
        {
            t += dt;
            if (!shrinking)
            {
                if (t >= Phases[phase].wait) { shrinking = true; t = 0f; }
            }
            else
            {
                float k = Mathf.Clamp01(t / Phases[phase].shrink);
                Radius = Mathf.Lerp(fromR, toR, k);
                Vector2 c = Vector2.Lerp(fromC, toC, k);
                Center = new Vector3(c.x, 0f, c.y);
                Layout();
                if (k >= 1f)
                {
                    fromR = toR; fromC = toC;
                    shrinking = false; t = 0f;
                    if (phase >= Phases.Length - 1) finished = true;
                    else { phase++; PickNext(); }
                }
            }
        }

        bool showNext = ShowNext;
        if (nextRoot.gameObject.activeSelf != showNext) nextRoot.gameObject.SetActive(showNext);
        if (showNext)
            for (int k2 = 0; k2 < nextPillars.Length; k2++)
            {
                float an = k2 * Mathf.PI * 2f / nextPillars.Length;
                nextPillars[k2].position = new Vector3(toC.x + Mathf.Cos(an) * toR, 40f, toC.y + Mathf.Sin(an) * toR);
            }

        if (Time.time >= nextTick)
        {
            nextTick = Time.time + 1f;
            float dps = Phases[Mathf.Min(phase, Phases.Length - 1)].dps;
            var all = Health.All;
            for (int i = all.Count - 1; i >= 0; i--)
            {
                var h = all[i];
                if (h == null || h.Dead) continue;
                if (h.IsPlayer && GameStats.PlayerFlying) continue;
                if (!Inside(h.transform.position)) h.Take(dps, null);
            }
        }
    }
}
