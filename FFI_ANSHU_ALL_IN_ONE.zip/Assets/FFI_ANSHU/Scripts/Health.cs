using UnityEngine;

/// <summary>Hit points for the player and bots.</summary>
public class Health : MonoBehaviour
{
    public float max = 100f;
    public float hp;
    public float armor;
    public float maxArmor = 100f;
    public bool IsPlayer;
    public static readonly System.Collections.Generic.List<Health> All = new System.Collections.Generic.List<Health>();
    public bool Dead { get; private set; }

    public event System.Action<float, GameObject> OnDamaged;
    public event System.Action<GameObject> OnDied;

    void Awake() { hp = max; All.Add(this); }
    void OnDestroy() { All.Remove(this); }

    public void Take(float dmg, GameObject attacker)
    {
        if (Dead || dmg <= 0f) return;
        if (armor > 0f) { float ab = Mathf.Min(armor, dmg * 0.6f); armor -= ab; dmg -= ab; }
        hp = Mathf.Max(0f, hp - dmg);
        if (OnDamaged != null) OnDamaged(dmg, attacker);
        if (hp <= 0f)
        {
            Dead = true;
            if (OnDied != null) OnDied(attacker);
        }
    }

    public void Revive() { hp = max; armor = 0f; Dead = false; }
    public void Heal(float a) { if (!Dead) hp = Mathf.Min(max, hp + a); }
}
