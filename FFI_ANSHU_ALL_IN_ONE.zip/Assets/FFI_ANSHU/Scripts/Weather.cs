using UnityEngine;

/// <summary>Random sandstorms: thick tan fog, shorter bot sight, louder wind. Runs after DayNightCycle so it can blend the fog.</summary>
[DefaultExecutionOrder(100)]
public class Weather : MonoBehaviour
{
    public static float Intensity;
    public static string Label { get { return Intensity > 0.3f ? "     SANDSTORM" : ""; } }

    float target, nextChange, baseDensity;
    bool storm;

    void Start()
    {
        Intensity = 0f;
        baseDensity = RenderSettings.fogDensity;
        nextChange = Time.time + Random.Range(120f, 200f);
    }

    void Update()
    {
        if (Time.time >= nextChange)
        {
            storm = !storm;
            target = storm ? 1f : 0f;
            nextChange = Time.time + (storm ? Random.Range(45f, 70f) : Random.Range(150f, 240f));
        }
        Intensity = Mathf.MoveTowards(Intensity, target, Time.deltaTime / 12f);
        RenderSettings.fogDensity = Mathf.Lerp(baseDensity, 0.007f, Intensity);
        Color tan = new Color(0.62f, 0.5f, 0.34f) * Mathf.Lerp(0.25f, 1f, Mathf.Clamp01(RenderSettings.fogColor.grayscale * 1.4f));
        RenderSettings.fogColor = Color.Lerp(RenderSettings.fogColor, tan, Intensity * 0.85f);
        Sfx.SetWindBoost(Intensity);
    }
}
