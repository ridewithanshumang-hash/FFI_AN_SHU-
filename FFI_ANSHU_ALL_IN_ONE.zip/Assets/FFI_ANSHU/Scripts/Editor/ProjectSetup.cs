#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

public static class ProjectSetup
{
    [MenuItem("FFI_ANSHU/Configure for Android")]
    public static void Configure()
    {
        PlayerSettings.productName = "FFI_ANSHU";
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.anshu.ffianshu");
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
        Debug.Log("FFI_ANSHU: Android settings applied (IL2CPP, ARM64, landscape, minSdk 24).");
    }
}
#endif
