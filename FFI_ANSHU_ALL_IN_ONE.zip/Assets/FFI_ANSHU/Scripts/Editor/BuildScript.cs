using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.Rendering;

/// <summary>Headless Android build used by the GitHub Actions workflow. Also: menu FFI_ANSHU > Build APK.</summary>
public static class BuildScript
{
    [MenuItem("FFI_ANSHU/Build APK")]
    public static void BuildAndroid()
    {
        ProjectSetup.Configure();
        PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
        PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });
        EditorUserBuildSettings.buildAppBundle = false;

        Directory.CreateDirectory("Assets/Scenes");
        const string scenePath = "Assets/Scenes/Main.unity";
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.Refresh();

        Directory.CreateDirectory("build/Android");
        var opts = new BuildPlayerOptions
        {
            scenes = new[] { scenePath },
            locationPathName = "build/Android/FFI_ANSHU.apk",
            target = BuildTarget.Android,
            options = BuildOptions.None
        };
        var report = BuildPipeline.BuildPlayer(opts);
        if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
            EditorApplication.Exit(1);
    }
}
