using UnityEngine;

/// <summary>
/// Entry point. Auto-runs in ANY scene on Play: shows the 3D lobby, then builds the match when PLAY is pressed.
/// </summary>
public class GameBootstrap : MonoBehaviour
{
    public static readonly Vector3 SpawnPoint = new Vector3(400f, MapBuilder.FlatH + 0.15f, 330f);

    Camera cam;
    ThirdPersonCamera tpc;
    DayNightCycle dn;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Auto()
    {
        if (FindFirstObjectByType<GameBootstrap>() == null)
            new GameObject("FFI_ANSHU_Bootstrap").AddComponent<GameBootstrap>();
    }

    void Start()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.LandscapeLeft;

        cam = Camera.main;
        if (cam == null)
        {
            var cg = new GameObject("Main Camera");
            cg.tag = "MainCamera";
            cam = cg.AddComponent<Camera>();
            cg.AddComponent<AudioListener>();
        }
        cam.clearFlags = CameraClearFlags.Skybox;
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 700f;
        cam.fieldOfView = 62f;
        foreach (var old in cam.GetComponents<ThirdPersonCamera>()) Destroy(old);
        tpc = cam.gameObject.AddComponent<ThirdPersonCamera>();

        GameSettings.Apply();
        Sfx.Init();
        dn = DayNightCycle.Create(cam);

        if (GameFlow.AutoStart) { GameFlow.AutoStart = false; StartMatch(); }
        else Lobby.Create(this, cam, dn);
    }

    public void StartMatch()
    {
        MapBuilder.Variant = PlayerPrefs.GetInt("map", 0);
        dn.timeOfDay = MapBuilder.Variant == 1 ? 0.30f : 0.36f;
        dn.dayLengthSeconds = 600f;
        MobileInput.Crouching = false; MobileInput.Sprinting = false; MobileInput.Aiming = false;
        MobileInput.Firing = false; MobileInput.Move = Vector2.zero;
        GameFlow.MatchStart = Time.time;

        Random.InitState(20260);                 // same map every match
        MapBuilder.Build();
        Vector3 spawn = MapBuilder.SpawnPos;
        Random.InitState(System.Environment.TickCount);   // different loot / bots every match

        // Player
        var pg = new GameObject("Player");
        pg.transform.position = spawn;
        pg.layer = 2; // Ignore Raycast: camera / bullet rays skip the player
        pg.AddComponent<CharacterController>();
        var player = pg.AddComponent<PlayerController>();
        player.Init(tpc, CharacterSkins.Get(PlayerPrefs.GetInt("skin", 0)), spawn);
        tpc.target = pg.transform;

        // Combat + match systems
        pg.AddComponent<Health>().IsPlayer = true;
        var weapons = pg.AddComponent<WeaponController>();
        weapons.Init(tpc, player);
        BotManager.Spawn(GameSettings.Players - 1, pg.transform);
        LootManager.Create(pg.transform, weapons);
        SafeZone.Create(pg.transform);
        pg.AddComponent<ParachuteController>().Init(tpc, player);
        VehicleManager.Spawn(player, tpc);
        new GameObject("Weather").AddComponent<Weather>();

        // HUD / controls
        MobileHUD.Create();
    }
}
